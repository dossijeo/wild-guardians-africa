import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {deserialize,serialize} from '../src/persistence/snapshots.js';
import {Navigation,BIOME_IDS} from '../src/world/navigation.js';
import {actorBlockers,actorSegmentClear,prepareActorMotion} from '../src/simulation/actor-motion.js';
import * as Game from '../src/simulation/game.js';

test('recorded paid-defense night 31 finishes past fallen workers and intact walls, including reload',()=>{
 let s=deserialize(gunzipSync(readFileSync(new URL('../docs/qa/raid-paid-defense-night31/failure-state.json.gz',import.meta.url))).toString());
 const profile=JSON.parse(readFileSync(new URL('../public/content/biome-'+BIOME_IDS[s.biome]+'.json',import.meta.url))).profile;
 const nav=new Navigation(s.seed,s.biome,profile);nav.setState(s);
 assert.equal(s.completedNights,30);assert.equal(s.day,31);assert.equal(s.time,600);
 const bodies=s.raid.animals,exits=new Map(bodies.map(a=>[a.id,{...a.exit}])),ledger=structuredClone(s.ledger.balance);
 const fallen=s.workers.filter(w=>w.incapacitated).map(w=>({...w}));assert.equal(fallen.length,3);
 const walls=s.structures.filter(t=>t.kind==='wall').map(t=>({id:t.id,hp:t.hp,status:t.status}));
 let moved=false,reloaded=false,steps=0,finalAnimals=bodies;
 for(;steps<4000&&s.raid;steps++){
  const before=new Map(s.raid.animals.map(a=>[a.id,{x:a.x,z:a.z,status:a.status}]));
  finalAnimals=s.raid.animals;Game.tick(s,.1,nav);
  const animals=s.raid?.animals??finalAnimals;
  for(const a of animals){
   const start=before.get(a.id);if(start.status==='gone')continue;
   const distance=Math.hypot(a.x-start.x,a.z-start.z);moved||=distance>1e-8;
   assert.ok(distance<=.38+1e-8,'Keep the original speed bound');
   assert.ok(nav.segmentClear(start,a,a.radius,null,false),'Every swept segment respects native walls, props and terrain');
   assert.ok(actorSegmentClear(start,a,a,fallen),'No segment traverses an incapacitated worker');
  }
  for(let i=0;i<animals.length;i++)for(let j=i+1;j<animals.length;j++)if(animals[i].status!=='gone'&&animals[j].status!=='gone')
   assert.ok(Math.hypot(animals[i].x-animals[j].x,animals[i].z-animals[j].z)>=animals[i].radius+animals[j].radius-1e-8);
  if(steps===50&&s.raid){s=deserialize(serialize(s));nav.setState(s);reloaded=true;}
 }
 assert.ok(moved);assert.ok(reloaded);assert.equal(s.raid,null,'The recorded incursion must actually finish');
 assert.equal(s.completedNights,31);assert.equal(s.day,32);assert.ok(s.pauses.includes('hiring'));
 assert.deepEqual(s.ledger.balance,ledger);
 assert.deepEqual(s.structures.filter(t=>t.kind==='wall').map(t=>({id:t.id,hp:t.hp,status:t.status})),walls);
 const departures=s.events.filter(e=>e.type==='RaidEnded');assert.ok(departures.length);
 // Every original actor exits at its own recorded location, without deleting it.
 assert.ok(finalAnimals.every(a=>a.status==='gone'));
 for(const a of finalAnimals)assert.deepEqual({x:a.x,z:a.z},exits.get(a.id));
});

test('an impossible dynamic detour is cached until bodies move or terrain changes',()=>{
 let searches=0;
 const nav={version:1,walkable:()=>true,segmentClear:()=>false,*findPathSteps(){searches++;return null;}};
 const actor={id:'actor',x:0,z:0,radius:.5,path:[{x:3,z:0}]},blocker={id:'fallen',x:1,z:0,radius:.5,incapacitated:true,status:'fleeing'};
 const state={workers:[blocker],raid:{animals:[actor]}};
 for(let i=0;i<20;i++)prepareActorMotion(state,actor,nav,false);
 assert.equal(searches,1);
 blocker.x+=.1;prepareActorMotion(state,actor,nav,false);assert.equal(searches,2);
 blocker.x+=.2;prepareActorMotion(state,actor,nav,false);assert.equal(searches,3);
 nav.version++;prepareActorMotion(state,actor,nav,false);assert.equal(searches,4);
 assert.deepEqual(actor.path,[{x:3,z:0}]);
});

test('a sliced search does not cache a failure from bodies that moved within a quarter metre',()=>{
 let searches=0;
 const nav={version:1,walkable:()=>true,segmentClear:()=>false,*findPathSteps(){searches++;yield null;yield null;return null;}};
 const actor={id:'actor',x:0,z:0,radius:.5,path:[{x:3,z:0}]},blocker={id:'fallen',x:1,z:0,radius:.5,incapacitated:true,status:'fleeing'};
 const state={workers:[blocker],raid:{animals:[actor]}};
 prepareActorMotion(state,actor,nav,false);blocker.x+=.1;
 prepareActorMotion(state,actor,nav,false);prepareActorMotion(state,actor,nav,false);
 assert.equal(searches,1,'Keep the in-progress bounded search');
 prepareActorMotion(state,actor,nav,false);assert.equal(searches,2,'A stale failure must permit a fresh search');
});

test('native incremental A* preserves the synchronous route and expands at most eight cells per slice',()=>{
 const nav=new Navigation(712,'sabana',{}),s=Game.newGame({seed:712,slotId:'incremental-route'});nav.setState(s);
 nav.field={waterInfo:()=>({inside:false}),blocked:()=>false,slope:()=>0};nav.propsAt=()=>[];
 nav.obstacles=[{id:'solid',kind:'house',footprint:[{x:1,z:-2},{x:3,z:-2},{x:3,z:2},{x:1,z:2}]}];
 const start={x:0,z:0},end={x:4,z:0},expected=nav.findPath(start,end,.3,null,false);
 assert.ok(expected);let expanded=0,slices=0,step;
 const original=nav.searchNeighbors.bind(nav);nav.searchNeighbors=(...args)=>{expanded++;return original(...args);};
 const search=nav.findPathSteps(start,end,.3,null,false);
 do{const before=expanded;step=search.next();assert.ok(expanded-before<=8);slices++;}while(!step.done);
 assert.ok(slices>1);assert.deepEqual(step.value,expected);
 let before=start;for(const point of step.value){assert.ok(nav.segmentClear(before,point,.3,null,false));before=point;}
});

test('Recorded night 39 retreat approaches distant occupied bends instead of repeatedly yielding away',()=>{
 const s=deserialize(gunzipSync(readFileSync(new URL('../docs/qa/paid-defense-failure-ee25c8c/failure-state.json.gz',import.meta.url))).toString());
 const profile=JSON.parse(readFileSync(new URL('../public/content/biome-'+BIOME_IDS[s.biome]+'.json',import.meta.url))).profile;
 const nav=new Navigation(s.seed,s.biome,profile);nav.setState(s);
 const a=s.raid.animals.find(a=>a.id==='animal-95773'),exit={...a.exit,id:'exit-'+a.id};
 const initialDistance=Math.hypot(a.x-exit.x,a.z-exit.z),recordedFirst={...a.path[0]};
 const ledger=structuredClone(s.ledger),workers=structuredClone(s.workers);
 const initialPhase=a.motionPhase;let travelled=0;
 // Keep the checkpoint's bodies stationary to isolate route preparation; this
 // is a native-navigation regression, not a completed-raid/campaign claim.
 for(let i=0;i<125;i++){
  const before={x:a.x,z:a.z},blockers=actorBlockers(s,a,false);
  Game.walkTo(s,a,exit,.1,nav,{speed:3.8,worker:false,expandRoute:true,routeVia:a.spawn});
  const metres=Math.hypot(a.x-before.x,a.z-before.z);travelled+=metres;
  assert.ok(metres<=.38+1e-8);
  assert.ok(nav.segmentClear(before,a,a.radius,null,false),'Respect native terrain/props throughout the return');
  assert.ok(actorSegmentClear(before,a,a,blockers));
 }
 assert.ok(Math.hypot(a.x-exit.x,a.z-exit.z)<initialDistance-40,'Make sustained progress towards the original exit');
 assert.ok(a.motionPhase-initialPhase<=12.5+1e-7,'Preserve native running speed');
 assert.ok(travelled>40,'The restored connector must not stall at its first obstructing prop');
 assert.ok(!a.path.some(p=>p.x===recordedFirst.x&&p.z===recordedFirst.z));
 assert.deepEqual(s.ledger,ledger);assert.deepEqual(s.workers,workers);
 assert.deepEqual(a.exit,{x:exit.x,z:exit.z});
});

test('Motion outside the native search corridor cannot restart an incremental detour',()=>{
 let searches=0;
 const nav={version:1,walkable:()=>true,segmentClear:()=>false,*findPathSteps(){searches++;yield null;yield null;return null;}};
 const actor={id:'actor',x:0,z:0,radius:.5,path:[{x:3,z:0}]};
 const fallen={id:'fallen',x:1,z:0,radius:.5,incapacitated:true,status:'fleeing'};
 const far={id:'remote',x:100,z:0,radius:2,status:'retreating'};
 const state={workers:[fallen],raid:{animals:[actor,far]}};
 for(let i=0;i<10;i++){far.x--;prepareActorMotion(state,actor,nav,false);}
 assert.equal(searches,1,'Finish and cache the same search despite remote movement');
 // The corridor ends at x=35. The other body's clearance disc reaches it
 // before its centre does; entering that overlap must invalidate the cache.
 far.x=37.4;prepareActorMotion(state,actor,nav,false);
 assert.equal(searches,2,'Include bodies whose discs overlap the corridor');
 far.x=20;prepareActorMotion(state,actor,nav,false);
 assert.equal(searches,3,'An entering body also invalidates an in-progress search');
});

test('Recorded paid-defense night 39 actually finishes past fallen workers, including reload',()=>{
 let s=deserialize(gunzipSync(readFileSync(new URL('../docs/qa/paid-defense-failure-ee25c8c/failure-state.json.gz',import.meta.url))).toString());
 const profile=JSON.parse(readFileSync(new URL('../public/content/biome-'+BIOME_IDS[s.biome]+'.json',import.meta.url))).profile;
 const nav=new Navigation(s.seed,s.biome,profile);nav.setState(s);
 const exits=new Map(s.raid.animals.map(a=>[a.id,{...a.exit}]));
 const fallen=s.workers.filter(w=>w.incapacitated).map(w=>({...w}));
 let reloaded=false,finalAnimals;
 for(let i=0;i<6000&&s.raid;i++){
  const before=new Map(s.raid.animals.map(a=>[a.id,{x:a.x,z:a.z,status:a.status}]));
  finalAnimals=s.raid.animals;Game.tick(s,.1,nav);
  const animals=s.raid?.animals??finalAnimals;
  for(const a of animals){
   const start=before.get(a.id);if(start.status==='gone')continue;
   assert.ok(Math.hypot(a.x-start.x,a.z-start.z)<=.38+1e-8,'Keep native speed');
   assert.ok(nav.segmentClear(start,a,a.radius,null,false),'Respect terrain, props and walls throughout the full raid');
   assert.ok(actorSegmentClear(start,a,a,fallen),'Do not traverse fallen workers');
  }
  for(let a=0;a<animals.length;a++)for(let b=a+1;b<animals.length;b++)if(animals[a].status!=='gone'&&animals[b].status!=='gone')
   assert.ok(Math.hypot(animals[a].x-animals[b].x,animals[a].z-animals[b].z)>=animals[a].radius+animals[b].radius-1e-8);
  if(i===50&&s.raid){s=deserialize(serialize(s));nav.setState(s);reloaded=true;}
 }
 assert.ok(reloaded);assert.equal(s.raid,null);assert.equal(s.completedNights,39);assert.equal(s.day,40);assert.ok(s.pauses.includes('hiring'));
 assert.ok(finalAnimals.every(a=>a.status==='gone'));
 for(const a of finalAnimals)assert.deepEqual({x:a.x,z:a.z},exits.get(a.id));
});
