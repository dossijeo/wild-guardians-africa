import assert from'node:assert/strict';import{readFileSync,writeFileSync,mkdirSync}from'node:fs';import{gunzipSync}from'node:zlib';import{pathToFileURL}from'node:url';import{resolve}from'node:path';import{createHash}from'node:crypto';
import * as Original from '../src/simulation/game.js';import{Navigation}from'../src/world/navigation.js';import{deserialize,serialize}from'../src/persistence/snapshots.js';import{numberOf}from'../src/simulation/money.js';
const dir=resolve('.cache/worker-landing-candidate');mkdirSync(dir,{recursive:true});
const absolute=(source,url)=>source.replace(/from '([^']+)'/g,(m,p)=>p.startsWith('.')?`from '${new URL(p,url).href}'`:m);
const gameUrl=new URL('../src/simulation/game.js',import.meta.url),idleUrl=new URL('../src/simulation/idle.js',import.meta.url);
const game=readFileSync(gameUrl,'utf8'),idle=readFileSync(idleUrl,'utf8');
const guard='export const landingQA={checks:0,rejected:0};\nfunction landingClear(nav,worker,base){return (a,b)=>{if(base&&!base(a,b))return false;landingQA.checks++;const valid=nav.terrainValid(b.x,b.z,worker.radius??.28,true);if(!valid&&nav.terrainValid(a.x,a.z,worker.radius??.28,true)){landingQA.rejected++;return false;}return true;};}\n';
const idleFile=resolve(dir,'candidate-idle.mjs');assert.equal(idle.split('moveWorker(worker,seconds,{gates})').length,2);
writeFileSync(idleFile,guard+absolute(idle.replace('moveWorker(worker,seconds,{gates})','moveWorker(worker,seconds,{gates,clear:landingClear(nav,worker,null)})'),idleUrl));
const needle='const clear=routeClearance?.clear??dynamicClear;';assert.equal(game.split(needle).length,2);
const candidate=guard+absolute(game.replace(needle,'const baseClear=routeClearance?.clear??dynamicClear;const clear=worker?landingClear(nav,w,baseClear):baseClear;').replace("from './idle.js'",`from '${pathToFileURL(idleFile).href}'`),gameUrl);
const gameFile=resolve(dir,'candidate-game.mjs');writeFileSync(gameFile,candidate);const Candidate=await import(pathToFileURL(gameFile).href),Idle=await import(pathToFileURL(idleFile).href);
const raw=gunzipSync(readFileSync('docs/qa/intensive-sabana-musgum-e461b550/state.json.gz')).toString(),profile=JSON.parse(readFileSync('public/content/biome-savanna.json')).profile;
const hash=s=>createHash('sha256').update(s).digest('hex'),median=x=>{const a=[...x].sort((a,b)=>a-b);return a[Math.floor(a.length/2)];};const runs=[];
for(const mode of ['reference','candidate','candidate','reference']){
 const Game=mode==='reference'?Original:Candidate,s=deserialize(raw),nav=new Navigation(s.seed,s.biome,profile);nav.setState(s);Game.continuePostgame(s);const staff=Math.ceil(s.plants.filter(p=>p.alive).length/12);Game.hire(s,'qa-watering-diagnostic-hire',{olderFemale:staff});assert.equal(s.pauses.length,0);
 const first={game:{...Candidate.landingQA},idle:{...Idle.landingQA}},ms=[],hashes=[];
 for(let i=0;i<100;i++){const before=performance.now();Game.tick(s,.1,nav);const duration=performance.now()-before;if(i>=25)ms.push(duration);hashes.push(hash(serialize(s)));}
 runs.push({mode,staff,checks:{game:Candidate.landingQA.checks-first.game.checks,idle:Idle.landingQA.checks-first.idle.checks},rejected:{game:Candidate.landingQA.rejected-first.game.rejected,idle:Idle.landingQA.rejected-first.idle.rejected},measuredTicks:75,warmupTicks:25,medianMs:median(ms),totalMs:ms.reduce((a,b)=>a+b,0),samplesMs:ms,hashes,final:{time:s.time,living:s.plants.filter(p=>p.alive).length,tasks:s.tasks.length}});
 console.log(JSON.stringify({mode,medianMs:runs.at(-1).medianMs,checks:runs.at(-1).checks,rejected:runs.at(-1).rejected}));
}
const baseline=runs[0].hashes,firstDivergence=runs.map(r=>r.hashes.findIndex((h,i)=>h!==baseline[i]));
const report={scope:'QA-only endpoint terrain guard in walkTo and ambient walking; no production change. Allows already-invalid starts to exit, so it is not a complete recovery or route replanning solution. Native historical farm, ordinary paid hiring, 100 ticks each in ABBA. 25 warmup and75 measured. Serialization/hash outside timing. Four concurrent campaigns; CPU wall tick measurements, not GPU/frame/phone acceptance.',sourceHashes:{game:hash(game),idle:hash(idle),candidate:hash(candidate)},runs,firstDivergence,referenceMedian:median(runs.filter(r=>r.mode==='reference').flatMap(r=>r.samplesMs)),candidateMedian:median(runs.filter(r=>r.mode==='candidate').flatMap(r=>r.samplesMs))};
writeFileSync(resolve(dir,'report.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({firstDivergence,referenceMedian:report.referenceMedian,candidateMedian:report.candidateMedian}));
