import {readFileSync,writeFileSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {TerrainField,scatterWorld} from '../src/world/terrain.js';
import {sampleSavannaAcacias} from '../tools/experiments/far-tree-sampling.js';
const raw=execFileSync('git',['show','HEAD:src/world/terrain.js']);
writeFileSync(new URL('./terrain-before-sampling.mjs',import.meta.url),raw.toString('utf8').replace("'./fifo-eviction.js'","'../src/world/fifo-eviction.js'"));
const original=await import('./terrain-before-sampling.mjs');
const sha=value=>createHash('sha256').update(value).digest('hex');
const report={baseHead:execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),originalTerrainHash:sha(raw),defaultComparisons:[],sampling:[]};
for(const biome of ['savanna','grand_river','mangrove','volcanoes','canyons','desert']){
 const profile=JSON.parse(readFileSync(`public/content/biome-${biome}.json`,'utf8')).profile;
 for(const [cx,cz] of [[0,0],[-1,1]]){
  const config={seed:'712',biome,relief:1,density:1,river:true,n:1,cx,cz,layers:Array(6).fill(true)};
  const expected=original.scatterWorld(config,profile,new original.TerrainField(config)),actual=scatterWorld(config,profile,new TerrainField(config));
  assert.deepEqual(actual,expected);report.defaultComparisons.push({biome,cx,cz,count:actual.instances.flat().length,sha256:sha(JSON.stringify(actual))});
 }
}
const profile=JSON.parse(readFileSync('public/content/biome-savanna.json','utf8')).profile,config={seed:'712',biome:'savanna',relief:1,density:1,river:true,n:1,cx:0,cz:0,layers:Array(6).fill(true)},bounds={minX:-180,maxX:180,minZ:-230,maxZ:48};
for(let i=0;i<3;i++)for(const mode of i%2?['trees','full']:['full','trees']){
 const at=performance.now(),result=mode==='trees'?sampleSavannaAcacias(config,profile,bounds):scatterWorld({...config,bounds},profile,new TerrainField(config)).instances;
 report.sampling.push({mode,ms:performance.now()-at,trees:mode==='trees'?result.length:result[0].length,totalObjects:mode==='trees'?result.length:result.flat().length,treeHash:sha(JSON.stringify(mode==='trees'?result:result[0]))});
}
assert.equal(new Set(report.sampling.map(s=>s.treeHash)).size,1);
writeFileSync('docs/qa/far-vegetation-procedural/proof.json',JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report));
