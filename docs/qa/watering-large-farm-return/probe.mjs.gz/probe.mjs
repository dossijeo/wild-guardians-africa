import{readFileSync,writeFileSync}from'node:fs';
import{gunzipSync}from'node:zlib';
import{deserialize}from'../src/persistence/snapshots.js';
import{Navigation}from'../src/world/navigation.js';
import{footprintDistance}from'../src/world/footprints.js';
const s=deserialize(gunzipSync(readFileSync('docs/qa/intensive-sabana-musgum-e461b550/state.json.gz')).toString());
const profile=JSON.parse(readFileSync('public/content/biome-savanna.json')).profile;
const n=new Navigation(s.seed,s.biome,profile);n.setState(s);
const report=JSON.parse(readFileSync('.cache/watering-large-musgum-attribution/report.json'));
const rows=report.navigation.failureSamples.map(q=>{
 const p=q.start,r=q.radius;
 return {id:p.id,terrainValid:n.terrainValid(p.x,p.z,r,true),walkable:n.walkable(p.x,p.z,r,null,true),
  obstacleOverlaps:n.obstacles.filter(o=>o.kind!=='shield'&&(o.footprint?footprintDistance(o.footprint,p.x,p.z)<r:Math.hypot(o.x-p.x,o.z-p.z)<o.radius+r)).map(o=>({id:o.id,kind:o.kind})),
  propOverlaps:n.propsAt(p.x,p.z,r+4).filter(a=>(a.slot<4||a.slot>=10&&a.slot<=12||a.slot>=18)&&Math.hypot(a.x-p.x,a.z-p.z)<(a.radius??1.5)+r).map(a=>({id:a.id,slot:a.slot,x:a.x,z:a.z,radius:a.radius}))};
});
const result={scope:'Separate cold-navigation probe after the replay, no ticks. Endpoint and starting-point validity do not establish the cause of historical overlaps or a valid escape route.',home:report.navigation.failureSamples[0].end,homeWalkable:n.walkable(60,0,.28,null,true),rows};
writeFileSync('.cache/watering-large-musgum-attribution/return-probe.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));
