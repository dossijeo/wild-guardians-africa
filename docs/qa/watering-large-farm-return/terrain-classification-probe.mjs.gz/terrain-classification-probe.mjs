import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {deserialize} from '../src/persistence/snapshots.js';
import {Navigation} from '../src/world/navigation.js';
import {fluidAt} from '../src/world/fluid-placement.js';
const state=deserialize(gunzipSync(readFileSync('docs/qa/intensive-sabana-musgum-e461b550/state.json.gz')).toString());
const nav=new Navigation(state.seed,state.biome,JSON.parse(readFileSync('public/content/biome-savanna.json')).profile);nav.setState(state);
const failures=JSON.parse(readFileSync('.cache/watering-large-musgum-attribution/report.json')).navigation.failureSamples;
const rows=failures.map(q=>{
 const r=q.radius,p=q.start,worker=state.workers.find(w=>w.id===p.id);
 const samples=[[0,0],[r,0],[-r,0],[0,r],[0,-r]].map(([dx,dz])=>({x:p.x+dx,z:p.z+dz,fluid:fluidAt(nav.field,p.x+dx,p.z+dz),slope:nav.field.slope(p.x+dx,p.z+dz)}));
 const nearby=[];for(let d=.1;d<=1.001;d+=.1)for(let a=0;a<16;a++){
  const x=p.x+Math.sin(a*Math.PI/8)*d,z=p.z+Math.cos(a*Math.PI/8)*d;
  if(nav.walkable(x,z,r,null,true))nearby.push({x,z,d,angle:a*Math.PI/8});
 }
 return {id:p.id,x:p.x,z:p.z,radius:r,status:worker?.status,savedPathLength:worker?.path?.length??null,savedPathVersion:worker?.pathVersion,navigationVersion:nav.version,samples,rejection:samples.some(s=>s.fluid)?'fluid':samples.some(s=>s.slope>.5)?'slope':'unexplained',nearestValid:nearby[0]??null};
});
const result={scope:'Cold terrain classification, no ticks or model movement. Nearby endpoint validity does not establish a traversable recovery segment or historical cause.',seed:state.seed,biome:state.biome,terrainVersion:state.terrainVersion,rows};
writeFileSync('.cache/watering-large-musgum-attribution/terrain-classification.json',JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({rows:rows.length,rejections:rows.reduce((m,r)=>(m[r.rejection]=(m[r.rejection]??0)+1,m),{}),nearbyValid:rows.filter(r=>r.nearestValid).length,maxSlope:Math.max(...rows.flatMap(r=>r.samples.map(s=>s.slope))),first:rows[0]},null,2));
