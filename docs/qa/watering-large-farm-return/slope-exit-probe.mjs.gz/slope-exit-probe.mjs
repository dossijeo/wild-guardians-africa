import{readFileSync,writeFileSync}from'node:fs';
import{gunzipSync}from'node:zlib';
import{deserialize}from'../src/persistence/snapshots.js';
import{Navigation}from'../src/world/navigation.js';
import{fluidAt}from'../src/world/fluid-placement.js';
const s=deserialize(gunzipSync(readFileSync('docs/qa/intensive-sabana-musgum-e461b550/state.json.gz')).toString());
const nav=new Navigation(s.seed,s.biome,JSON.parse(readFileSync('public/content/biome-savanna.json')).profile);nav.setState(s);
const failures=JSON.parse(readFileSync('.cache/watering-large-musgum-attribution/report.json')).navigation.failureSamples;
const offsets=r=>[[0,0],[r,0],[-r,0],[0,r],[0,-r]];
const slope=(p,r)=>Math.max(...offsets(r).map(([dx,dz])=>nav.field.slope(p.x+dx,p.z+dz)));
const dry=(p,r)=>offsets(r).every(([dx,dz])=>!fluidAt(nav.field,p.x+dx,p.z+dz));
// QA-only view bypasses only slope; native swept obstacles, props and gates
// still apply. It is never passed to Game or used to move saved entities.
const collision=Object.assign(Object.create(nav),{terrainValid:(x,z,r)=>dry({x,z},r),segmentCache:new Map()});
const rows=[];
for(const q of failures){
 const p=q.start,r=q.radius,initial=slope(p,r);let candidate=null,attempts=0;
 search:for(let step=1;step<=10;step++)for(let angle=0;angle<32;angle++){
  attempts++;const d=step*.1,a=angle*Math.PI/16,end={x:p.x+Math.sin(a)*d,z:p.z+Math.cos(a)*d};
  if(!nav.walkable(end.x,end.z,r,null,true)||!collision.workerMotionClear(p,end,r))continue;
  const count=Math.ceil(d/.025),samples=[];let previous=initial,valid=true;
  for(let i=0;i<=count;i++){
   const point={x:p.x+(end.x-p.x)*i/count,z:p.z+(end.z-p.z)*i/count},value=slope(point,r);
   // Only decrease the existing violation; never enter fluid or a steeper part.
   if(!dry(point,r)||Math.max(0,value-.5)>Math.max(0,previous-.5)+1e-10){valid=false;break;}
   previous=value;samples.push({x:point.x,z:point.z,maxSlope:value});
  }
  if(!valid)continue;
  const tail=nav.path(end,q.end,r,null,true);if(!tail)continue;
  candidate={end,d,angle:a,samples,tail};break search;
 }
 rows.push({id:p.id,start:p,initialSlope:initial,attempts,candidate});
}
const report={scope:'QA-only slope recovery feasibility, no ticks or movement. Samples every <=0.025 m require non-increasing slope violation, no fluids, native swept props/obstacles/gates, then an ordinary native path to home. Not a production recovery or proof of historical cause.',rows};
writeFileSync('.cache/watering-large-musgum-attribution/slope-exit-feasibility.json',JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({rows:rows.length,recoverable:rows.filter(r=>r.candidate).length,maxExitDistance:Math.max(...rows.map(r=>r.candidate?.d??0)),attempts:rows.reduce((a,r)=>a+r.attempts,0)},null,2));
