import {writeFileSync} from 'node:fs';
import {simulateIntensiveFarm} from '../tools/check_intensive_farm.mjs';
import {serialize} from '../src/persistence/snapshots.js';
let previous=null,poses=new Map(),captured=false;
try{simulateIntensiveFarm({days:9,seed:712,biome:'desierto',culture:'suajili',mixed:true,onTick(s,nav){
 if(s.day!==9||!s.raid||captured)return;
 const actor=s.raid.animals.find(a=>a.id==='animal-8183');
 if(actor&&!nav.terrainValid(actor.x,actor.z,actor.radius,false)){
  captured=true;
  writeFileSync('.cache/suajili9-first-unsafe-state.json',serialize(s));
  if(previous)writeFileSync('.cache/suajili9-before-unsafe-state.json',previous);
  const before=poses.get(actor.id);
  writeFileSync('.cache/suajili9-first-unsafe.json',JSON.stringify({day:s.day,time:s.time,elapsed:s.elapsed,version:nav.version,actor,before,beforeTerrainValid:before?nav.terrainValid(before.x,before.z,actor.radius,false):null},null,2)+'\n');
  console.log(JSON.stringify({captured:true,time:s.time,actor:actor.id,beforeTerrainValid:before?nav.terrainValid(before.x,before.z,actor.radius,false):null}));
  return;
 }
 previous=serialize(s);poses=new Map(s.raid.animals.map(a=>[a.id,structuredClone(a)]));
}});}catch(e){console.log(JSON.stringify({originalTerminalFailure:e.message.slice(0,120),captured}));}
