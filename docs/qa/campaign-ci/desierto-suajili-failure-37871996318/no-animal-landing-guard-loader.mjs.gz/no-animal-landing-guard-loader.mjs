import {readFileSync} from 'node:fs';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
const target=pathToFileURL(resolve('src/simulation/animal-route-clearance.js')).href;
export async function load(url,context,nextLoad){
 if(url===target)return {format:'module',source:readFileSync('.cache/animal-route-clearance-before.mjs','utf8'),shortCircuit:true};
 return nextLoad(url,context);
}
