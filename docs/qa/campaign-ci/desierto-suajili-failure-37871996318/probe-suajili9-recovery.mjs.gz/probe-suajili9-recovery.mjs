import {readFileSync} from 'node:fs';
import {deserialize} from '../src/persistence/snapshots.js';
import {Navigation} from '../src/world/navigation.js';
import {workerSlopeRecoveryPath} from '../src/world/worker-slope-recovery.js';
const dir='C:/Users/PC/.codex/worktrees/raid-fractional-exit/wild-guardians-africa/.cache/desierto-suajili-37871996318/';
const s=deserialize(readFileSync(dir+'desierto-suajili-failure-state.json','utf8'));
const pack=JSON.parse(readFileSync('public/content/biome-desert.json','utf8'));
const nav=new Navigation(s.seed,s.biome,pack.profile);nav.setState(s);
const actor=s.raid.animals.find(a=>a.status==='retreating');
// Diagnostic only: reuse the approved marginal-worker recovery recipe while
// routing/collision checks retain animal semantics (including shields/gates).
const view=Object.create(nav);
view.path=(a,b,r,ignore)=>nav.path(a,b,r,ignore,false);
view.walkable=(x,z,r,ignore)=>nav.walkable(x,z,r,ignore,false);
view.workerMotionClear=function(a,b,r){return this.testSegmentClear(a,b,r,null,false);};
const start=performance.now(),path=workerSlopeRecoveryPath(view,actor,actor.exit,actor.radius);
console.log(JSON.stringify({milliseconds:performance.now()-start,actor:{x:actor.x,z:actor.z,radius:actor.radius},terrainValid:nav.terrainValid(actor.x,actor.z,actor.radius,false),path},null,2));
