import{readFileSync,writeFileSync}from'node:fs';import{gunzipSync}from'node:zlib';import{deserialize}from'../src/persistence/snapshots.js';import{Navigation}from'../src/world/navigation.js';import{walkTo}from'../src/simulation/game.js';import{LOCOMOTION as L}from'../src/simulation/locomotion-calibration.js';
const s=deserialize(gunzipSync(readFileSync('docs/qa/intensive-sabana-musgum-e461b550/state.json.gz')).toString());const n=new Navigation(s.seed,s.biome,JSON.parse(readFileSync('public/content/biome-savanna.json')).profile);n.setState(s);
const points=JSON.parse(gunzipSync(readFileSync('docs/qa/watering-large-farm-return/attribution.json.gz'))).navigation.failureSamples;let result=null,attempts=0;
search:for(const q of points)for(let angle=0;angle<32;angle++)for(const a of [.025,.05,.075,.1])for(const b of [.025,.05,.075,.1]){
 attempts++;const x=Math.sin(angle*Math.PI/16),z=Math.cos(angle*Math.PI/16),start={x:q.start.x-x*a,z:q.start.z-z*a},end={x:q.start.x+x*b,z:q.start.z+z*b,id:'probe-end'};
 if(!n.walkable(start.x,start.z,.28,null,true)||!n.walkable(end.x,end.z,.28,null,true)||!n.segmentClear(start,end,.28,null,true))continue;
 const worker={...start,id:'probe-worker',status:'walking',radius:.28};const reached=walkTo({structures:s.structures,workers:[worker]},worker,end,a/L.walkMetresPerSecond,n);
 result={sourceWorkerId:q.start.id,attempts,start,end,expectedInvalid:q.start,worker,reached,startValid:n.walkable(start.x,start.z,.28,null,true),endValid:n.walkable(end.x,end.z,.28,null,true),segmentAccepted:true,actualPointValid:n.walkable(worker.x,worker.z,.28,null,true),dt:a/L.walkMetresPerSecond};break search;
}
writeFileSync('.cache/watering-slope-integrated/segment-alias-probe.json',JSON.stringify({scope:'Isolated local reproduction on unmodified native terrain and obstacles. Constructed connector and worker test doubles; not a replay of the original historical trajectory.',attempts,result},null,2)+'\n');console.log(JSON.stringify(result,null,2));
