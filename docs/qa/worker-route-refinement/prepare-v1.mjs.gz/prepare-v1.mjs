import assert from'node:assert/strict';import{readFileSync,writeFileSync,mkdirSync}from'node:fs';import{pathToFileURL}from'node:url';import{resolve}from'node:path';
const dir=resolve('.cache/worker-route-refinement');mkdirSync(dir,{recursive:true});const url=new URL('../src/world/navigation.js',import.meta.url);let source=readFileSync(url,'utf8');
const canyon='if(Math.hypot(surface(x+dx+.8,z+dz)-surface(x+dx-.8,z+dz),surface(x+dx,z+dz+.8)-surface(x+dx,z+dz-.8))/1.6>.5)return false;';
const regular='}else if(this.field.slope(x+dx,z+dz)>.5)return false;';assert.equal(source.split(canyon).length,2);assert.equal(source.split(regular).length,2);
source=source.replace(canyon,'const value=Math.hypot(surface(x+dx+.8,z+dz)-surface(x+dx-.8,z+dz),surface(x+dx,z+dz+.8)-surface(x+dx,z+dz-.8))/1.6;if(this.qaSweep)this.qaSweep.peak=Math.max(this.qaSweep.peak,value);if(value>.5)return false;').replace(regular,'}else {const value=this.field.slope(x+dx,z+dz);if(this.qaSweep)this.qaSweep.peak=Math.max(this.qaSweep.peak,value);if(value>.5)return false;}');
const needle='  testSegmentClear(start,end,radius,ignore,worker,escapeProps=false) {';assert.equal(source.split(needle).length,2);
const wrapper=`  testSegmentClear(start,end,radius,ignore,worker,escapeProps=false) {
    if(!worker)return this.coarseSegmentClear(start,end,radius,ignore,worker,escapeProps);
    this.qaRefinement??={checks:0,cacheHits:0,fineSegments:0,finePoints:0,rejected:0};
    if(this.qaRefinedVersion!==this.version){this.qaRefinedVersion=this.version;this.qaRefinedCache=new Map();}
    const key=JSON.stringify([start.x,start.z,end.x,end.z,radius,ignore,worker,escapeProps]);this.qaRefinement.checks++;
    if(this.qaRefinedCache.has(key)){this.qaRefinement.cacheHits++;return this.qaRefinedCache.get(key);}
    const previous=this.qaSweep,sweep={peak:0};this.qaSweep=sweep;let valid;
    try{valid=this.coarseSegmentClear(start,end,radius,ignore,worker,escapeProps);}finally{this.qaSweep=previous;}
    if(valid&&sweep.peak>=.46){this.qaRefinement.fineSegments++;const steps=Math.max(1,Math.ceil(distance(start,end)/.025));
      for(let i=1;i<steps;i++){this.qaRefinement.finePoints++;if(!this.terrainValid(start.x+(end.x-start.x)*i/steps,start.z+(end.z-start.z)*i/steps,radius,worker)){valid=false;this.qaRefinement.rejected++;break;}}
    }
    if(this.qaRefinedCache.size>=10000)evictOldest(this.qaRefinedCache);this.qaRefinedCache.set(key,valid);return valid;
  }
  coarseSegmentClear(start,end,radius,ignore,worker,escapeProps=false) {`;
source=source.replace(needle,wrapper).replace(/from '([^']+)'/g,(m,p)=>p.startsWith('.')?`from '${new URL(p,url).href}'`:m);
writeFileSync(resolve(dir,'candidate-navigation.mjs'),source);console.log('Generated QA-only adaptive route navigator');
