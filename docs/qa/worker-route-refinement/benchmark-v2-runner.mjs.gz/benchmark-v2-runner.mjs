import assert from'node:assert/strict';import{readFileSync,writeFileSync,mkdirSync}from'node:fs';import{gunzipSync}from'node:zlib';import{pathToFileURL}from'node:url';import{resolve}from'node:path';import{createHash}from'node:crypto';
import * as Original from '../src/simulation/game.js';import{Navigation}from'../src/world/navigation.js';import{deserialize,serialize}from'../src/persistence/snapshots.js';import{numberOf}from'../src/simulation/money.js';
import{Navigation as RefinedNavigation}from'./worker-route-refinement/candidate-navigation-v2.mjs';
const Candidate=Original;const dir=resolve('.cache/worker-route-refinement');const game=readFileSync(new URL('../src/simulation/game.js',import.meta.url),'utf8');const idle=readFileSync(new URL('../src/world/navigation.js',import.meta.url),'utf8');const candidate=readFileSync(resolve(dir,'candidate-navigation-v2.mjs'),'utf8');
const raw=gunzipSync(readFileSync('docs/qa/intensive-sabana-musgum-e461b550/state.json.gz')).toString(),profile=JSON.parse(readFileSync('public/content/biome-savanna.json')).profile;
const hash=s=>createHash('sha256').update(s).digest('hex'),median=x=>{const a=[...x].sort((a,b)=>a-b);return a[Math.floor(a.length/2)];};const runs=[];
for(const mode of ['reference','candidate','candidate','reference']){
 const Game=mode==='reference'?Original:Candidate,s=deserialize(raw),nav=new (mode==='reference'?Navigation:RefinedNavigation)(s.seed,s.biome,profile);nav.setState(s);Game.continuePostgame(s);const staff=Math.ceil(s.plants.filter(p=>p.alive).length/12);Game.hire(s,'qa-watering-diagnostic-hire',{olderFemale:staff});assert.equal(s.pauses.length,0);
 const ms=[],hashes=[];
 for(let i=0;i<100;i++){const before=performance.now();Game.tick(s,.1,nav);const duration=performance.now()-before;if(i>=25)ms.push(duration);hashes.push(hash(serialize(s)));}
 runs.push({mode,staff,refinement:nav.qaRefinement??null,measuredTicks:75,warmupTicks:25,medianMs:median(ms),totalMs:ms.reduce((a,b)=>a+b,0),samplesMs:ms,hashes,final:{time:s.time,living:s.plants.filter(p=>p.alive).length,tasks:s.tasks.length}});
 console.log(JSON.stringify({mode,medianMs:runs.at(-1).medianMs,refinement:runs.at(-1).refinement}));
}
const baseline=runs[0].hashes,firstDivergence=runs.map(r=>r.hashes.findIndex((h,i)=>h!==baseline[i]));
const report={scope:'QA-only adaptive route refinement near slope threshold>=0.46 at 0.025m with 10000-key static cache owned per navigator, reset by setState and retained by crop-only placement. Same Game runtime in both modes; no production change. Not mathematical terrain continuity or full biome acceptance. Native historical farm, ordinary paid hiring, 100 ticks each in ABBA. 25 warmup and75 measured. Serialization/hash outside timing. Four concurrent campaigns; CPU wall tick measurements, not GPU/frame/phone acceptance.',sourceHashes:{game:hash(game),idle:hash(idle),candidate:hash(candidate)},runs,firstDivergence,referenceMedian:median(runs.filter(r=>r.mode==='reference').flatMap(r=>r.samplesMs)),candidateMedian:median(runs.filter(r=>r.mode==='candidate').flatMap(r=>r.samplesMs))};
writeFileSync(resolve(dir,'report-v2.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({firstDivergence,referenceMedian:report.referenceMedian,candidateMedian:report.candidateMedian}));

