import assert from'node:assert/strict';import{readFileSync,writeFileSync}from'node:fs';
const file='.cache/worker-route-refinement/candidate-navigation.mjs';let source=readFileSync(file,'utf8');
const condition='if(this.qaRefinedVersion!==this.version){this.qaRefinedVersion=this.version;this.qaRefinedCache=new Map();}';assert.equal(source.split(condition).length,2);
source=source.replace(condition,"if(!Object.hasOwn(this,'qaRefinedCache'))this.qaRefinedCache=new Map();");
const set='  setState(state) {';assert.equal(source.split(set).length,2);source=source.replace(set,'  setState(state) {\n    this.qaRefinedCache=new Map();');
writeFileSync('.cache/worker-route-refinement/candidate-navigation-v2.mjs',source);
let probe=readFileSync('.cache/probe-refinement-cache-owner.mjs','utf8').replace('candidate-navigation.mjs','candidate-navigation-v2.mjs').replace('cache-owner.json','cache-owner-v2.json');writeFileSync('.cache/probe-refinement-cache-owner-v2.mjs',probe);
