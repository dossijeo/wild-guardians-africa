import assert from'node:assert/strict';import{readFileSync,writeFileSync}from'node:fs';import{gunzipSync}from'node:zlib';import{deserialize}from'../src/persistence/snapshots.js';import{Navigation}from'./worker-route-refinement/candidate-navigation-v2.mjs';import{walkTo}from'../src/simulation/game.js';
const s=deserialize(gunzipSync(readFileSync('docs/qa/intensive-sabana-musgum-e461b550/state.json.gz')).toString()),nav=new Navigation(s.seed,s.biome,JSON.parse(readFileSync('public/content/biome-savanna.json')).profile);nav.setState(s);
const q=JSON.parse(readFileSync('.cache/watering-slope-integrated/segment-alias-probe.json')).result,w={...q.start,id:'refinement-probe',status:'walking',radius:.28},state={structures:s.structures,workers:[w]};
assert.equal(nav.segmentClear(q.start,q.end,.28,null,true),false);const route=nav.path(w,q.end,.28,null,true);const rows=[];let reached=false;
for(let i=0;i<1000;i++){reached=walkTo(state,w,q.end,.01,nav);const valid=nav.walkable(w.x,w.z,.28,null,true);rows.push({i,x:w.x,z:w.z,valid});if(!valid||reached)break;}
const report={scope:'Isolated native connector on actual terrain/obstacles, constructed worker, ordinary walkTo. Adaptive route refinement candidate only, not campaign or renderer acceptance.',route,reached,allValid:rows.every(r=>r.valid),steps:rows.length,final:w,refinement:nav.qaRefinement,rows};
writeFileSync('.cache/worker-route-refinement/connector-v2.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({route,reached,allValid:report.allValid,steps:rows.length,refinement:report.refinement},null,2));

