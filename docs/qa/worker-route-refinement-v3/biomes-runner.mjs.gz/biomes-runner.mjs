import {readFileSync,writeFileSync} from 'node:fs';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {newGame,walkTo,BIOMES} from '../src/simulation/game.js';
import {Navigation as Reference,BIOME_IDS} from '../src/world/navigation.js';
import {Navigation as Candidate} from './worker-route-refinement/candidate-navigation-v3.mjs';
import {LOCOMOTION as L} from '../src/simulation/locomotion-calibration.js';
const results=[];
function unit(value){let x=value>>>0;x=Math.imul(x^(x>>>16),0x7feb352d);x=Math.imul(x^(x>>>15),0x846ca68b);return ((x^(x>>>16))>>>0)/4294967296;}
function peak(nav,x,z){return Math.max(...[[0,0],[.28,0],[-.28,0],[0,.28],[0,-.28]].map(([dx,dz])=>nav.field.canyon?Math.hypot(nav.workerSurface(x+dx+.8,z+dz)-nav.workerSurface(x+dx-.8,z+dz),nav.workerSurface(x+dx,z+dz+.8)-nav.workerSurface(x+dx,z+dz-.8))/1.6:nav.field.slope(x+dx,z+dz)));}
for(const biome of BIOMES){
 const state=newGame({biome,culture:'mapungubwe',seed:712,slotId:'qa-segment-'+biome}),profile=JSON.parse(readFileSync('public/content/biome-'+BIOME_IDS[biome]+'.json')).profile;
 const ref=new Reference(712,biome,profile),candidate=new Candidate(712,biome,profile);ref.setState(state);candidate.setState(structuredClone(state));
 let scanned=0,riskPoints=0,maxPeak=0;const cases=[];
 for(let i=1;i<=8192&&cases.length<32;i++){
  scanned++;const x=unit(i)*320-160,z=unit(i^0x351913)*320-160,slope=peak(ref,x,z);maxPeak=Math.max(maxPeak,slope);
  if((slope<.46&&biome!=='manglares')||slope>.5||!ref.walkable(x,z,.28,null,true))continue;if(slope>=.46)riskPoints++;
  for(const length of [3,1,.3,.1])for(let angle=0;angle<8&&cases.length<32;angle++){
   const a={x,z},end={id:'qa-end',x:x+Math.sin(angle*Math.PI/4)*length,z:z+Math.cos(angle*Math.PI/4)*length};
   if(!ref.segmentClear(a,end,.28,null,true))continue;
   const accepted=candidate.segmentClear(a,end,.28,null,true),runs=[];
   for(const [mode,nav] of [['reference',ref],['candidate',candidate]]){
    if(mode==='candidate'&&!accepted)continue;
    for(const dt of [.01,.1,.25,.5]){
     const worker={id:'qa-worker',status:'walking',radius:.28,x,z,path:[{x:end.x,z:end.z}],pathVersion:nav.version,destinationId:end.id},sim={structures:[],workers:[worker]};let reached=false;const violations=[];let steps=0;
     for(;steps<Math.ceil(length/(L.walkMetresPerSecond*dt))+3;steps++){
      const before={x:worker.x,z:worker.z};reached=walkTo(sim,worker,end,dt,nav);
      assert(Math.hypot(worker.x-before.x,worker.z-before.z)<=L.walkMetresPerSecond*dt+1e-8);
      if(!nav.walkable(worker.x,worker.z,.28,null,true))violations.push({step:steps,x:worker.x,z:worker.z,peak:peak(nav,worker.x,worker.z)});
      if(reached)break;
     }
     runs.push({mode,dt,reached,steps:steps+1,violations});
    }
   }
   cases.push({start:a,end,length,slope,candidateAccepted:accepted,runs});
  }
 }
 const row={biome,scanned,riskPoints,maxPeak,cases,summary:{cases:cases.length,rejected:cases.filter(c=>!c.candidateAccepted).length,referenceViolations:cases.flatMap(c=>c.runs).filter(r=>r.mode==='reference').reduce((n,r)=>n+r.violations.length,0),candidateViolations:cases.flatMap(c=>c.runs).filter(r=>r.mode==='candidate').reduce((n,r)=>n+r.violations.length,0)}};
 results.push(row);console.log(JSON.stringify({biome,...row.summary,scanned,riskPoints}));
}
writeFileSync('.cache/worker-route-refinement/biomes-v3.json',JSON.stringify({scope:'QA controlled walking connectors on native terrain/props for six biomes, seed712 Mapungubwe newGame metadata; buildings are not populated, terrainSite remains absent, no farm or campaign. Up to32 original-accepted near-slope connectors per biome; mangrove uses ordinary low-slope connectors because initial risk search found none. Candidate rejection is not proof of an alternate route. No timing, continuous sweep or renderer acceptance.',sourceSha256:createHash('sha256').update(readFileSync('.cache/worker-route-refinement/candidate-navigation-v3.mjs')).digest('hex'),results},null,2)+'\n');
