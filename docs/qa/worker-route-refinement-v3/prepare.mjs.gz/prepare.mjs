import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
const source=readFileSync('.cache/worker-route-refinement/candidate-navigation-v2.mjs','utf8');
assert.equal(source.split('distance(start,end)/.025').length,2);
writeFileSync('.cache/worker-route-refinement/candidate-navigation-v3.mjs',source.replace('distance(start,end)/.025','distance(start,end)/.01')+'\r\n');
for(const [input,output] of [
 ['.cache/check-refinement-native-quality.mjs','.cache/check-refinement-native-quality-v3.mjs'],
 ['.cache/benchmark-worker-route-refinement-v2.mjs','.cache/benchmark-worker-route-refinement-v3.mjs'],
 ['.cache/probe-worker-route-refinement-v2.mjs','.cache/probe-worker-route-refinement-v3.mjs']]){
 let code=readFileSync(input,'utf8').replaceAll('candidate-navigation-v2.mjs','candidate-navigation-v3.mjs').replaceAll('quality-v2.json','quality-v3.json').replaceAll('report-v2.json','report-v3.json').replaceAll('connector-v2.json','connector-v3.json').replaceAll('0.025m','0.01m').replace('sourceHashes:{game:hash(game),idle:hash(idle)','sourceHashes:{game:hash(game),navigation:hash(idle)');
 writeFileSync(output,code+'\r\n');
}
let native=readFileSync('.cache/check-worker-slope-native.mjs','utf8');
native=native.replace("import{Navigation,BIOME_IDS}from'../src/world/navigation.js';","import{BIOME_IDS}from'../src/world/navigation.js';\nimport{Navigation}from'./worker-route-refinement/candidate-navigation-v3.mjs';");
native=native.replace("'.cache/watering-slope-integrated/native-return.json'","'.cache/worker-route-refinement/native-return-v3.json'");
writeFileSync('.cache/check-worker-slope-native-v3.mjs',native);
