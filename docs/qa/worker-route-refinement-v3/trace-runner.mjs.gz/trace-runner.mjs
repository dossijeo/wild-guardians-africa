import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import * as Game from '../src/simulation/game.js';
import {deserialize,serialize} from '../src/persistence/snapshots.js';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {Navigation} from './worker-route-refinement/candidate-navigation-v2.mjs';
const s=deserialize(gunzipSync(readFileSync('docs/qa/intensive-sabana-musgum-e461b550/state.json.gz')).toString());
const nav=new Navigation(s.seed,s.biome,JSON.parse(readFileSync('public/content/biome-savanna.json')).profile);nav.setState(s);
Game.continuePostgame(s);Game.hire(s,'qa-watering-diagnostic-hire',{olderFemale:Math.ceil(s.plants.filter(p=>p.alive).length/12)});
const rows=[],calls=[];let tick=0;
const original=nav.testSegmentClear;
nav.testSegmentClear=function(a,b,...args){const result=original.call(this,a,b,...args);if(a.id==='worker-53147'||Math.hypot(a.x-112.7958,a.z-9.8645)<.4)calls.push({tick,a:{x:a.x,z:a.z,id:a.id},b:{x:b.x,z:b.z},args,result});return result;};
const hash=state=>createHash('sha256').update(serialize(state)).digest('hex');
function record(){const w=s.workers.find(w=>w.id==='worker-53147');rows.push({tick,stateSha256:hash(s),worker:structuredClone(w),valid:nav.walkable(w.x,w.z,.28,null,true),slope:Math.max(...[[0,0],[.28,0],[-.28,0],[0,.28],[0,-.28]].map(([dx,dz])=>nav.field.slope(w.x+dx,w.z+dz)))});}
record();for(tick=1;tick<=4;tick++){Game.tick(s,.1,nav);record();}
const baseline=deserialize(gunzipSync(readFileSync('docs/qa/intensive-sabana-musgum-e461b550/state.json.gz')).toString()),plain=new Navigation(baseline.seed,baseline.biome,JSON.parse(readFileSync('public/content/biome-savanna.json')).profile);plain.setState(baseline);Game.continuePostgame(baseline);Game.hire(baseline,'qa-watering-diagnostic-hire',{olderFemale:Math.ceil(baseline.plants.filter(p=>p.alive).length/12)});
const baselineHashes=[];for(let i=0;i<=4;i++){if(i)Game.tick(baseline,.1,plain);baselineHashes.push(hash(baseline));assert.equal(baselineHashes[i],rows[i].stateSha256);const w=baseline.workers.find(w=>w.id==='worker-53147');plain.walkable(w.x,w.z,.28,null,true);}
writeFileSync('.cache/worker-route-refinement/landing-trace.json',JSON.stringify({scope:'Four ordinary ticks, observed and unwrapped candidate V2, full serialized state parity each tick including initial state; worker snapshots outside simulation.',baselineHashes,rows,calls},null,2)+'\n');
console.log(JSON.stringify(rows.map(r=>({tick:r.tick,valid:r.valid,slope:r.slope,x:r.worker.x,z:r.worker.z,path:r.worker.path,status:r.worker.status})),null,2));

