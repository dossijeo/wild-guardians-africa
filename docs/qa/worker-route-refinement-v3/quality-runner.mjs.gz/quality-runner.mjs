import{readFileSync,writeFileSync}from'node:fs';import{gunzipSync}from'node:zlib';import * as Game from'../src/simulation/game.js';import{deserialize}from'../src/persistence/snapshots.js';import{Navigation as Refined}from'./worker-route-refinement/candidate-navigation-v3.mjs';import{Navigation as Original}from'../src/world/navigation.js';
const raw=gunzipSync(readFileSync('docs/qa/intensive-sabana-musgum-e461b550/state.json.gz')).toString(),profile=JSON.parse(readFileSync('public/content/biome-savanna.json')).profile,results=[];
for(const [mode,Class]of[['reference',Original],['candidate',Refined]]){
 const s=deserialize(raw),nav=new Class(s.seed,s.biome,profile);nav.setState(s);Game.continuePostgame(s);Game.hire(s,'qa-watering-diagnostic-hire',{olderFemale:Math.ceil(s.plants.filter(p=>p.alive).length/12)});
 const rows=[],samples=[];let violations=0;
 for(let tick=1;tick<=100;tick++){
  const validBefore=new Set(s.workers.filter(w=>w.status!=='home'&&nav.walkable(w.x,w.z,w.radius??.28,null,true)).map(w=>w.id));Game.tick(s,.1,nav);
  let newlyInvalid=0;for(const w of s.workers)if(validBefore.has(w.id)&&w.status!=='home'&&!nav.walkable(w.x,w.z,w.radius??.28,null,true)){newlyInvalid++;violations++;if(samples.length<20)samples.push({tick,id:w.id,status:w.status,x:w.x,z:w.z});}
  rows.push({tick,newlyInvalid});
 }
 results.push({mode,violations,samples,rows});
}
const report={scope:'QA quality continuation,100 ordinary ticks per mode; checks outside simulation, no CPU timing. Tracks valid-before workers that become invalid after the tick, not continuous collision proof or full campaign acceptance.',results};writeFileSync('.cache/worker-route-refinement/quality-v3.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(results.map(r=>({mode:r.mode,violations:r.violations,first:r.samples[0]}))));

