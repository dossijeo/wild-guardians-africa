import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {deserialize} from '../src/persistence/snapshots.js';
import {Navigation} from './worker-route-refinement/candidate-navigation-v2.mjs';
const s=deserialize(gunzipSync(readFileSync('docs/qa/intensive-sabana-musgum-e461b550/state.json.gz')).toString());
const nav=new Navigation(s.seed,s.biome,JSON.parse(readFileSync('public/content/biome-savanna.json')).profile);nav.setState(s);
const trace=JSON.parse(readFileSync('.cache/worker-route-refinement/landing-trace.json'));
const first=trace.rows[1].worker,start=first.path[0],end=first.path[1],length=Math.hypot(end.x-start.x,end.z-start.z);
const rows=[];for(let i=0;i<=300;i++){const d=i*.001,x=start.x+(end.x-start.x)*d/length,z=start.z+(end.z-start.z)*d/length;rows.push({d,x,z,valid:nav.terrainValid(x,z,.28,true),peak:Math.max(...[[0,0],[.28,0],[-.28,0],[0,.28],[0,-.28]].map(([dx,dz])=>nav.field.slope(x+dx,z+dz)))});}
const grids=[.25,.025,.01,.005].map(interval=>{const count=Math.ceil(length/interval),hits=[];for(let i=0;i<=count;i++){const d=length*i/count;if(d>.3)break;const x=start.x+(end.x-start.x)*i/count,z=start.z+(end.z-start.z)*i/count;hits.push({d,valid:nav.terrainValid(x,z,.28,true)});}return {interval,count,hits,rejects:hits.filter(p=>!p.valid).length};});
const report={scope:'QA native accepted connector prefix,1mm diagnostic grid. Not continuous proof or performance claim.',start,end,length,accepted:nav.segmentClear(start,end,.28,null,true),invalidRows:rows.filter(r=>!r.valid),grids};
assert(report.accepted);assert(report.invalidRows.length);assert.equal(grids[1].rejects,0);
writeFileSync('.cache/worker-route-refinement/missed-strip.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({length,accepted:report.accepted,invalidFrom:report.invalidRows[0],invalidTo:report.invalidRows.at(-1),invalidSamples:report.invalidRows.length,grids:grids.map(({interval,count,rejects})=>({interval,count,rejects}))},null,2));
