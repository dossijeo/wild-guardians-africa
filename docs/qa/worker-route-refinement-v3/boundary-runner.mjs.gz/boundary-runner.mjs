import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {deserialize} from '../src/persistence/snapshots.js';
import {Navigation} from './worker-route-refinement/candidate-navigation-v3.mjs';
import {walkTo} from '../src/simulation/game.js';
const s=deserialize(gunzipSync(readFileSync('docs/qa/intensive-sabana-musgum-e461b550/state.json.gz')).toString()),nav=new Navigation(s.seed,s.biome,JSON.parse(readFileSync('public/content/biome-savanna.json')).profile);nav.setState(s);
let tested=0,accepted=0,failure=null;
outer:for(let zi=0;zi<120;zi++)for(let xi=0;xi<20;xi++){
 const start={x:112.74+xi*.0005,z:9.84+zi*.0005},end={id:'qa-end',x:start.x+.1,z:start.z};tested++;
 if(!nav.walkable(start.x,start.z,.28,null,true)||!nav.segmentClear(start,end,.28,null,true))continue;accepted++;
 const worker={...start,id:'qa-worker',radius:.28,status:'walking'},sim={structures:s.structures,workers:[worker]},rows=[];
 for(let i=0;i<20;i++){const reached=walkTo(sim,worker,end,.01,nav),valid=nav.walkable(worker.x,worker.z,.28,null,true);rows.push({i,x:worker.x,z:worker.z,valid,reached});if(!valid){failure={start,end,dt:.01,rows,path:worker.path};break outer;}if(reached)break;}
}
if(failure){const last=failure.rows.at(-1);failure.peak=Math.max(...[[0,0],[.28,0],[-.28,0],[0,.28],[0,-.28]].map(([dx,dz])=>nav.field.slope(last.x+dx,last.z+dz)));const count=Math.ceil(Math.hypot(failure.end.x-failure.start.x,failure.end.z-failure.start.z)/.01);failure.plannerSamples=Array.from({length:count+1},(_,i)=>{const x=failure.start.x+(failure.end.x-failure.start.x)*i/count,z=failure.start.z+(failure.end.z-failure.start.z)*i/count;return {x,z,valid:nav.terrainValid(x,z,.28,true)};});}
const result={scope:'QA native Sabana/Musgum field/props/buildings, constructed single walking worker and nearby horizontal connectors around recorded narrow-slope problem; ordinary nav.path and walkTo, no terrain overrides. No timing or campaign acceptance.',tested,accepted,failure};
writeFileSync('.cache/worker-route-refinement/boundary-v3.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));
