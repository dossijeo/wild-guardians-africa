import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import * as Game from '../src/simulation/game.js';
import {deserialize,serialize} from '../src/persistence/snapshots.js';
import {Navigation} from './worker-route-refinement/candidate-navigation-v3.mjs';
const raw=gunzipSync(readFileSync('docs/qa/intensive-sabana-musgum-e461b550/state.json.gz')).toString(),profile=JSON.parse(readFileSync('public/content/biome-savanna.json')).profile,results=[];
for(const dt of [.01,.025,.05,.25,.5]){
 const s=deserialize(raw),nav=new Navigation(s.seed,s.biome,profile);nav.setState(s);Game.continuePostgame(s);Game.hire(s,'qa-watering-diagnostic-hire',{olderFemale:Math.ceil(s.plants.filter(p=>p.alive).length/12)});
 const samples=[];let violations=0;
 for(let tick=1;tick<=100;tick++){
  const validBefore=new Set(s.workers.filter(w=>w.status!=='home'&&nav.walkable(w.x,w.z,w.radius??.28,null,true)).map(w=>w.id));Game.tick(s,dt,nav);
  for(const w of s.workers)if(validBefore.has(w.id)&&w.status!=='home'&&!nav.walkable(w.x,w.z,w.radius??.28,null,true)){violations++;if(samples.length<30)samples.push({tick,id:w.id,status:w.status,x:w.x,z:w.z});}
 }
 const row={dt,ticks:100,simulatedSeconds:100*dt,violations,samples,finalSha256:createHash('sha256').update(serialize(s)).digest('hex')};results.push(row);console.log(JSON.stringify(row));
}
writeFileSync('.cache/worker-route-refinement/time-steps-v3.json',JSON.stringify({scope:'QA100 ordinary ticks per dt on one native historical Sabana/Musgum farm with paid112 olderFemale hiring; valid-before to invalid-after worker observations outside tick. Different simulated durations; no cost measurement, continuous proof or identical-work comparison.',results},null,2)+'\n');
