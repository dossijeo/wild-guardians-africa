import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
const [workerPath,cachePath,out]=process.argv.slice(2);
assert(workerPath&&cachePath&&out);
const worker=pathToFileURL(resolve(workerPath)+'/'),cache=pathToFileURL(resolve(cachePath)+'/');
const source=readFileSync(new URL('src/simulation/game.js',worker),'utf8');
assert(!source.includes('import.meta'));
const modified=source.replace(/from '([^']+)'/g,(_match,spec)=>`from '${spec==='../world/work-points.js'?new URL('src/world/work-points.js',cache).href:spec.startsWith('.')?new URL(spec,new URL('src/simulation/game.js',worker)).href:spec}'`);
const A=await import(new URL('src/simulation/game.js',worker));
const B=await import('data:text/javascript;base64,'+Buffer.from(modified).toString('base64'));
const {Navigation,BIOME_IDS}=await import(new URL('src/world/navigation.js',worker));
const {deserialize,serialize}=await import(new URL('src/persistence/snapshots.js',worker));
const hash=b=>createHash('sha256').update(b).digest('hex');
const rows=[];
function nav(s){const profile=JSON.parse(readFileSync(new URL('public/content/biome-'+BIOME_IDS[s.biome]+'.json',worker))).profile;const n=new Navigation(s.seed,s.biome,profile);n.setState(s);return n;}
for(const reload of [false,true]){
 const bytes=gunzipSync(readFileSync(new URL('tests/fixtures/worker-fractional-departure/state.json.gz',worker))),initial=deserialize(bytes.toString());
 initial.result=null;initial.pauses=[];initial.time=400;initial.raid=null;initial.spells=[];
 initial.dayPlan={at:0,done:true,group:[]};initial.nightPlan={at:500,done:true,group:[]};
 initial.plants=[];initial.tasks=[];initial.crates=[];initial.workers=[initial.workers[0]];
 let a=deserialize(serialize(initial)),b=deserialize(serialize(initial)),na=nav(a),nb=nav(b),ticks=0;
 while(a.workers[0].status!=='home'&&ticks<1200){
  A.tick(a,.1,na);B.tick(b,.1,nb);ticks++;
  assert.equal(serialize(b),serialize(a),'Combined departure state diverged at '+ticks);
  if(reload&&ticks===100){a=deserialize(serialize(a));b=deserialize(serialize(b));na=nav(a);nb=nav(b);}
 }
 assert.equal(a.workers[0].status,'home');assert.equal(b.workers[0].status,'home');
 rows.push({kind:'isolated fractional departure',reload,ticks,allStatesIdentical:true,fixtureHash:hash(bytes)});
}
for(const suffix of ['1','10']){
 const bytes=gunzipSync(readFileSync(new URL('tests/fixtures/watering-gran-canon-saheliana-detour-'+suffix+'.json.gz',cache)));
 let a=deserialize(bytes.toString()),b=deserialize(bytes.toString()),na=nav(a),nb=nav(b);
 for(let tick=0;tick<300;tick++){
  A.tick(a,.1,na);B.tick(b,.1,nb);assert.equal(serialize(b),serialize(a),'Combined watering state diverged');
  if(tick===149){a=deserialize(serialize(a));b=deserialize(serialize(b));na=nav(a);nb=nav(b);}
 }
 rows.push({kind:'native Canyon watering',suffix,ticks:300,reloadAtTick:150,allStatesIdentical:true,fixtureHash:hash(bytes)});
}
const paths={worker:['src/simulation/game.js','src/world/navigation.js','src/world/worker-fractional-connector.js'],cache:['src/world/work-points.js','src/world/watering-route-cache.js']};
const sourceHashes=Object.fromEntries(Object.entries(paths).flatMap(([label,paths])=>paths.map(p=>[label+':'+p,hash(readFileSync(new URL(p,label==='worker'?worker:cache)))])));
writeFileSync(out,JSON.stringify({observedAt:new Date().toISOString(),scope:'In-memory composition of PR25 worker Game/Navigation with PR26 work-points. No worktree runtime or live campaign mutation. Isolated departure fixture clears terminal state and unrelated simulation systems; it is not a campaign revival. Functional state equality, not performance measurement.',sourceHashes,rows},null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(rows));
