import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {deserialize,serialize} from '../src/persistence/snapshots.js';
import {Navigation,BIOME_IDS} from '../src/world/navigation.js';
import * as Game from '../src/simulation/game.js';
import {nativeStablePlanPerimeterProof} from '../tools/native-stable-plan-perimeter-proof.mjs';
import {nativeWorkerServiceProofV3} from '../tools/native-worker-service-proof-v3.mjs';

test('native gate-phase reuse never carries protection across an opened proposed perimeter',()=>{
 const root=new URL('../docs/qa/integrated-spiritual-survival/campaign-v115-q15-good-sabana-123-hundred/',import.meta.url);
 const state=deserialize(gunzipSync(readFileSync(new URL('partial-state.json.gz',root))).toString());
 const trace=JSON.parse(readFileSync(new URL('partial.json',root))).receipts.defense.planned;
 const profile=JSON.parse(readFileSync(new URL('../public/content/biome-'+BIOME_IDS[state.biome]+'.json',import.meta.url))).profile;
 const nav=new Navigation(state.seed,state.biome,profile);nav.setState(state);
 const options={outline:trace.points,workersFirst:true,incrementalCrops:true,workerServiceProof:nativeWorkerServiceProofV3,gateAnimationInvariant:true};
 const quote=Game.quoteWallChain(state,'zarzas',trace.points,nav,{smooth:false,snap:false});
 assert.equal(quote.pieces.length,1,'Retained fixture has one missing closing piece');
 const before=serialize(state),cold=nativeStablePlanPerimeterProof(state,nav,quote,trace.bounds,options);
 assert(cold.valid,cold.reason);assert.equal(serialize(state),before);
 const gates=state.structures.filter(w=>w.kind==='wall'&&w.gate);assert(gates.length);
 for(const gate of gates)gate.gateOpen=1;
 const current=serialize(state),warm=nativeStablePlanPerimeterProof(state,nav,quote,trace.bounds,options);
 assert(warm.valid,warm.reason);assert.equal(serialize(state),current);
 // Withhold the closing piece: geometry must no longer inherit the positive
 // certificate, even though the other structures and gate identity persist.
 const open={...quote,pieces:[],previewPieces:[],updates:[]};
 const candidate=nativeStablePlanPerimeterProof(state,nav,open,trace.bounds,options);
 const baseline=nativeStablePlanPerimeterProof(state,nav,open,trace.bounds,{...options,gateAnimationInvariant:false,cache:false});
 assert.equal(candidate.valid,false,'Missing closing piece cannot remain certified');
 assert.equal(candidate.reason,baseline.reason);assert.equal(baseline.valid,false);
 assert.equal(serialize(state),current,'QA certification cannot build walls or damage crops');
});
