import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import * as Game from './src/simulation/game.js';
import {Navigation,BIOME_IDS} from './src/world/navigation.js';
import {deserialize,serialize} from './src/persistence/snapshots.js';
import {uncachedWateringControl} from './tools/watering-cache-control-game.mjs';
assert.equal(typeof global.gc,'function');
const out=process.argv[2];assert(out);
const {engine:Control}=await uncachedWateringControl();
const paths=['src/world/work-points.js','src/world/watering-route-cache.js','src/simulation/game.js','src/world/navigation.js'];
const hash=b=>createHash('sha256').update(b).digest('hex');
const sourceHashes=Object.fromEntries(paths.map(p=>[p,hash(readFileSync(p))]));
const bytes=readFileSync('docs/qa/integrated-spiritual-survival/native-power-50-200-500-v2/fixture-500.json');
const rows=[];
for(const [variant,engine] of [['A',Control],['B',Game],['B',Game],['A',Control]]){
 const s=deserialize(bytes.toString()),profile=JSON.parse(readFileSync(`public/content/biome-${BIOME_IDS[s.biome]}.json`)).profile;
 const nav=new Navigation(s.seed,s.biome,profile);nav.setState(s);
 global.gc();global.gc();const initialHeap=process.memoryUsage().heapUsed;
 let sampledPeakHeap=initialHeap;
 for(let i=0;i<3000;i++){
  engine.tick(s,.1,nav);
  if((i+1)%50===0)sampledPeakHeap=Math.max(sampledPeakHeap,process.memoryUsage().heapUsed);
  if((i+1)%500===0)console.log(JSON.stringify({variant,ticks:i+1}));
 }
 global.gc();global.gc();const retainedHeap=process.memoryUsage().heapUsed;
 const stateHash=hash(serialize(s));if(rows.length)assert.equal(stateHash,rows[0].stateHash);
 rows.push({variant,ticks:3000,initialHeap,retainedHeap,retainedDelta:retainedHeap-initialHeap,sampledPeakHeap,stateHash});
}
for(const [p,h] of Object.entries(sourceHashes))assert.equal(hash(readFileSync(p)),h);
writeFileSync(out,JSON.stringify({observedAt:new Date().toISOString(),sourceHashes,fixtureHash:hash(bytes),rows,scope:'AB/BA process-local JavaScript heap probes with forced GC before/after 300 simulated seconds in a historically pre-funded 500-crop fixture. Peak sampled every 50 ticks, not an absolute peak, OS RAM or GPU/VRAM metric. Active native navigation/state remain alive at after-GC measurement. No campaign mutation or new funding.'},null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(rows));
