import assert from 'node:assert/strict';
import {readFileSync as read,writeFileSync as write,mkdirSync} from 'node:fs';
import {gzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
const root='C:/Users/PC/.codex/worktrees/frontside-model-repair/wild-guardians-africa/';
const dir='docs/qa/frontside-native-inputs/maize-young-independent-v1/';
const sha=b=>createHash('sha256').update(b).digest('hex'),pieces=[];
const report=JSON.parse(read(root+'docs/qa/frontside-model-pilot/crop-runtime-visual-selection.json'));
assert.equal(report.independentProfileSha256,'a24f24e8613eef534cdef5761b09e1826baeeeb7c1560a7fb9c78d8fba9b172d');
assert.equal(report.samples.length,16);assert.equal(report.samples.at(-1).comparisons[2].passes,false);
assert(report.samples.every(s=>s.comparisons.slice(0,2).every(c=>c.passes)));mkdirSync(dir,{recursive:true});
const files=[
 ['docs/qa/frontside-model-pilot/crop-runtime-visual-selection.json','report.json.gz',true],
 ['docs/qa/frontside-model-pilot/crop-runtime-visual-last-frame.png','comparison.png',false],
 ['docs/qa/frontside-model-pilot/local-stem-independent-v1.json','profile.json',false],
 ['docs/qa/frontside-model-pilot/local-stem-independent-v1.md','prospective-plan.md',false],
 ['docs/qa/frontside-model-pilot/local-stem-independent-fixture-receipt.json','fixture-receipt.json',false],
 ['tests/browser/frontside-crop-local-stem-independent.js','fixture.js.gz',true],
 ['tests/browser/frontside-crop-local-stem-independent.html','fixture.html.gz',true],
 ['tools/frontside_build_local_stem_independent.mjs','generator.mjs.gz',true]
];
for(const [source,path,gzip] of files){const bytes=read(root+source);write(dir+path,gzip?gzipSync(bytes):bytes);pieces.push({source,path,gzip,bytes:bytes.length,sha256:sha(bytes)});}
for(const path of ['native-screen.png','console.json']){const bytes=read(dir+path);pieces.push({source:'native browser789',path,gzip:false,bytes:bytes.length,sha256:sha(bytes)});}
const archive=read('.cache/archive-front-independent-v1.mjs');write(dir+'archive.mjs.gz',gzipSync(archive));pieces.push({source:'.cache/archive-front-independent-v1.mjs',path:'archive.mjs.gz',gzip:true,bytes:archive.length,sha256:sha(archive)});
const webGlb=read('public/'+report.source);
write(dir+'receipt.json',JSON.stringify({rootCommit:'1e606eae',fixtureCommit:'1071a2a5d66f616c65f2a3ae7670011b080563d7',authorHeadAtRun:'fb5ad8ac',fixtureSha256:'4fe378e6ad86f52ef3694fff98df5c0ae4cbe83f402ae375bbfc535ba1926818',profileSha256:report.independentProfileSha256,tab:789,tabClosed:true,gpuDisposed:true,warningErrorLogs:[],cpuCampaigns:[41320,41304,49032,49608],productionAssetPromoted:false,benchmark:false,profileRejected:true,laterBlocksNotRun:true,url:'http://localhost:5284/tests/browser/frontside-crop-local-stem-independent.html?localStemFrontIndependent&limit=26&caseOffset=0&cpuCampaigns=41320,41304,49032,49608',sourceGlb:{runtime:report.source,bytes:webGlb.length,sha256:sha(webGlb)},pieces},null,2)+'\n');
