import assert from 'node:assert/strict';
import{readFileSync,writeFileSync,mkdirSync}from'node:fs';
import{gunzipSync}from'node:zlib';
import{dirname}from'node:path';
import{createHash}from'node:crypto';
import * as Game from './candidate-game-v5.mjs';
import{deserialize,serialize}from'../src/persistence/snapshots.js';
import{BIOME_IDS}from'../src/world/navigation.js';
import{Navigation}from'./worker-route-refinement/candidate-navigation-v5.mjs';
import{numberOf}from'../src/simulation/money.js';
import{LOCOMOTION as L}from'../src/simulation/locomotion-calibration.js';
const s=deserialize(gunzipSync(readFileSync('docs/qa/intensive-sabana-musgum-e461b550/state.json.gz')).toString());
const nav=new Navigation(s.seed,s.biome,JSON.parse(readFileSync(`public/content/biome-${BIOME_IDS[s.biome]}.json`)).profile);nav.setState(s);
const ids=JSON.parse(gunzipSync(readFileSync('docs/qa/watering-large-farm-return/attribution.json.gz'))).navigation.failureSamples.map(q=>q.start.id);
const rows=ids.map(id=>{const w=s.workers.find(w=>w.id===id);return {id,start:{x:w.x,z:w.z,status:w.status},firstValid:null,homeTick:null,maxStep:0,last:null};});
if(s.result==='victory')Game.continuePostgame(s);
const hired=Math.max(1,Math.min(Math.ceil(s.plants.filter(p=>p.alive).length/12),Math.floor(numberOf(s.ledger.balance)/30)));
if(s.pauses.includes('hiring'))Game.hire(s,'qa-watering-diagnostic-hire',{olderFemale:hired});
for(let tick=1;tick<=900;tick++){
 const before=new Map(s.workers.map(w=>[w.id,{x:w.x,z:w.z}]));Game.tick(s,.1,nav);
 for(const row of rows){const w=s.workers.find(w=>w.id===row.id);if(!w){assert(row.homeTick!==null,'Must reach home before removal');continue;}
  const p=before.get(w.id),d=Math.hypot(w.x-p.x,w.z-p.z);row.maxStep=Math.max(row.maxStep,d);
  assert(d<=Math.max(L.walkMetresPerSecond,L.runMetresPerSecond)*1.5*.1+1e-8,'No teleport or speed increase');
  if(!row.firstValid&&nav.walkable(w.x,w.z,w.radius??.28,null,true))row.firstValid={tick,x:w.x,z:w.z};
  row.last={x:w.x,z:w.z,status:w.status,pathLength:w.path?.length??null};if(row.homeTick===null&&w.status==='home')row.homeTick=tick;
 }
}
assert.equal(rows.length,27);assert(rows.every(r=>r.firstValid));
const report={scope:'Ordinary Game.tick continuation with paid hiring, no position/collision/growth/speed/RNG overrides. Tracks 27 historical terrain-invalid returning workers over 900 ticks, not full campaign acceptance or a GPU benchmark.',ticks:900,stepSeconds:.1,hired,rows,final:{day:s.day,time:s.time,workers:s.workers.length,living:s.plants.filter(p=>p.alive).length,stateSha256:createHash('sha256').update(serialize(s)).digest('hex')}};
mkdirSync('.cache/watering-slope-integrated',{recursive:true});writeFileSync('.cache/worker-route-refinement/native-return-v5.json',JSON.stringify(report,null,2)+'\n');assert(rows.every(r=>r.homeTick!==null));console.log(JSON.stringify({tracked:rows.length,firstValidBy:Math.max(...rows.map(r=>r.firstValid.tick)),homeBy:Math.max(...rows.map(r=>r.homeTick)),hired,final:report.final},null,2));


