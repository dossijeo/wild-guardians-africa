import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
let nav=readFileSync('.cache/worker-route-refinement/candidate-navigation-v4.mjs','utf8');
const get='return this.qaRefinedCache.get(key);',set='this.qaRefinedCache.set(key,valid);';assert.equal(nav.split(get).length,2);assert.equal(nav.split(set).length,2);
nav=nav.replace(get,'return this.qaRefinedCache.get(key).valid;').replace(set,'this.qaRefinedCache.set(key,{valid,peak:sweep.peak});');
nav=nav.replace('  qaRiskSegment(start,end,radius,ignore){',`  qaKnownRisk(start,end,radius,ignore){
    if(!Object.hasOwn(this,'qaRefinedCache'))return null;
    const key=JSON.stringify([start.x,start.z,end.x,end.z,radius,ignore,true,false]);
    return this.qaRefinedCache.get(key)??null;
  }
  qaRiskSegment(start,end,radius,ignore){`);
writeFileSync('.cache/worker-route-refinement/candidate-navigation-v5.mjs',nav);
let guard=readFileSync('.cache/worker-risk-clearance.mjs','utf8');
guard=guard.replace('classified:0,guarded:0,rejected:0','classified:0,guarded:0,rejected:0,reused:0,fallback:0');
const original=`   const length=Math.hypot(point.x-start.x,point.z-start.z),look=Math.max(4,Math.hypot(end.x-start.x,end.z-start.z));
   const boundary=length>look?{x:start.x+(point.x-start.x)*look/length,z:start.z+(point.z-start.z)*look/length}:point;
   const risk=nav.qaRiskSegment(start,boundary,radius,ignore);nav.qaMovementStats.classified++;`;
const replacement=`   const known=nav.qaKnownRisk(start,point,radius,ignore);
   const length=Math.hypot(point.x-start.x,point.z-start.z),look=Math.max(4,Math.hypot(end.x-start.x,end.z-start.z));
   const boundary=known?point:length>look?{x:start.x+(point.x-start.x)*look/length,z:start.z+(point.z-start.z)*look/length}:point;
   const risk=known??nav.qaRiskSegment(start,boundary,radius,ignore);nav.qaMovementStats.classified++;
   if(known)nav.qaMovementStats.reused++;else nav.qaMovementStats.fallback++;`;
assert(guard.includes(original));guard=guard.replace(original,replacement);
writeFileSync('.cache/worker-risk-clearance-v5.mjs',guard);
writeFileSync('.cache/candidate-game-v5.mjs',readFileSync('.cache/candidate-game-v4.mjs','utf8').replace("'./worker-risk-clearance.mjs'","'./worker-risk-clearance-v5.mjs'"));
for(const [input,output] of [
 ['.cache/probe-refinement-v4-replan.mjs','.cache/probe-refinement-v5-replan.mjs'],
 ['.cache/check-refinement-native-quality-v4.mjs','.cache/check-refinement-native-quality-v5.mjs'],
 ['.cache/check-worker-slope-native-v4.mjs','.cache/check-worker-slope-native-v5.mjs'],
 ['.cache/check-refinement-v4-restore.mjs','.cache/check-refinement-v5-restore.mjs'],
 ['.cache/check-refinement-v4-blocked-restore.mjs','.cache/check-refinement-v5-blocked-restore.mjs'],
 ['.cache/benchmark-worker-route-refinement-v4-guard-cost.mjs','.cache/benchmark-worker-route-refinement-v5-guard-cost.mjs']]){
 let code=readFileSync(input,'utf8').replaceAll('candidate-game-v4.mjs','candidate-game-v5.mjs').replaceAll('candidate-navigation-v4.mjs','candidate-navigation-v5.mjs').replaceAll("'.cache/worker-risk-clearance.mjs'","'.cache/worker-risk-clearance-v5.mjs'").replaceAll('-v4.json','-v5.json').replaceAll('report-v4-guard-cost.json','report-v5-guard-cost.json').replaceAll('candidate V4','candidate V5');writeFileSync(output,code);
}
