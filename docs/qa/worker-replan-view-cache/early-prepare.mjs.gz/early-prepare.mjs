import {readFileSync as read,writeFileSync as write} from 'node:fs';
const opening=read('tools/check_opening.mjs','utf8').replace("from '../src/world/navigation.js'","from './worker-route-refinement/candidate-navigation-v6.mjs'").replace("from '../src/simulation/game.js'","from './candidate-game-v5.mjs'");
write('.cache/opening-v6.mjs',opening);
let intensive=read('tools/check_intensive_farm.mjs','utf8').replace("from './check_opening.mjs'","from './opening-v6.mjs'").replace("from '../src/simulation/game.js'","from './candidate-game-v5.mjs'");
for(const p of ['intensive-run-provenance','farm-defense-policy'])intensive=intensive.replace(`from './${p}.mjs'`,`from '../tools/${p}.mjs'`);
write('.cache/intensive-v6.mjs',intensive);
