import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
let nav=readFileSync('.cache/worker-route-refinement/candidate-navigation-v5.mjs','utf8');
nav="import {ViewMap,ViewSet,trimViewRegions} from '../bounded-worker-view-cache.mjs';\n"+nav;
const start=nav.indexOf('  qaWorkerPath(start,end,radius,ignore){'),end=nav.indexOf('  testSegmentClear(',start);assert(start>=0&&end>start);
nav=nav.slice(0,start)+`  qaWorkerPath(start,end,radius,ignore){
    const source=start.qaTerrainAvoidance;
    if(!source?.length){if(Object.hasOwn(this,'qaWorkerViews'))this.qaWorkerViews.delete(start);return this.path(start,end,radius,ignore,true);}
    if(!Object.hasOwn(this,'qaWorkerViews'))this.qaWorkerViews=new Map();
    const signature=JSON.stringify(source),cached=this.qaWorkerViews.get(start);let view;
    if(cached&&cached.version===this.version&&cached.radius===radius&&cached.ignore===ignore&&cached.signature===signature){
      view=cached.view;this.qaWorkerViews.delete(start);this.qaWorkerViews.set(start,cached);
    }else{
      const points=source.map(p=>({x:p.x,z:p.z}));
      // Portal positions/links depend only on unchanged native gates and radius;
      // every usable edge is still checked against this view's avoided points.
      this.portalGraph(radius,ignore);
      view=Object.assign(Object.create(this),{segmentCache:new ViewMap(4096),walkCache:new ViewMap(2048),failedPaths:new ViewSet(128),closedRegions:new ViewMap(2048),searchedRegions:[],searchNeighborCache:new ViewMap(512),portalGraphs:this.portalGraphs,preparedPaths:null,qaRefinedCache:new ViewMap(2048)});
      const test=view.testSegmentClear,walk=view.testWalkable;
      view.testSegmentClear=function(a,b,...args){return !points.some(p=>edgeDistance(a,b,p.x,p.z)<.00001)&&test.call(this,a,b,...args);};
      view.testWalkable=function(x,z,...args){return !points.some(p=>Math.hypot(x-p.x,z-p.z)<.00001)&&walk.call(this,x,z,...args);};
      if(this.qaWorkerViews.size>=8&&!this.qaWorkerViews.has(start))this.qaWorkerViews.delete(this.qaWorkerViews.keys().next().value);
      this.qaWorkerViews.set(start,{version:this.version,radius,ignore,signature,view});
    }
    const result=view.path(start,end,radius,ignore,true);trimViewRegions(view);return result;
  }
`+nav.slice(end);
writeFileSync('.cache/worker-route-refinement/candidate-navigation-v6.mjs',nav);
for(const [input,output] of [
 ['.cache/probe-refinement-v5-replan.mjs','.cache/probe-refinement-v6-replan.mjs'],
 ['.cache/check-refinement-v5-blocked-restore.mjs','.cache/check-refinement-v6-blocked-restore.mjs'],
 ['.cache/check-refinement-native-quality-v5.mjs','.cache/check-refinement-native-quality-v6.mjs']])writeFileSync(output,readFileSync(input,'utf8').replaceAll('candidate-navigation-v5.mjs','candidate-navigation-v6.mjs').replaceAll('-v5.json','-v6.json'));
