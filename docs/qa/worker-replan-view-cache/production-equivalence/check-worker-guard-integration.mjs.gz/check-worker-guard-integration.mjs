import assert from 'node:assert/strict';
import {readFileSync as read,writeFileSync as write} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import * as Prior from './candidate-game-v6-current.mjs';
import {Navigation as PriorNav} from './worker-route-refinement/candidate-navigation-v6-current.mjs';
import * as Game from '../src/simulation/game.js';
import {Navigation} from '../src/world/navigation.js';
import {deserialize,serialize} from '../src/persistence/snapshots.js';
const raw=gunzipSync(read('docs/qa/intensive-sabana-musgum-e461b550/state.json.gz')).toString();
const profile=JSON.parse(read('public/content/biome-savanna.json')).profile;
const sites=JSON.parse(read('.cache/no-crop-epoch-report.json')).sites;
const hash=b=>createHash('sha256').update(b).digest('hex');
const normalized=state=>serialize(state).replaceAll('"terrainAvoidance":','"qaTerrainAvoidance":');
const make=(G,N)=>{const state=deserialize(raw),nav=new N(state.seed,state.biome,profile);nav.setState(state);G.continuePostgame(state);G.hire(state,'qa-production-guard-hire',{olderFemale:Math.ceil(state.plants.filter(p=>p.alive).length/12)});return{state,nav};};
const a=make(Prior,PriorNav),b=make(Game,Navigation),pairs=[];
assert.equal(normalized(a.state),normalized(b.state));
for(let step=1;step<=100;step++) {
 if(step===25||step===50)for(const [x,G] of [[a,Prior],[b,Game]]) {
  const site=sites[step===25?0:1],check=x.nav.placement(site.x,site.z,.4),epoch=x.nav.version;
  assert(check.valid&&!check.suppress.length);G.plant(x.state,'intensive-plant-integration-'+step,'mijo',site.x,site.z,x.nav);assert.equal(x.nav.version,epoch);
 }
 Prior.tick(a.state,.1,a.nav);Game.tick(b.state,.1,b.nav);
 const one=normalized(a.state),two=normalized(b.state);assert.equal(one,two,'Complete state differs at step'+step);pairs.push(hash(one));
}
assert.deepEqual(a.nav.qaRefinement,b.nav.workerRefinementStats);assert.deepEqual(a.nav.qaMovementStats,b.nav.workerMotionStats);
const q=JSON.parse(read('.cache/worker-route-refinement/boundary-v3.json')).failure;
const blockedMake=N=>{const state=deserialize(raw),nav=new N(state.seed,state.biome,profile);nav.setState(state);const w={...q.start,id:'qa-worker',status:'walking',radius:.28};state.workers.push(w);return{state,nav,w,sim:{structures:state.structures,workers:[w]}};};
const old=blockedMake(PriorNav),next=blockedMake(Navigation),blocked=[];let reached=false,cold=null,restoredStates=0;
for(let step=1;step<=150;step++) {
 const x=Prior.walkTo(old.sim,old.w,q.end,q.dt,old.nav),y=Game.walkTo(next.sim,next.w,q.end,q.dt,next.nav);
 assert.equal(x,y);assert.equal(normalized(old.state),normalized(next.state));assert(next.nav.walkable(next.w.x,next.w.z,.28,null,true));
 if(cold){const z=Game.walkTo(cold.sim,cold.w,q.end,q.dt,cold.nav);assert.equal(y,z);assert.equal(serialize(next.state),serialize(cold.state));restoredStates++;}
 if(!cold&&next.w.terrainAvoidance?.length){
  const state=deserialize(serialize(next.state)),nav=new Navigation(state.seed,state.biome,profile);nav.setState(state);const w=state.workers.find(w=>w.id==='qa-worker');cold={state,nav,w,sim:{structures:state.structures,workers:[w]}};
 }
 blocked.push(hash(normalized(next.state)));if(y){reached=true;break;}
}
assert(reached);assert.equal(next.w.terrainAvoidance.length,1);assert.equal(old.w.qaTerrainAvoidance.length,1);assert(restoredStates>0);
const sources=Object.fromEntries(['.cache/check-worker-guard-integration.mjs','src/simulation/game.js','src/world/navigation.js','src/simulation/worker-route-clearance.js','src/world/worker-view-cache.js','src/persistence/snapshots.js','.cache/candidate-game-v6-current.mjs','.cache/worker-route-refinement/candidate-navigation-v6-current.mjs','.cache/worker-risk-clearance-v5.mjs'].map(p=>[p,hash(read(p))]));
write('.cache/worker-guard-integration-report.json',JSON.stringify({scope:'Current production integration versus frozen V6 candidate. Only optional logical actor field name is normalized qaTerrainAvoidance→terrainAvoidance for comparison. All100 complete states paid112staff/two clear-ground replants; actual native adversarial connector states and cold restored continuation. No CPU/GPU timing claim.',sources,statesCompared:pairs.length,paidReplants:2,pairs,refinement:b.nav.workerRefinementStats,movement:b.nav.workerMotionStats,blocked:{statesCompared:blocked.length,reached,avoidancePoints:next.w.terrainAvoidance.length,restoredStates,hashes:blocked}},null,2)+'\n');
console.log(JSON.stringify({statesCompared:pairs.length,paidReplants:2,blockedStates:blocked.length,reached,restoredStates}));
