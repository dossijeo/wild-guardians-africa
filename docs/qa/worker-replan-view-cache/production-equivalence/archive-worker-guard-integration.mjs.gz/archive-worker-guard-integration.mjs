import assert from 'node:assert/strict';
import {readFileSync as read,writeFileSync as write,mkdirSync} from 'node:fs';
import {gzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
const dir='docs/qa/worker-replan-view-cache/production-equivalence/',hash=b=>createHash('sha256').update(b).digest('hex');
const report=JSON.parse(read('.cache/worker-guard-integration-report.json'));assert.equal(report.statesCompared,100);assert.equal(report.blocked.restoredStates,63);
mkdirSync(dir,{recursive:true});const pieces=[];
for(const source of ['.cache/archive-worker-guard-integration.mjs','.cache/check-worker-guard-integration.mjs','.cache/integrate-worker-guard.mjs','.cache/worker-guard-integration-report.json','.cache/worker-guard-build.log','.cache/worker-guard-package.log',...Object.keys(report.sources).filter(p=>p!=='.cache/check-worker-guard-integration.mjs'),'.cache/bounded-worker-view-cache.mjs','.cache/no-crop-epoch-report.json','.cache/worker-route-refinement/boundary-v3.json','tests/worker-route-clearance.test.js','public/content/biome-savanna.json']) {
 const bytes=read(source);if(report.sources[source])assert.equal(hash(bytes),report.sources[source]);
 const path=source.replace(/^\.cache\//,'').replaceAll('/','__')+'.gz';write(dir+path,gzipSync(bytes));pieces.push({source,path,bytes:bytes.length,sha256:hash(bytes)});
}
write(dir+'receipt.json',JSON.stringify({productionCommit:'2fbe9a7e6250c1b54aea3d09ee8ddeb1ea3d15f6',nativeSession:54305,nativeExitCode:0,directedSession:78374,directedExitCode:0,directedPassed:52,buildPackageSession:3592,buildPackageExitCode:0,ciRun:37782785754,ciStatusAtArchive:'in_progress',productionChanged:true,input:'../../intensive-sabana-musgum-e461b550/state.json.gz',inputSha256:hash(read('docs/qa/intensive-sabana-musgum-e461b550/state.json.gz')),pieces},null,2)+'\n');
