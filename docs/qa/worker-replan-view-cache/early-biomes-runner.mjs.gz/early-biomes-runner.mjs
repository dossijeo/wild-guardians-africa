import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {simulateIntensiveFarm,auditIntensiveFarm} from './intensive-v6.mjs';
import {serialize} from '../src/persistence/snapshots.js';
import {createIntensiveHeartbeat} from '../tools/intensive-heartbeat.mjs';
const cases=[['gran-rio','saheliana'],['manglares','suajili'],['volcanes','etiope'],['gran-canon','mapungubwe'],['desierto','musgum']],rows=[];
const sourceHashes=Object.fromEntries(['.cache/opening-v6.mjs','.cache/intensive-v6.mjs','.cache/candidate-game-v5.mjs','.cache/worker-risk-clearance-v5.mjs','.cache/worker-route-refinement/candidate-navigation-v6.mjs','tools/check_opening.mjs','tools/check_intensive_farm.mjs','public/content/villages.json'].map(p=>[p,createHash('sha256').update(readFileSync(p)).digest('hex')]));
for(const [biome,culture] of cases){
 const key=biome+'-'+culture,heartbeat=createIntensiveHeartbeat();let last=null;
 try{
  const result=simulateIntensiveFarm({days:5,biome,culture,seed:712,mixed:true,onDay:day=>console.log(JSON.stringify({key,day})),onTick:s=>{last=s;const live=heartbeat(s);if(live)console.log(JSON.stringify({key,live}));}});
  auditIntensiveFarm(result);const {state,nav,...report}=result;
  if(report.completedNights!==5||report.result==='defeat')throw Error('Responsible candidate opening did not finish five nights');
  if(!report.daily.every(d=>d.staff>0&&d.delivered>0))throw Error('Day lacks paid labour or physical deliveries');
  const bytes=serialize(state),stateHash=createHash('sha256').update(bytes).digest('hex');writeFileSync('.cache/worker-route-refinement/early-'+key+'-v6-state.json',bytes);
  const row={key,status:'passed',...report,stateHash,movement:nav.qaMovementStats??null,refinement:nav.qaRefinement??null};rows.push(row);writeFileSync('.cache/worker-route-refinement/early-'+key+'-v6.json',JSON.stringify(row,null,2)+'\n');
  console.log(JSON.stringify({key,status:row.status,completedNights:row.completedNights,money:row.money,reloads:row.reloads,counts:row.counts}));
 }catch(e){if(last)writeFileSync('.cache/worker-route-refinement/early-'+key+'-v6-failure-state.json',serialize(last));const row={key,status:'failed',error:{name:e.name,message:e.message}};rows.push(row);writeFileSync('.cache/worker-route-refinement/early-'+key+'-v6-error.json',JSON.stringify(row,null,2)+'\n');console.error(JSON.stringify(row));process.exitCode=1;}
}
writeFileSync('.cache/worker-route-refinement/early-biomes-v6.json',JSON.stringify({scope:'QA five additional biome/culture pairs, five nights each, native responsible reinvestment/opening with V6/guarded Game and automatic actual raid snapshot reloads. Combined with Sabana/Musgum, all six biomes and five cultures are represented, not all30pairs or100nights. No per-internal-tick terrain sweep, benchmark, balance/damage override or production integration.',sourceHashes,rows},null,2)+'\n');
