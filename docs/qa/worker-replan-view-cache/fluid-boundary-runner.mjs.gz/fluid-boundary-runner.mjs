import {readFileSync,writeFileSync} from 'node:fs';
import {Navigation,BIOME_IDS} from './worker-route-refinement/candidate-navigation-v6.mjs';
import {walkTo} from './candidate-game-v5.mjs';
import {fluidAt} from '../src/world/fluid-placement.js';
const results=[];
for(const biome of ['sabana','gran-rio','manglares','volcanes']){
 const profile=JSON.parse(readFileSync(`public/content/biome-${BIOME_IDS[biome]}.json`)).profile,nav=new Navigation(712,biome,profile),state={structures:[],villages:[],spells:[],suppressed:[],workers:[]};nav.setState(state);
 const anchors=[];
 outer:for(let z=-96;z<=96;z+=6){let previous=fluidAt(nav.field,-96,z);for(let x=-95.5;x<=96;x+=.5){const wet=fluidAt(nav.field,x,z);if(wet!==previous){let a=x-.5,b=x;for(let i=0;i<20;i++){const m=(a+b)/2;if(fluidAt(nav.field,m,z)===previous)a=m;else b=m;}anchors.push({x:(a+b)/2,z,sign:previous?1:-1});if(anchors.length===32)break outer;}previous=wet;}}
 let considered=0,accepted=0,interiorInvalid=0,failure=null;const exercised=new Set();
 search:for(const [anchorIndex,p] of anchors.entries())for(const gap of [.000001,.0001,.001,.005,.025,.1])for(const dz of [-.01,0,.01])for(const angle of [Math.PI/2,-Math.PI/2,Math.PI/2-.03,Math.PI/2+.03,-Math.PI/2-.03,-Math.PI/2+.03])for(const length of [.1,.3,1,3,6,12]){
  considered++;const start={x:p.x+p.sign*(.28+gap),z:p.z+dz},end={x:start.x+Math.cos(angle)*length,z:start.z+Math.sin(angle)*length,id:'qa-fluid-goal'};
  if(!nav.terrainValid(start.x,start.z,.28,true)||!nav.terrainValid(end.x,end.z,.28,true))continue;
  // Probe only the exact movement positions of a 0.01 s straight walk. This is
  // not a continuous or exhaustive geometry proof.
  const count=Math.ceil(length/.0072);let invalid=null;
  for(let i=1;i<count;i++){const f=Math.min(1,i*.0072/length),x=start.x+(end.x-start.x)*f,z=start.z+(end.z-start.z)*f;if(!nav.terrainValid(x,z,.28,true)){invalid={x,z,i};break;}}
  if(!invalid)continue;interiorInvalid++;
  if(!nav.walkable(start.x,start.z,.28,null,true)||!nav.walkable(end.x,end.z,.28,null,true)||!nav.segmentClear(start,end,.28,null,true))continue;
  accepted++;exercised.add(anchorIndex);const actor={...start,id:'qa-fluid-worker',radius:.28,status:'walking'},sim={structures:[],workers:[actor]},rows=[];let reached=false;
  for(let i=0;i<2000&&!reached;i++){reached=walkTo(sim,actor,end,.01,nav);const valid=nav.walkable(actor.x,actor.z,.28,null,true);rows.push({i,x:actor.x,z:actor.z,valid,reached});if(!valid){failure={anchorIndex,start,end,invalid,risk:nav.qaKnownRisk(start,end,.28,null),rows,stats:nav.qaMovementStats};break search;}}
 }
 const row={biome,anchors:anchors.length,considered,interiorInvalid,accepted,exercised:[...exercised],failure};results.push(row);console.log(JSON.stringify({...row,failure:failure?{...failure,rows:failure.rows.slice(-3)}:null}));
}
writeFileSync('.cache/worker-route-refinement/fluid-boundary-v6.json',JSON.stringify({scope:'QA seed712 native terrain/props without villages or settlement platform; bounded adversarial shore tangents. Endpoint terrain valid, straight 0.01s movement locations tested for interior invalidity before native planner and walkTo. No continuous proof, full campaign, timing or production change.',results},null,2)+'\n');

