import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import {Navigation as V5} from './worker-route-refinement/candidate-navigation-v5.mjs';
import {Navigation as V6} from './worker-route-refinement/candidate-navigation-v6.mjs';
import {deserialize} from '../src/persistence/snapshots.js';
import {edgeDistance} from '../src/world/footprints.js';
const file=p=>readFileSync(p),hash=b=>createHash('sha256').update(b).digest('hex'),median=a=>[...a].sort((x,y)=>x-y)[Math.floor(a.length/2)];
const raw=gunzipSync(file('docs/qa/intensive-sabana-musgum-e461b550/state.json.gz')).toString(),profile=JSON.parse(file('public/content/biome-savanna.json')).profile;
const source=JSON.parse(file('.cache/worker-route-refinement/replan-v6.json')),origin=source.rows.find(r=>r.avoidance?.length),destination=JSON.parse(file('.cache/worker-route-refinement/boundary-v3.json')).failure.end;
assert(origin);const runs=[];let expected=null;
for(const mode of ['v5','v6','v6','v5']){
 const state=deserialize(raw),nav=new (mode==='v5'?V5:V6)(state.seed,state.biome,profile);nav.setState(state);
 const actor={id:'qa-native-replan-worker',x:origin.x,z:origin.z,radius:.28,status:'walking',qaTerrainAvoidance:structuredClone(origin.avoidance)};
 assert(nav.walkable(actor.x,actor.z,.28,null,true));assert(nav.walkable(destination.x,destination.z,.28,null,true));
 const times=[],routes=[];let searches=0;const find=nav.findPath;nav.findPath=function(...args){searches++;return find.apply(this,args);};
 for(let i=0;i<100;i++){
  const start=performance.now(),route=nav.qaWorkerPath(actor,destination,.28,null),elapsed=performance.now()-start;
  assert(route?.length,'Both variants must return a reachable route');
  expected??=route;assert.deepEqual(route,expected,'View reuse must retain exact chosen waypoints');
  let prior=actor;for(const p of route){assert(nav.segmentClear(prior,p,.28,null,true));assert(actor.qaTerrainAvoidance.every(a=>edgeDistance(prior,p,a.x,a.z)>=.00001));prior=p;}
  routes.push(hash(JSON.stringify(route)));if(i>=25)times.push(elapsed);
 }
 runs.push({mode,warmup:25,measured:75,medianMs:median(times),samplesMs:times,searches,routeHashes:routes,route:expected});console.log(JSON.stringify({mode,medianMs:runs.at(-1).medianMs,searches}));
}
const referenceMedian=median(runs.filter(r=>r.mode==='v5').flatMap(r=>r.samplesMs)),candidateMedian=median(runs.filter(r=>r.mode==='v6').flatMap(r=>r.samplesMs));
const report={scope:'QA native historical Sabana/Musgum terrain/props/buildings; constructed stationary worker exactly after recorded invalid landing rejection, valid origin and valid reachable destination. ABBA V5/V6 private navigation path query only,100queries25warm75measured per arm. Validation/route hashing outside timing. No movement simulation, full frame, GPU/phone or entire-farm speedup claim.',origin:{x:origin.x,z:origin.z,avoidance:origin.avoidance},destination,sourceHashes:Object.fromEntries(['.cache/worker-route-refinement/candidate-navigation-v5.mjs','.cache/worker-route-refinement/candidate-navigation-v6.mjs','.cache/bounded-worker-view-cache.mjs','.cache/worker-route-refinement/replan-v6.json','.cache/worker-route-refinement/boundary-v3.json'].map(p=>[p,hash(file(p))])),runs,referenceMedian,candidateMedian};
writeFileSync('.cache/worker-route-refinement/replan-cost-v6.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({referenceMedian,candidateMedian,ratio:candidateMedian/referenceMedian}));
