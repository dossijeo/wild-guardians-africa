import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {deserialize} from '../src/persistence/snapshots.js';
import {Navigation as V5} from './worker-route-refinement/candidate-navigation-v5.mjs';
import {Navigation as V6} from './worker-route-refinement/candidate-navigation-v6.mjs';
const q=JSON.parse(readFileSync('.cache/worker-route-refinement/boundary-v3.json')).failure,bad=q.rows.at(-1),results=[];
for(const [mode,Class] of [['v5',V5],['v6',V6]]){
 const s=deserialize(gunzipSync(readFileSync('docs/qa/intensive-sabana-musgum-e461b550/state.json.gz')).toString()),nav=new Class(s.seed,s.biome,JSON.parse(readFileSync('public/content/biome-savanna.json')).profile);nav.setState(s);
 const w={...q.start,id:'qa-worker',qaTerrainAvoidance:[{x:bad.x,z:bad.z}]};let calls=0;const find=nav.findPath;nav.findPath=function(...args){calls++;return find.apply(this,args);};
 assert(nav.walkable(w.x,w.z,.28,null,true));assert.equal(nav.walkable(bad.x,bad.z,.28,null,true),false);const answers=[];
 for(let i=0;i<100;i++)answers.push(nav.qaWorkerPath(w,bad,.28,null));assert(answers.every(x=>x===null));results.push({mode,calls,answers:answers.length,viewCount:nav.qaWorkerViews?.size??null});
}
assert.deepEqual(results.map(x=>x.calls),[100,1]);writeFileSync('.cache/worker-route-refinement/failed-views-v6.json',JSON.stringify({scope:'QA100 identical failed queries per variant, native historical field/props/buildings, constructed stationary worker with one confirmed terrain-invalid avoided point as destination. Counts findPath invocations, not graph nodes, CPU/GPU timing or reachable-task acceptance.',results},null,2)+'\n');console.log(JSON.stringify(results));
