import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {deserialize,serialize} from '../src/persistence/snapshots.js';
import {Navigation as Candidate} from './worker-route-refinement/candidate-navigation-v6.mjs';
import {Navigation as Original} from '../src/world/navigation.js';
import * as CandidateGame from './candidate-game-v5.mjs';
import * as OriginalGame from '../src/simulation/game.js';
import {gateFrameFootprints} from '../src/world/gate-passages.js';
import {advanceGateLeaves} from '../src/simulation/gates.js';
import {LOCOMOTION as L} from '../src/simulation/locomotion-calibration.js';
const raw=gunzipSync(readFileSync('docs/qa/intensive-sabana-musgum-e461b550/state.json.gz')).toString(),profile=JSON.parse(readFileSync('public/content/biome-savanna.json')).profile;
const make=Class=>{const state=deserialize(raw),nav=new Class(state.seed,state.biome,profile);nav.setState(state);return {state,nav};};
const transform=(gate,x,z)=>({x:gate.x+x*Math.cos(gate.yaw)+z*Math.sin(gate.yaw),z:gate.z-x*Math.sin(gate.yaw)+z*Math.cos(gate.yaw)});
const movement=(state,worker)=>({structures:state.structures,workers:[worker],pauses:[],initialPreparation:false});
const projected=(worker,gate)=>JSON.stringify({worker,gate});
const results=[];
for(const material of ['zarzas','empalizada','adobe','piedra','reforzado'])for(const yaw of [0,Math.PI/4,Math.PI/2]){
 const {state:search,nav:searchNav}=make(Candidate),center=search.structures.find(s=>s.kind==='center');let gate=null,start=null,end=null;
 outer:for(let dz=-16;dz<=16;dz+=2)for(let dx=-16;dx<=16;dx+=2){
  const proposal={id:'qa-native-gate',kind:'wall',gate:true,material,yaw,baseScaleX:1,x:center.x+dx,z:center.z+dz,hp:120,maxHp:120,status:'intact',gateOpen:0};
  const a=transform(proposal,.05,-3),b={...transform(proposal,.05,3),id:'qa-gate-goal'};
  if(searchNav.walkable(a.x,a.z,.28,null,true)&&searchNav.walkable(b.x,b.z,.28,null,true)&&searchNav.segmentClear(a,b,.28,null,true)&&searchNav.placementFootprint(proposal).valid){gate=proposal;start=a;end=b;break outer;}
 }
 assert(gate,'Native legal gate fixture not found '+material+'/'+yaw);
 const arms=[];
 for(const mode of ['original','candidate']){
  const Game=mode==='original'?OriginalGame:CandidateGame,{state,nav}=make(mode==='original'?Original:Candidate);const g=structuredClone(gate);state.structures.push(g);nav.setState(state);
  const pillar=gateFrameFootprints(g)[0],point={x:pillar.reduce((n,p)=>n+p.x,0)/pillar.length,z:pillar.reduce((n,p)=>n+p.z,0)/pillar.length};assert(!nav.walkable(point.x,point.z,.28,null,true));
  const w={...start,id:'qa-native-gate-worker',status:'walking',radius:.28,qaTerrainAvoidance:[point]};state.workers.push(w);
  const rows=[];let reached=false,waits=0,restored=null,cold=null,coldWorker=null,coldGate=null,restorePairs=0;
  for(let step=0;step<250&&!reached;step++){
   const before={x:w.x,z:w.z};advanceGateLeaves(movement(state,w),.1);reached=Game.walkTo(movement(state,w),w,end,.1,nav);
   assert(nav.walkable(w.x,w.z,.28,null,true));assert(nav.workerMotionClear(before,w,.28));assert(Math.hypot(w.x-before.x,w.z-before.z)<=L.walkMetresPerSecond*.1+1e-8);if(w.gateWaiting)waits++;
   if(cold){advanceGateLeaves(movement(restored,coldWorker),.1);Game.walkTo(movement(restored,coldWorker),coldWorker,end,.1,cold);assert.equal(projected(coldWorker,coldGate),projected(w,g));restorePairs++;}
   if(mode==='candidate'&&step===4){restored=deserialize(serialize(state));cold=new Candidate(restored.seed,restored.biome,profile);cold.setState(restored);coldWorker=restored.workers.find(a=>a.id===w.id);coldGate=restored.structures.find(a=>a.id===g.id);}
   rows.push({step,x:w.x,z:w.z,gateOpen:g.gateOpen,waiting:!!w.gateWaiting});
  }
  assert(reached,'Must cross gate, not merely stay safe');if(['zarzas','empalizada','reforzado'].includes(material))assert(waits>0,'Articulated gate must wait');
  arms.push({mode,reached,waits,steps:rows.length,restorePairs,rows,final:projected(w,g),viewCount:nav.qaWorkerViews?.size??0});
 }
 assert.deepEqual(arms[0].rows,arms[1].rows);assert.equal(arms[0].final,arms[1].final);results.push({material,yaw,gate,start,end,arms});console.log(JSON.stringify({material,yaw,steps:arms[1].steps,waits:arms[1].waits,restorePairs:arms[1].restorePairs}));
}
writeFileSync('.cache/worker-route-refinement/native-gates-v6.json',JSON.stringify({scope:'QA historical native Sabana/Musgum terrain/props/villages/centre. Constructed legally sited native gate and single controlled worker with a confirmed pillar-invalid avoided point; existing actors and clock frozen. Original versus V6 movements identical; V6 full snapshot checkpoint after5steps then worker/gate projection equality after restore, not full-state continuation or opening gameplay. Five materials and three yaws, no terrain/prop/speed overrides, no GPU/CPU benchmark.',results},null,2)+'\n');
