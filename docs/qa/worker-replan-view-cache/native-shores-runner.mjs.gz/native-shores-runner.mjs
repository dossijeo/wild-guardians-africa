import {readFileSync,writeFileSync} from 'node:fs';
import {Navigation,BIOME_IDS} from './worker-route-refinement/candidate-navigation-v6.mjs';
import {walkTo} from './candidate-game-v5.mjs';
import {fluidAt} from '../src/world/fluid-placement.js';
const rows=[];
for(const biome of ['sabana','gran-rio','manglares','volcanes','gran-canon']){
 const profile=JSON.parse(readFileSync(`public/content/biome-${BIOME_IDS[biome]}.json`)).profile;
 const nav=new Navigation(712,biome,profile),state={structures:[],villages:[],spells:[],suppressed:[],workers:[]};nav.setState(state);
 const anchors=[];
 if(biome==='gran-canon'){
  for(let z=-64;z<=64;z+=4){const p={x:nav.field.riverX(z),z};if(fluidAt(nav.field,p.x,p.z)&&nav.walkable(p.x,p.z,.28,null,true))anchors.push({...p,canyon:true});if(anchors.length>=12)break;}
 }else{
  outer:for(let z=-64;z<=64;z+=4){let prior=fluidAt(nav.field,-80,z);for(let x=-79.5;x<=80;x+=.5){const wet=fluidAt(nav.field,x,z);if(wet!==prior){let a=x-.5,b=x;for(let i=0;i<18;i++){const m=(a+b)/2;if(fluidAt(nav.field,m,z)===prior)a=m;else b=m;}const edge=(a+b)/2,drySign=prior?1:-1;anchors.push({x:edge,z,drySign});if(anchors.length>=12)break outer;}prior=wet;}}
 }
 let considered=0,accepted=0;const samples=[],violations=[];
 for(const [anchorIndex,anchor] of anchors.entries()){let perAnchor=0;anchorSearch:for(const gap of [.005,.025,.05,.1,.2,.4])for(const dz of [0,.025,-.025])for(const angle of [Math.PI/2,-Math.PI/2,0,Math.PI,Math.PI/4,3*Math.PI/4])for(const length of [.1,.3]){
  const start={x:anchor.x+(anchor.canyon?0:anchor.drySign*(.28+gap)),z:anchor.z+dz},end={x:start.x+Math.cos(angle)*length,z:start.z+Math.sin(angle)*length,id:'qa-shore-goal'};considered++;
  if(!nav.walkable(start.x,start.z,.28,null,true)||!nav.walkable(end.x,end.z,.28,null,true)||!nav.segmentClear(start,end,.28,null,true))continue;
  accepted++;const risk=nav.qaKnownRisk(start,end,.28,null);
  for(const dt of [.01,.025,.1]){
   const actor={...start,id:'qa-shore-worker',radius:.28,status:'walking'};state.workers=[actor];let reached=false,violation=null,steps=0;
   for(;steps<100;steps++){reached=walkTo(state,actor,end,dt,nav);if(!nav.walkable(actor.x,actor.z,.28,null,true)){violation={step:steps+1,x:actor.x,z:actor.z,fluid:fluidAt(nav.field,actor.x,actor.z)};break;}if(reached){steps++;break;}}
   const sample={anchorIndex,start,end,dt,reached,steps,risk,violation};samples.push(sample);if(violation)violations.push(sample);
  }
  if(++perAnchor>=6)break anchorSearch;
 }}
 const row={biome,anchors:anchors.length,anchorsExercised:new Set(samples.map(s=>s.anchorIndex)).size,considered,accepted,runs:samples.length,violations:violations.length,reached:samples.filter(s=>s.reached).length,samples};rows.push(row);console.log(JSON.stringify({biome,anchors:row.anchors,considered,accepted,runs:row.runs,violations:row.violations,reached:row.reached}));
}
const report={scope:'QA native seed712 terrain and native procedural props, empty structures/villages and no settlement platform. Constructed walking worker, ordinary candidate walkTo/nav, up to6 accepted short connectors per each of12 sampled anchors per biome at sampled fluid shore anchors; three time steps. Gran Canyon uses submerged river anchors and its existing water exception. No terrain/prop/actor speed overrides, no GPU timing or full populated campaign proof.',rows};
writeFileSync('.cache/worker-route-refinement/native-shores-v6.json',JSON.stringify(report,null,2)+'\n');
if(rows.some(r=>r.violations))process.exitCode=1;
