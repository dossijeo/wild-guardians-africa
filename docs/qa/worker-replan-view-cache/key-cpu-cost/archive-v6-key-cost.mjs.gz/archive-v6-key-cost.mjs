import assert from 'node:assert/strict';
import {readFileSync as read,writeFileSync as write,mkdirSync} from 'node:fs';
import {gzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
const dir='docs/qa/worker-replan-view-cache/key-cpu-cost/';
const hash=b=>createHash('sha256').update(b).digest('hex');
const report=JSON.parse(read('.cache/v6-key-cost-report.json'));assert.equal(report.runs.length,4);assert(report.allCompleteStatesEqual);
mkdirSync(dir,{recursive:true});const pieces=[];
for(const source of ['.cache/archive-v6-key-cost.mjs','.cache/benchmark-v6-key-cost.mjs','.cache/v6-key-cost-report.json','.cache/worker-refined-key.mjs','.cache/worker-route-refinement/candidate-navigation-v6-current.mjs','.cache/worker-route-refinement/candidate-navigation-v6-key.mjs','.cache/candidate-game-v6-current.mjs','.cache/worker-risk-clearance-v5.mjs','.cache/bounded-worker-view-cache.mjs','public/content/biome-savanna.json']) {
  const bytes=read(source);if(report.sources[source])assert.equal(hash(bytes),report.sources[source]);
  const path=source.replace(/^\.cache\//,'').replaceAll('/','__')+'.gz';write(dir+path,gzipSync(bytes));pieces.push({source,path,bytes:bytes.length,sha256:hash(bytes)});
}
write(dir+'receipt.json',JSON.stringify({baseCommit:'2f2039dd',session:92770,exitCode:0,productionChanged:false,confirmedHistoricalCpuBeforeDispatch:[41320,41304,49032,49608],loadingPilot14NotOpenedBeforeDispatch:true,noRootGpu:true,input:'../../intensive-sabana-musgum-e461b550/state.json.gz',inputSha256:hash(read('docs/qa/intensive-sabana-musgum-e461b550/state.json.gz')),pieces},null,2)+'\n');
