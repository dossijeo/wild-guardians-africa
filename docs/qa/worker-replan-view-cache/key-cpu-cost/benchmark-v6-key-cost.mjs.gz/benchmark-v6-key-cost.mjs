import assert from 'node:assert/strict';
import {readFileSync as read,writeFileSync as write} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import * as Game from './candidate-game-v6-current.mjs';
import {Navigation as Base} from './worker-route-refinement/candidate-navigation-v6-current.mjs';
import {Navigation as Candidate} from './worker-route-refinement/candidate-navigation-v6-key.mjs';
import {deserialize,serialize} from '../src/persistence/snapshots.js';

const raw=gunzipSync(read('docs/qa/intensive-sabana-musgum-e461b550/state.json.gz')).toString();
const profile=JSON.parse(read('public/content/biome-savanna.json')).profile;
const hash=b=>createHash('sha256').update(b).digest('hex');
const median=xs=>[...xs].sort((a,b)=>a-b)[Math.floor(xs.length/2)];
const runs=[];
for(const mode of ['base','key','key','base']) {
  const state=deserialize(raw),nav=new (mode==='base'?Base:Candidate)(state.seed,state.biome,profile);
  nav.setState(state);Game.continuePostgame(state);
  const staff=Math.ceil(state.plants.filter(p=>p.alive).length/12);
  Game.hire(state,'qa-key-cost-hire',{olderFemale:staff});
  assert.equal(state.pauses.length,0);
  const samplesMs=[],hashes=[];
  for(let step=0;step<100;step++) {
    const before=performance.now();Game.tick(state,.1,nav);const elapsed=performance.now()-before;
    if(step>=25)samplesMs.push(elapsed);
    hashes.push(hash(serialize(state)));
  }
  runs.push({mode,staff,warmupTicks:25,measuredTicks:75,samplesMs,medianMs:median(samplesMs),hashes,refinement:nav.qaRefinement,movement:nav.qaMovementStats});
  console.log(JSON.stringify({arm:runs.length,mode,medianMs:runs.at(-1).medianMs}));
}
for(const run of runs) {
  assert.deepEqual(run.hashes,runs[0].hashes,'All100 full states must match across all ABBA arms');
  assert.deepEqual(run.refinement,runs[0].refinement);
  assert.deepEqual(run.movement,runs[0].movement);
}
const sources=Object.fromEntries(['.cache/benchmark-v6-key-cost.mjs','.cache/worker-refined-key.mjs','.cache/worker-route-refinement/candidate-navigation-v6-current.mjs','.cache/worker-route-refinement/candidate-navigation-v6-key.mjs','.cache/candidate-game-v6-current.mjs','.cache/worker-risk-clearance-v5.mjs'].map(p=>[p,hash(read(p))]));
const baseMedianMs=median(runs.filter(r=>r.mode==='base').flatMap(r=>r.samplesMs));
const keyMedianMs=median(runs.filter(r=>r.mode==='key').flatMap(r=>r.samplesMs));
const report={scope:'Only cache-key serialization differs between isolated V6 candidates, same guarded Game/current epoch. Historical native farm112 paid older women, ABBA100 ticks per arm25warm75measured, hashing outside timing. Four historical CPU campaigns are live; no GPU/phone/end-to-end claim.',sources,runs,allCompleteStatesEqual:true,baseMedianMs,keyMedianMs,deltaMs:keyMedianMs-baseMedianMs,deltaPercent:100*(keyMedianMs/baseMedianMs-1)};
write('.cache/v6-key-cost-report.json',JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({baseMedianMs,keyMedianMs,deltaMs:report.deltaMs,deltaPercent:report.deltaPercent,allCompleteStatesEqual:true}));
