import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import * as Game from '../src/simulation/game.js';
import {Navigation as Native} from '../src/world/navigation.js';
import {Navigation as Candidate} from './no-crop-epoch-navigation.mjs';
import {deserialize,serialize} from '../src/persistence/snapshots.js';
import {numberOf} from '../src/simulation/money.js';
import {auditIntensiveFarm} from '../tools/check_intensive_farm.mjs';
const source='docs/qa/intensive-sabana-musgum-e461b550/state.json.gz',raw=gunzipSync(readFileSync(source)).toString(),profile=JSON.parse(readFileSync('public/content/biome-savanna.json')).profile;
const sites=JSON.parse(readFileSync('.cache/no-crop-epoch-report.json')).sites,sha=b=>createHash('sha256').update(b).digest('hex'),rows=[];
for(const [mode,Class] of [['reference',Native],['candidate',Candidate]]){
 let s=deserialize(raw),nav=new Class(s.seed,s.biome,profile);nav.setState(s);Game.continuePostgame(s);
 const staff=Math.ceil(s.plants.filter(p=>p.alive).length/12);Game.hire(s,'qa-dense-epoch-hire',{olderFemale:staff});
 const startDay=s.day,startElapsed=s.elapsed,initialMoney=numberOf(s.ledger.balance),initialCrates=s.crates.length,initialDelivered=s.crates.filter(c=>c.delivered).length;
 const checkpoints=[],violations=[],seen=new Set(s.events.map(e=>e.id)),events={};let ticks=0,cold=null,restorePairs=0,restoreWindows=0,violationCount=0,lastHeartbeat=performance.now(),error=null;
 try{
  while(s.day===startDay&&!s.result&&s.elapsed-startElapsed<1800){
   assert.equal(s.pauses.length,0,'Unexpected blocking pause within workday');
   if(!cold&&restoreWindows<3&&s.time>=[30,150,285][restoreWindows]){const bytes=serialize(s),copy=deserialize(bytes),n=new Class(copy.seed,copy.biome,profile);n.setState(copy);cold={s:copy,nav:n,remaining:10};restoreWindows++;}
   const before=new Map(s.workers.filter(w=>w.status!=='home').map(w=>[w.id,{valid:nav.walkable(w.x,w.z,w.radius??.28,null,true),status:w.status,x:w.x,z:w.z}]));
   if(ticks%300===0&&ticks<3000){const p=sites[ticks/300];for(const [state,n] of cold?[[s,nav],[cold.s,cold.nav]]:[[s,nav]]){const check=n.placement(p.x,p.z,.4);assert(check.valid&&check.suppress.length===0);Game.plant(state,'intensive-plant-dense-epoch-'+ticks,'mijo',p.x,p.z,n);}}
   Game.tick(s,.1,nav);ticks++;
   if(cold){Game.tick(cold.s,.1,cold.nav);assert.equal(serialize(cold.s),serialize(s),'Cold restore full state diverged');restorePairs++;if(--cold.remaining===0)cold=null;}
   for(const w of s.workers){const b=before.get(w.id);if(b?.valid&&w.status!=='home'&&!nav.walkable(w.x,w.z,w.radius??.28,null,true)){violationCount++;if(violations.length<100)violations.push({tick:ticks,time:s.time,id:w.id,before:b,after:{x:w.x,z:w.z,status:w.status},raid:!!s.raid});}}
   for(const e of s.events)if(!seen.has(e.id)){seen.add(e.id);events[e.type]=(events[e.type]??0)+1;}
   if(ticks%300===0||s.day!==startDay){const statuses={};for(const w of s.workers)statuses[w.status]=(statuses[w.status]??0)+1;checkpoints.push({tick:ticks,day:s.day,time:s.time,money:numberOf(s.ledger.balance),living:s.plants.filter(p=>p.alive).length,delivered:s.crates.filter(c=>c.delivered).length,tasks:s.tasks.length,blocked:s.tasks.filter(t=>t.blocked).length,statuses,raid:!!s.raid});}
   if(performance.now()-lastHeartbeat>30000){const live={mode,pid:process.pid,tick:ticks,time:s.time,day:s.day,violationCount,restorePairs};writeFileSync('.cache/no-crop-epoch-dense-status.json',JSON.stringify({status:'running',live})+'\n');console.log(JSON.stringify(live));lastHeartbeat=performance.now();}
  }
  assert.equal(s.day,startDay+1,'Must reach next dawn');assert(s.pauses.includes('hiring'));assert.equal(s.result,null);assert.equal(restorePairs,30);
  assert(s.crates.filter(c=>c.delivered).length>initialDelivered,'Must physically deliver harvest');
  auditIntensiveFarm({state:s,counts:{CrateDelivered:s.crates.filter(c=>c.delivered).length,CropPicked:s.crates.length}});
 }catch(e){error={name:e.name,message:e.message.slice(0,1000)};process.exitCode=1;}
 const bytes=serialize(s);writeFileSync('.cache/no-crop-epoch-dense-'+mode+'-state.json',bytes);
 const row={mode,staff,startDay,startElapsed,initialMoney,initialCrates,initialDelivered,ticks,restoreWindows,restorePairs,events,checkpoints,violationCount,violations,error,final:{day:s.day,time:s.time,result:s.result,pauses:s.pauses,money:numberOf(s.ledger.balance),crates:s.crates.length,delivered:s.crates.filter(c=>c.delivered).length,living:s.plants.filter(p=>p.alive).length},stateHash:sha(bytes)};
 rows.push(row);writeFileSync('.cache/no-crop-epoch-dense-'+mode+'-report.json',JSON.stringify(row,null,2)+'\n');console.log(JSON.stringify({...row,checkpoints:row.checkpoints.length,violations:row.violations.length}));
 if(error)break;
}
const report={scope:'Untimed QA paired full workdays, historical native Sabana/Musgum dense farm, paid112older women and ten ordinary verified clear-ground replants one per30simulated seconds during daylight0..270. Unchanged production Game, Native vs no-crop-epoch navigator. Three full-state cold windows per arm. Endpoint validity sampled each0.1s tick, not continuous clearance; home/already-invalid origins excluded. Postgame supplies no raids. Route/task/economy differences remain possible, not state equality against original or FPS proof.',sourceHash:sha(raw),sites,sourceHashes:Object.fromEntries(['src/simulation/game.js','src/world/navigation.js','.cache/no-crop-epoch-navigation.mjs'].map(p=>[p,sha(readFileSync(p))])),rows};
writeFileSync('.cache/no-crop-epoch-dense-report.json',JSON.stringify(report,null,2)+'\n');writeFileSync('.cache/no-crop-epoch-dense-status.json',JSON.stringify({pid:process.pid,status:process.exitCode?'failed':'finished',rows:rows.map(r=>({mode:r.mode,error:r.error,violationCount:r.violationCount}))})+'\n');
