import assert from 'node:assert/strict';
import {readFileSync as read,writeFileSync as write,mkdirSync} from 'node:fs';
import {gzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
const dir='docs/qa/worker-replan-view-cache/key-equivalence/';
const sha=b=>createHash('sha256').update(b).digest('hex');
const report=JSON.parse(read('.cache/v6-key-equivalence-report.json'));
assert.equal(report.statesCompared,100);assert.equal(report.paidReplants,2);
assert.equal(report.blocked.statesCompared,70);assert.equal(report.blocked.avoidancePoints,1);assert(report.blocked.reached);
mkdirSync(dir,{recursive:true});const pieces=[];
for(const source of ['.cache/archive-v6-key-equivalence.mjs','.cache/check-v6-key-equivalence.mjs','.cache/refined-key.test.mjs','.cache/worker-refined-key.mjs','.cache/prepare-v6-key-candidate.mjs','.cache/v6-key-equivalence-report.json','.cache/worker-route-refinement/candidate-navigation-v6-current.mjs','.cache/worker-route-refinement/candidate-navigation-v6-key.mjs','.cache/candidate-game-v6-current.mjs','.cache/worker-risk-clearance-v5.mjs','.cache/bounded-worker-view-cache.mjs','.cache/no-crop-epoch-report.json','.cache/worker-route-refinement/boundary-v3.json','public/content/biome-savanna.json']) {
  const bytes=read(source);if(report.sources[source])assert.equal(sha(bytes),report.sources[source]);
  const path=source.replace(/^\.cache\//,'').replaceAll('/','__')+'.gz';write(dir+path,gzipSync(bytes));pieces.push({source,path,bytes:bytes.length,sha256:sha(bytes)});
}
write(dir+'receipt.json',JSON.stringify({baseCommit:'532eb046',session:88783,exitCode:0,productionChanged:false,input:'../../intensive-sabana-musgum-e461b550/state.json.gz',inputSha256:sha(read('docs/qa/intensive-sabana-musgum-e461b550/state.json.gz')),pieces},null,2)+'\n');
