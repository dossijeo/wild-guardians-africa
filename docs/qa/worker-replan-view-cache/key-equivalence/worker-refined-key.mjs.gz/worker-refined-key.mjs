// Preserve exact coordinate identity and ignore JSON semantics; avoid allocating
// and serializing an eight-element array on normal finite navigation queries.
export function refinedKey(start,end,radius,ignore,worker,escapeProps){
 const sx=start.x,sz=start.z,ex=end.x,ez=end.z;
 if(!Number.isFinite(sx)||!Number.isFinite(sz)||!Number.isFinite(ex)||!Number.isFinite(ez)||!Number.isFinite(radius)||typeof worker!=='boolean'||typeof escapeProps!=='boolean'||ignore!==null&&!['undefined','string','number','boolean'].includes(typeof ignore))return JSON.stringify([sx,sz,ex,ez,radius,ignore,worker,escapeProps]);
 return `finite:${sx},${sz}|${ex},${ez}:${radius}:${JSON.stringify(ignore??null)}:${worker?1:0}:${escapeProps?1:0}`;
}
