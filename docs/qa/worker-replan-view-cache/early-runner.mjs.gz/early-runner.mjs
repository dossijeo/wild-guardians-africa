import {writeFileSync} from 'node:fs';
import {simulateIntensiveFarm,auditIntensiveFarm} from './intensive-v6.mjs';
import {serialize} from '../src/persistence/snapshots.js';
import {createIntensiveHeartbeat} from '../tools/intensive-heartbeat.mjs';
const heartbeat=createIntensiveHeartbeat();let last=null;
try{
 const result=simulateIntensiveFarm({days:5,biome:'sabana',culture:'musgum',seed:712,mixed:true,onDay:day=>console.log(JSON.stringify(day)),onTick:s=>{last=s;const live=heartbeat(s);if(live)console.log(JSON.stringify({live}));}});
 auditIntensiveFarm(result);const {state,nav,...report}=result;
 if(report.completedNights!==5||report.result==='defeat')throw Error('Candidate responsible opening failed before five nights');
 if(!report.daily.every(d=>d.staff>0&&d.delivered>0))throw Error('Day lacks paid labour or physical deliveries');
 writeFileSync('.cache/worker-route-refinement/early-campaign-v6-state.json',serialize(state));
 writeFileSync('.cache/worker-route-refinement/early-campaign-v6.json',JSON.stringify({scope:'QA five-night Sabana/Musgum seed712 responsible reinvestment strategy with candidate V6/guarded Game, native legal opening and terrain/props, ordinary commands, automatic real raid snapshot reloads. No overrides, timing/GPU proof or full100night/multibiome acceptance.',...report},null,2)+'\n');console.log(JSON.stringify({completedNights:report.completedNights,money:report.money,reloads:report.reloads,counts:report.counts}));
}catch(e){if(last)writeFileSync('.cache/worker-route-refinement/early-campaign-v6-failure-state.json',serialize(last));writeFileSync('.cache/worker-route-refinement/early-campaign-v6-error.json',JSON.stringify({name:e.name,message:e.message},null,2)+'\n');console.error(e.message);process.exitCode=1;}
