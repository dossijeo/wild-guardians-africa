import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import {deserialize,serialize} from '../src/persistence/snapshots.js';
import {Navigation} from './worker-route-refinement/candidate-navigation-v6.mjs';
import {walkTo} from './candidate-game-v5.mjs';
const s=deserialize(gunzipSync(readFileSync('docs/qa/intensive-sabana-musgum-e461b550/state.json.gz')).toString()),profile=JSON.parse(readFileSync('public/content/biome-savanna.json')).profile,nav=new Navigation(s.seed,s.biome,profile);nav.setState(s);
const q=JSON.parse(readFileSync('.cache/worker-route-refinement/boundary-v3.json')).failure,w={...q.start,id:'qa-worker',status:'walking',radius:.28},sim={structures:s.structures,workers:[w]};s.workers.push(w);
let rejectionTick=null;for(let i=1;i<=20;i++){walkTo(sim,w,q.end,q.dt,nav);if(w.qaTerrainAvoidance?.length){rejectionTick=i;break;}}
assert.equal(rejectionTick,7);assert.equal(w.path,null);assert(nav.walkable(w.x,w.z,.28,null,true));
const checkpoint=serialize(s),restored=deserialize(checkpoint),cold=new Navigation(restored.seed,restored.biome,profile);cold.setState(restored);const cw=restored.workers.find(x=>x.id===w.id),coldSim={structures:restored.structures,workers:[cw]},rows=[];let reached=false;
for(let i=1;i<=150;i++){const a=walkTo(sim,w,q.end,q.dt,nav),b=walkTo(coldSim,cw,q.end,q.dt,cold);assert.equal(a,b);const sa=serialize(s),sb=serialize(restored);assert.equal(sa,sb,'Full saved state equality after blocked-route reload');assert(nav.walkable(w.x,w.z,.28,null,true));assert(cold.walkable(cw.x,cw.z,.28,null,true));rows.push({i,sha256:createHash('sha256').update(sa).digest('hex'),x:w.x,z:w.z});if(a){reached=true;break;}}
assert(reached);writeFileSync('.cache/worker-route-refinement/blocked-restore-v6.json',JSON.stringify({scope:'Constructed worker appended to otherwise frozen native full snapshot. Snapshot serialize/deserialize after actual guard rejection; warm and cold navigator movement-only continuation. Other workers and simulation clock frozen. Not full campaign acceptance.',rejectionTick,checkpointSha256:createHash('sha256').update(checkpoint).digest('hex'),reached,steps:rows.length,rows},null,2)+'\n');console.log(JSON.stringify({rejectionTick,reached,steps:rows.length}));
