import assert from 'node:assert/strict';
import {readFileSync as read,writeFileSync as write,mkdirSync} from 'node:fs';
import {gzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
const dir='docs/qa/worker-replan-view-cache/ci-2fbe9a7e/',hash=b=>createHash('sha256').update(b).digest('hex');
const status=JSON.parse(read('.cache/worker-guard-ci-status.json')),log=read('.cache/worker-guard-ci.log');
assert.equal(status.headSha,'2fbe9a7e6250c1b54aea3d09ee8ddeb1ea3d15f6');assert.equal(status.status,'completed');assert.equal(status.conclusion,'success');
for(const metric of ['tests 3160','pass 3160','fail 0','cancelled 0','skipped 0'])assert(log.toString().includes('# '+metric));
mkdirSync(dir,{recursive:true});const pieces=[];
for(const [source,path,gzip] of [['.cache/worker-guard-ci-status.json','status.json',false],['.cache/worker-guard-ci.log','log.txt.gz',true],['.cache/archive-worker-guard-ci.mjs','archive.mjs.gz',true]]) {
 const bytes=read(source);write(dir+path,gzip?gzipSync(bytes):bytes);pieces.push({source,path,gzip,bytes:bytes.length,sha256:hash(bytes)});
}
const sources=JSON.parse(read('.cache/worker-guard-integration-report.json')).sources;
const productionSources=Object.fromEntries(Object.entries(sources).filter(([p])=>p.startsWith('src/')));
for(const [p,sha] of Object.entries(productionSources))assert.equal(hash(read(p)),sha);
write(dir+'receipt.json',JSON.stringify({run:37782785754,url:'https://github.com/dossijeo/wild-guardians-africa/actions/runs/37782785754',headSha:status.headSha,tests:3160,pass:3160,fail:0,cancelled:0,skipped:0,productionSources,localHeadAtArchive:'b90bf104',runtimeTestsToolsPackageWorkflowsDiffFromCiCommit:'empty',sourceBindingArchive:'../production-equivalence/receipt.json',pieces},null,2)+'\n');
