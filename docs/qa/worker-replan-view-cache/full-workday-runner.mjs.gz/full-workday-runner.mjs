import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import * as Game from './candidate-game-v5.mjs';
import {Navigation} from './worker-route-refinement/candidate-navigation-v6.mjs';
import {deserialize,serialize} from '../src/persistence/snapshots.js';
import {numberOf} from '../src/simulation/money.js';
import {auditIntensiveFarm} from '../tools/check_intensive_farm.mjs';
const source='docs/qa/intensive-sabana-musgum-e461b550/state.json.gz',raw=gunzipSync(readFileSync(source)).toString(),profile=JSON.parse(readFileSync('public/content/biome-savanna.json')).profile;
let s=deserialize(raw),nav=new Navigation(s.seed,s.biome,profile);nav.setState(s);Game.continuePostgame(s);
const staff=Math.ceil(s.plants.filter(p=>p.alive).length/12);Game.hire(s,'qa-full-workday-hire',{olderFemale:staff});assert.equal(s.pauses.length,0);
const startDay=s.day,startElapsed=s.elapsed,initialMoney=numberOf(s.ledger.balance),initialCrates=s.crates.length,initialDelivered=s.crates.filter(c=>c.delivered).length;
const checkpoints=[],violations=[],seen=new Set(s.events.map(e=>e.id)),events={};let ticks=0,cold=null,restorePairs=0,restoreWindows=0,lastHeartbeat=performance.now(),error=null;
const hash=x=>createHash('sha256').update(x).digest('hex');
try{
 while(s.day===startDay&&!s.result&&s.elapsed-startElapsed<1800){
  assert.equal(s.pauses.length,0,'Unexpected blocking pause within workday');
  if(!cold&&restoreWindows<3&&s.time>=[30,150,285][restoreWindows]){const bytes=serialize(s),copy=deserialize(bytes),n=new Navigation(copy.seed,copy.biome,profile);n.setState(copy);cold={s:copy,nav:n,remaining:10,time:s.time};restoreWindows++;}
  const before=new Map(s.workers.filter(w=>w.status!=='home').map(w=>[w.id,{valid:nav.walkable(w.x,w.z,w.radius??.28,null,true),status:w.status,x:w.x,z:w.z}]));
  Game.tick(s,.1,nav);ticks++;
  if(cold){Game.tick(cold.s,.1,cold.nav);assert.equal(serialize(cold.s),serialize(s),'Cold restore full state diverged');restorePairs++;if(--cold.remaining===0)cold=null;}
  for(const w of s.workers){const b=before.get(w.id);if(b?.valid&&w.status!=='home'&&!nav.walkable(w.x,w.z,w.radius??.28,null,true)&&violations.length<100)violations.push({tick:ticks,time:s.time,id:w.id,before:b,after:{x:w.x,z:w.z,status:w.status,incapacitated:w.incapacitated},raid:!!s.raid});}
  for(const e of s.events)if(!seen.has(e.id)){seen.add(e.id);events[e.type]=(events[e.type]??0)+1;}
  if(ticks%300===0||s.day!==startDay){const statuses={};for(const w of s.workers)statuses[w.status]=(statuses[w.status]??0)+1;checkpoints.push({tick:ticks,day:s.day,time:s.time,money:numberOf(s.ledger.balance),living:s.plants.filter(p=>p.alive).length,crates:s.crates.length,delivered:s.crates.filter(c=>c.delivered).length,tasks:s.tasks.length,blocked:s.tasks.filter(t=>t.blocked).length,statuses,raid:!!s.raid});}
  if(performance.now()-lastHeartbeat>30000){console.log(JSON.stringify({tick:ticks,time:s.time,day:s.day,violations:violations.length,restorePairs}));lastHeartbeat=performance.now();}
 }
 assert.equal(s.day,startDay+1,'Must reach next dawn');assert(s.pauses.includes('hiring'),'Next dawn must open hiring');assert.equal(s.result,null);assert.equal(restorePairs,30);
 assert(s.crates.filter(c=>c.delivered).length>initialDelivered,'Must physically deliver harvest');
 const counts={CrateDelivered:s.crates.filter(c=>c.delivered).length,CropPicked:s.crates.length};auditIntensiveFarm({state:s,counts});
 assert.equal(violations.length,0,'New invalid worker positions observed');
}catch(e){error={name:e.name,message:e.message.slice(0,1200)};process.exitCode=1;}
const bytes=serialize(s);writeFileSync('.cache/worker-route-refinement/full-workday-v6-state.json',bytes);
const report={scope:'QA candidate full postgame workday from historical native Sabana/Musgum farm; ordinary paid hiring, no replanting/magic/wall inputs, all workers/tasks/raids/clock active. Endpoint validity each 0.1s tick, three cold full-state restore windows of ten ticks. No continuous collision proof, campaign strategy, GPU or CPU benchmark.',sourceHash:hash(raw),sourceHashes:Object.fromEntries(['src/simulation/game.js','src/world/navigation.js','.cache/candidate-game-v5.mjs','.cache/worker-risk-clearance-v5.mjs','.cache/worker-route-refinement/candidate-navigation-v6.mjs'].map(p=>[p,hash(readFileSync(p))])),staff,startDay,startElapsed,initialMoney,initialCrates,initialDelivered,ticks,restoreWindows,restorePairs,events,checkpoints,violations,error,final:{day:s.day,time:s.time,result:s.result,pauses:s.pauses,money:numberOf(s.ledger.balance),crates:s.crates.length,delivered:s.crates.filter(c=>c.delivered).length,living:s.plants.filter(p=>p.alive).length},stateHash:hash(bytes),movement:nav.qaMovementStats??null};
writeFileSync('.cache/worker-route-refinement/full-workday-v6.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({...report,checkpoints:report.checkpoints.length,sourceHashes:undefined}));
