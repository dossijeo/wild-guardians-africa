import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {deserialize} from '../src/persistence/snapshots.js';
import {Navigation} from './worker-route-refinement/candidate-navigation-v6.mjs';
import {walkTo} from './candidate-game-v5.mjs';
import {LOCOMOTION as L} from '../src/simulation/locomotion-calibration.js';
const s=deserialize(gunzipSync(readFileSync('docs/qa/intensive-sabana-musgum-e461b550/state.json.gz')).toString()),nav=new Navigation(s.seed,s.biome,JSON.parse(readFileSync('public/content/biome-savanna.json')).profile);nav.setState(s);
const q=JSON.parse(readFileSync('.cache/worker-route-refinement/boundary-v3.json')).failure,w={...q.start,id:'qa-worker',status:'walking',radius:.28},state={structures:s.structures,workers:[w]};
const rows=[];let reached=false;
for(let i=0;i<2000;i++){
 const before={x:w.x,z:w.z};reached=walkTo(state,w,q.end,q.dt,nav);const valid=nav.walkable(w.x,w.z,.28,null,true);assert(Math.hypot(w.x-before.x,w.z-before.z)<=L.walkMetresPerSecond*q.dt+1e-8);rows.push({i,x:w.x,z:w.z,valid,reached,path:structuredClone(w.path),avoidance:structuredClone(w.qaTerrainAvoidance)});
 if(!valid||reached)break;
}
const report={scope:'QA constructed walking worker on native terrain/props/buildings, same V3 failing connector, ordinary candidate walkTo/nav, no teleport or speed override.',reached,allValid:rows.every(r=>r.valid),steps:rows.length,movement:nav.qaMovementStats,rows};
writeFileSync('.cache/worker-route-refinement/replan-v6.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({reached,allValid:report.allValid,steps:rows.length,movement:nav.qaMovementStats,last:rows.at(-1)},null,2));
assert(report.allValid);assert(reached,'Must reach destination, not just remain safe');
