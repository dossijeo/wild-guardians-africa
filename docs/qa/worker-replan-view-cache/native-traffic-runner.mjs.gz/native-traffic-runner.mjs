import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {deserialize} from '../src/persistence/snapshots.js';
import {Navigation as Candidate} from './worker-route-refinement/candidate-navigation-v6.mjs';
import {Navigation as Original} from '../src/world/navigation.js';
import * as CandidateGame from './candidate-game-v5.mjs';
import * as OriginalGame from '../src/simulation/game.js';
import {ANIMAL_ACTIONS} from '../src/simulation/animal-actions-data.js';
import {actorSegmentClear} from '../src/simulation/actor-motion.js';
import {LOCOMOTION as L} from '../src/simulation/locomotion-calibration.js';
const raw=gunzipSync(readFileSync('docs/qa/intensive-sabana-musgum-e461b550/state.json.gz')).toString(),profile=JSON.parse(readFileSync('public/content/biome-savanna.json')).profile;
const invalid=JSON.parse(readFileSync('.cache/worker-route-refinement/boundary-v3.json')).failure.rows.at(-1);
const make=Class=>{const s=deserialize(raw),nav=new Class(s.seed,s.biome,profile);nav.setState(s);return {s,nav};};
const results=[];
for(const [species,spec] of Object.entries(ANIMAL_ACTIONS.animals)){
 const radius=spec.presentation.footprint.radius,{s,nav}=make(Candidate),center=s.structures.find(x=>x.kind==='center');let location=null;
 outer:for(let dz=-24;dz<=24;dz+=4)for(let dx=-24;dx<=24;dx+=4){
  const c={x:center.x+dx,z:center.z+dz},a={x:c.x,z:c.z},ae={x:c.x,z:c.z+radius+4},w={x:c.x-radius-2,z:c.z},we={x:c.x+radius+2,z:c.z};
  if(nav.segmentClear(a,ae,radius,null,false)&&nav.segmentClear(w,we,.28,null,true)&&nav.walkable(w.x,w.z,.28,null,true)&&nav.walkable(we.x,we.z,.28,null,true)){location={a,ae,w,we};break outer;}
 }
 assert(location,'No legal native traffic location '+species);const arms=[];
 for(const mode of ['original','candidate']){
  const {s,nav}=make(mode==='original'?Original:Candidate),Game=mode==='original'?OriginalGame:CandidateGame;
  assert(!nav.terrainValid(invalid.x,invalid.z,.28,true),'Avoidance must be a confirmed native invalid terrain point');
  const worker={...location.w,id:'qa-moving-worker',status:'walking',radius:.28,qaTerrainAvoidance:[{x:invalid.x,z:invalid.z}]},animal={...location.a,id:'qa-retreating-animal',species,radius,status:'retreating',hitsRemaining:0};
  const state={structures:s.structures,workers:[worker],raid:{animals:[animal]}},workerGoal={...location.we,id:'qa-worker-goal'},animalGoal={...location.ae,id:'qa-animal-goal'},rows=[];let workerDone=false,animalDone=false;
  for(let step=0;step<600&&(!workerDone||!animalDone);step++){
   if(!workerDone){const before={x:worker.x,z:worker.z};workerDone=Game.walkTo(state,worker,workerGoal,.1,nav);assert(nav.walkable(worker.x,worker.z,.28,null,true));assert(Math.hypot(worker.x-before.x,worker.z-before.z)<=L.walkMetresPerSecond*.1+1e-8);if(!animalDone)assert(actorSegmentClear(before,worker,worker,[animal]));}
   if(!animalDone){const before={x:animal.x,z:animal.z};animalDone=Game.walkTo(state,animal,animalGoal,.1,nav,{speed:3.8,worker:false});assert(nav.walkable(animal.x,animal.z,radius,null,false));assert(Math.hypot(animal.x-before.x,animal.z-before.z)<=.38+1e-8);assert(actorSegmentClear(before,animal,animal,[worker]));if(animalDone)animal.status='gone';}
   rows.push({step,worker:{x:worker.x,z:worker.z},animal:{x:animal.x,z:animal.z},workerDone,animalDone});
  }
  assert(workerDone&&animalDone,'Both moving actors must reach destination '+species+'/'+mode);arms.push({mode,rows,steps:rows.length,workerDone,animalDone,views:nav.qaWorkerViews?.size??0,rejections:nav.qaMovementStats?.rejected??0});
 }
 assert.deepEqual(arms[0].rows,arms[1].rows);results.push({species,radius,location,arms});console.log(JSON.stringify({species,radius,steps:arms[1].steps,views:arms[1].views,rejections:arms[1].rejections}));
}
writeFileSync('.cache/worker-route-refinement/native-traffic-v6.json',JSON.stringify({scope:'QA native historical Sabana/Musgum terrain/props/buildings, one constructed moving worker and one exhausted retreating animal per species. Native controller radii, worker walk speed and production retreat3.8m/s. Other actors/clock frozen, no task/encounter/campaign or rendered acceptance. Existing confirmed terrain-invalid avoided point exercises private worker view; candidate/original positions identical every step, both finish, sampled terrain and swept body separation checked.',results},null,2)+'\n');
