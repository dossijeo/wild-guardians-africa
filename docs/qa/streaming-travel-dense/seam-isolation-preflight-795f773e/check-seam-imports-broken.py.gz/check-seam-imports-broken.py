import hashlib,json,re,urllib.request,urllib.parse
from pathlib import Path
root=Path.cwd()
result={}
patterns=[r'\b(?:import|export)\s+(?:[^;\n]*?\s+from\s+)?[\'"]([^\'"]+)[\'"]',r'\bimport\(\s*[\'"]([^\'"]+)[\'"]',r'new URL\(\s*[\'"]([^\'"]+)[\'"]\s*,\s*import\.meta\.url',r'fetch\(\s*[\'"](/[^\'"]+)[\'"]']
for port in [5398,5192]:
 origin=f'http://127.0.0.1:{port}'
 queue=[origin+'/tests/browser/streaming-travel.html?html-proxy&index=0.js']
 seen={};errors=[]
 while queue:
  url=queue.pop(0)
  if url in seen:continue
  try:
   response=urllib.request.urlopen(url,timeout=15);data=response.read();assert response.status==200
   seen[url.removeprefix(origin)]={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
   if not ('.js' in urllib.parse.urlparse(url).path or 'html-proxy' in url or urllib.parse.urlparse(url).path.endswith('.json')):continue
   text=data.decode().split('//# sourceMappingURL=')[0]
   for pattern in patterns:
    for dependency in re.findall(pattern,text):
     if dependency.startswith(('data:','node:','http:','https:')):continue
     if not dependency.startswith(('/','./','../')):continue
     resolved=urllib.parse.urljoin(url,dependency)
     if urllib.parse.urlparse(resolved).netloc==urllib.parse.urlparse(origin).netloc:queue.append(resolved)
  except Exception as error:errors.append({'url':url,'error':str(error)})
 result[str(port)]={'served':seen,'errors':errors,'scope':'Recursive static imports/exports, literal dynamic imports, worker newURL and absolute literal fetch from transformed fixture. Computed runtime assets require native functional load.'}
 print(port,'served',len(seen),'errors',errors)
(root/'.cache/seam-import-graph.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
assert not any(r['errors'] for r in result.values())
