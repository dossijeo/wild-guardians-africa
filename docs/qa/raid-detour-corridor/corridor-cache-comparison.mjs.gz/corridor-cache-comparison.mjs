import {prepareActorMotion as before} from './actor-motion-before-scope.mjs';
import {prepareActorMotion as current} from '../src/simulation/actor-motion.js';
for(const [source,prepare] of [['acaab75',before],['current',current]]){
 let searches=0;const nav={version:1,walkable:()=>true,segmentClear:()=>false,*findPathSteps(){searches++;yield null;yield null;return null;}};
 const actor={id:'actor',x:0,z:0,radius:.5,path:[{x:3,z:0}]},fallen={id:'fallen',x:1,z:0,radius:.5,incapacitated:true,status:'fleeing'},far={id:'remote',x:100,z:0,radius:2,status:'retreating'};
 const state={workers:[fallen],raid:{animals:[actor,far]}};
 for(let i=0;i<10;i++){far.x--;prepare(state,actor,nav,false);}
 console.log(JSON.stringify({source,searches}));
}
