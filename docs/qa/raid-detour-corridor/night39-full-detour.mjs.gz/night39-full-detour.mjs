import {readFileSync} from 'node:fs';import {gunzipSync} from 'node:zlib';
import {deserialize} from '../src/persistence/snapshots.js';import {Navigation,BIOME_IDS} from '../src/world/navigation.js';import {actorBlockers,actorSegmentClear} from '../src/simulation/actor-motion.js';
const s=deserialize(gunzipSync(readFileSync('docs/qa/paid-defense-failure-ee25c8c/failure-state.json.gz')).toString());
const nav=new Navigation(s.seed,s.biome,JSON.parse(readFileSync(`public/content/biome-${BIOME_IDS[s.biome]}.json`)).profile);nav.setState(s);
const a=s.raid.animals.find(a=>a.id==='animal-95772');const blockers=actorBlockers(s,a,false).map(b=>({...b}));
const clear=(x,y)=>actorSegmentClear(x,y,a,blockers);
console.log(JSON.stringify({actor:{x:a.x,z:a.z},path:a.path,blockers:blockers.map(b=>({id:b.id,x:b.x,z:b.z,r:b.radius}))}));
for(const goal of [{x:104,z:-1},a.approach]){
const search=Object.assign(Object.create(Object.getPrototypeOf(nav)),nav,{preparedPaths:null,walkCache:new Map(),segmentCache:new Map(),failedPaths:new Set(),closedRegions:new Map(),searchedRegions:[],searchNeighborCache:new Map(),portalGraphs:new Map(),testWalkable:(x,z,r,i,w)=>nav.walkable(x,z,r,i,w)&&clear({x,z},{x,z}),testSegmentClear:(x,y,r,i,w)=>nav.segmentClear(x,y,r,i,w)&&clear(x,y)});
const start=performance.now(),iterator=search.findPathSteps(a,goal,a.radius,null,false,32);let n=0,step;do{step=iterator.next();n++;}while(!step.done&&n<25000);
console.log(JSON.stringify({goal,slices:n,ms:performance.now()-start,done:step.done,path:step.value}));
}
