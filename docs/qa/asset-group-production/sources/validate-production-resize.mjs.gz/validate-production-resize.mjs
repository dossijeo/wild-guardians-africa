import fs from 'node:fs/promises';
import {compareColorPixels} from '../tools/image-pixel-comparison.mjs';
const read=async p=>JSON.parse(await fs.readFile(p,'utf8'));
const result=await read('.cache/asset-group-production/native-final.json');
const image=r=>Buffer.from(r.capturePng.split(',')[1],'base64');
const comparisons=[];
for(const name of ['base-A1','base-A2','candidate-B1-fixed','candidate-B2-fixed']){
 const reference=await read(`.cache/asset-group-resize/${name}.json`);
 comparisons.push({reference:name,frames:result.timing.firstRenderCalls.map((f,i)=>({drawEqual:JSON.stringify(f.groupDraw)===JSON.stringify(reference.timing.firstRenderCalls[i].groupDraw),renderEqual:JSON.stringify(f.renderInfo)===JSON.stringify(reference.timing.firstRenderCalls[i].renderInfo),memoryEqual:JSON.stringify(f.memory)===JSON.stringify(reference.timing.firstRenderCalls[i].memory)})),pixels:await compareColorPixels(image(reference),image(result))});
}
await fs.writeFile('.cache/asset-group-production/comparison-final.json',JSON.stringify({ok:result.ok,errors:result.errors,drawingBuffer:result.drawingBuffer,frames:result.timing.firstRenderCalls.map(f=>({cpuMs:f.cpuMs,calls:f.calls})),comparisons,scope:'Production resize integration vs archived same-scene QA baseline/candidate. Not GPU timing; CPU campaigns, tests and build may overlap.'},null,2)+'\n');
console.log(JSON.stringify(comparisons,null,2));
