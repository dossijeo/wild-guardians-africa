import {writeFileSync} from 'node:fs';
import {gzipSync} from 'node:zlib';
import * as Game from '../../src/simulation/game.js';
import {serialize} from '../../src/persistence/snapshots.js';
import {simulateNativeCampaign} from '../../tools/native-campaign-runner.mjs';
import {createSpatialCampaignOpening} from '../../tools/experiments/spatial-campaign-opening.mjs';
import {ANIMAL_SPATIAL_PROFILES} from '../../src/world/hierarchical-wasm/spatial-movement-profiles.js';

const out='.cache/native-intent-38799294071/enclosure-day2-diagnostic.json';
let opening;
const entryDriverFactory=()=>({
  async advancePresentation(){},async waitForEntry(){},report(){return {}},async dispose(){}
});
try{
  await simulateNativeCampaign({days:2,strategy:'good',biome:'sabana',seed:712,
    culture:'mapungubwe',nativeIntents:true,spatialAdvice:true,
    defensePolicy:'expanding',reloadRaids:false,nativeEvidence:false,
    openingFactory:async (...args)=>(opening=await createSpatialCampaignOpening(...args)),
    entryDriverFactory,
    onTick:(s,nav)=>{
      if(s.day!==2||s.time!==0)return;
      if(s.pauses.includes('hiring'))Game.hire(s,'diagnostic-hire',
        {olderFemale:Math.max(1,Math.ceil(s.plants.filter(p=>p.alive).length/6))});
      writeFileSync('tests/fixtures/sabana712-d2-enclosure-connectors.json.gz',
        gzipSync(serialize(s)));
      const loadedKeys=[...opening.session.stream.loaded().keys()];
      const bridge=nav.intentTaskPlanner;
      bridge.flushWorldEvents();
      const group=bridge.getUnprotectedCropGroups()[0];
      const margin=2.5,b=group.bounds;
      const points=[[b.minX-margin,b.minZ-margin],[b.maxX+margin,b.minZ-margin],
        [b.maxX+margin,b.maxZ+margin],[b.minX-margin,b.maxZ+margin],
        [b.minX-margin,b.minZ-margin]];
      const quote=Game.quoteWallChain(s,'zarzas',points,nav,
        {smooth:false,snap:false});
      const after=nav.withWallPreview(quote.previewPieces,quote.suppressed,()=>
        bridge.getUnprotectedCropGroups({includeProtected:true})
          .find(item=>item.id===group.id),true);
      const samples=nav.withWallPreview(quote.previewPieces,quote.suppressed,()=>
        Object.fromEntries(Object.entries(ANIMAL_SPATIAL_PROFILES).map(
          ([species,profile])=>[species,group.cropIds.reduce((counts,id)=>{
            const crop=s.plants.find(plant=>plant.id===id);
            const result=nav.enclosureFor(crop,profile.radius);
            const key=result.status??String(result);
            counts[key]=(counts[key]??0)+1;
            return counts;
          },{})])),true);
      const unknownSites=nav.withWallPreview(quote.previewPieces,quote.suppressed,
        ()=>Object.fromEntries(Object.entries(ANIMAL_SPATIAL_PROFILES).map(
          ([species,profile])=>[species,group.cropIds.map(id=>
            s.plants.find(plant=>plant.id===id)).filter(crop=>
            nav.enclosureFor(crop,profile.radius).status==='unknown')
            .map(crop=>({id:crop.id,x:crop.x,z:crop.z}))])),true);
      const probes=nav.withWallPreview(quote.previewPieces,quote.suppressed,()=>{
        const profile=ANIMAL_SPATIAL_PROFILES.warthog;
        return unknownSites.warthog.slice(0,3).map(site=>{
          const crop=s.plants.find(plant=>plant.id===site.id);
          const points=[];
          for(const x of new Set([Math.floor(crop.x),Math.ceil(crop.x)]))
            for(const z of new Set([Math.floor(crop.z),Math.ceil(crop.z)])){
              const point={x,z};
              points.push({point,clear:nav.segmentClear(crop,point,
                profile.radius,null,false),enclosure:nav.enclosureFor(point,
                profile.radius).status});
            }
          return {crop:site,points};
        });
      },true);
      const attackSamples=nav.withWallPreview(quote.previewPieces,
        quote.suppressed,()=>Object.fromEntries(Object.entries(
          ANIMAL_SPATIAL_PROFILES).map(([species,profile])=>[species,
          unknownSites[species].map(site=>{
            const samples=[];
            for(let i=0;i<12;i++){
              const angle=2*Math.PI*i/12;
              const point={x:site.x+Math.sin(angle)*(.6+profile.radius),
                z:site.z+Math.cos(angle)*(.6+profile.radius)};
              const grid={x:Math.round(point.x),z:Math.round(point.z)};
              if(!nav.segmentClear(point,grid,profile.radius,null,false))continue;
              samples.push({grid,status:nav.enclosureFor(grid,
                profile.radius).status});
            }
            return {id:site.id,samples};
          })])),true);
      writeFileSync(out,JSON.stringify({day:s.day,time:s.time,
        loadedKeys,
        centers:s.structures.filter(item=>item.kind==='center')
          .map(item=>({x:item.x,z:item.z,status:item.status})),
        group:{id:group.id,value:group.value,bounds:group.bounds,
          crops:group.cropIds.length,profiles:group.profiles},
        quote:{cost:quote.cost,expected:quote.expectedSlots.length,
          pieces:quote.pieces.length,blockedPhysical:quote.blockedPieces.length,
          blockedCrops:quote.blockedCrops.length,
          blockedPhysicalSites:quote.blockedPieces.map(piece=>
            ({x:piece.x,z:piece.z,yaw:piece.yaw}))},
        after:{protection:after?.protection,profiles:after?.profiles},
        samples,unknownSites,probes,attackSamples},null,2));
      throw Error('diagnostic-complete');
    }});
}catch(error){if(error.message!=='diagnostic-complete')throw error;}
