import {readFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {performance} from 'node:perf_hooks';
import {deserialize,serialize} from '../../src/persistence/snapshots.js';
import {createSpatialGameSession} from '../../src/world/hierarchical-wasm/spatial-game-session.js';
import {createSpatialNavigationMovement} from '../../src/world/hierarchical-wasm/spatial-navigation-movement.js';
import {createSpatialIntentBridge} from '../../src/world/hierarchical-wasm/spatial-intent-bridge.js';
import {createCropEnclosurePlanner} from '../../src/world/hierarchical-wasm/spatial-crop-enclosure-plan.js';

const binary=process.env.WILD_ENGINE_SPATIAL_SERVICES_WASM;
if(!binary)throw Error('WILD_ENGINE_SPATIAL_SERVICES_WASM is required');
const module=new WebAssembly.Module(readFileSync(binary));
const game=deserialize(gunzipSync(readFileSync(new URL(
  '../../tests/fixtures/sabana712-d2-enclosure-connectors.json.gz',import.meta.url))).toString());
const before=serialize(game),loaded=new Map();
const session=createSpatialGameSession(module,game,{loaded:()=>loaded,
  onData:data=>loaded.set(`${data.cx},${data.cz}`,data)});
try{
  const jobs=new Map();
  for(let z=-1;z<=1;z++)for(let x=1;x<=3;x++)
    jobs.set(`${x},${z}`,{cx:x,cz:z,score:Math.hypot(x,z)});
  session.stream.plan(jobs);await session.stream.whenIdle();
  const nav=createSpatialNavigationMovement(session,game);
  const bridge=createSpatialIntentBridge(session);bridge.resetFromState(game);
  const group=bridge.getUnprotectedCropGroups()[0];
  const planner=createCropEnclosurePlanner(game,nav,bridge);
  const start=performance.now();
  const plan=planner.planCropEnclosure(group.id,{material:'zarzas'});
  const elapsedMs=performance.now()-start;
  console.log(JSON.stringify({wasm:binary,groupId:group.id,crops:group.cropIds.length,
    status:plan.status,reason:plan.reason,cost:plan.cost,expectedSlots:plan.expectedSlots,
    modules:plan.modules?.length,gaps:plan.gaps?.length,
    elapsedMs:Number(elapsedMs.toFixed(2)),stateUnchanged:serialize(game)===before}));
}finally{session.dispose();}
