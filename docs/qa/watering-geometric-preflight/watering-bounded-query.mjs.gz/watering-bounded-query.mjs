import {readFileSync,writeFileSync} from 'node:fs';
import {performance} from 'node:perf_hooks';
import assert from 'node:assert/strict';
import {Navigation} from '../src/world/navigation.js';
import {deserialize,serialize} from '../src/persistence/snapshots.js';
import * as baseline from './watering-abba-canyon-bounded/old-work.mjs';
import * as candidate from './watering-abba-canyon-bounded/candidate-work.mjs';
const profile=JSON.parse(readFileSync(new URL('../public/content/biome-canyons.json',import.meta.url))).profile;
const fixtures=[['1','plant-38'],['10','plant-24']].map(([suffix,id])=>({suffix,id,state:deserialize(readFileSync(new URL(`./canyon-detour-snapshots/gran-canon-saheliana-detour-${suffix}.json`,import.meta.url),'utf8'))}));
function prepare(fixture){
 const nav=new Navigation(fixture.state.seed,fixture.state.biome,profile);nav.setState(fixture.state);
 return {nav,worker:fixture.state.workers.find(w=>w.id==='worker-14'),plant:fixture.state.plants.find(p=>p.id===fixture.id)};
}
const rows=[];
for(const fixture of fixtures){
 const before=serialize(fixture.state);
 for(const [index,arm] of ['A','B','B','A'].entries()){
  const algorithm=arm==='A'?baseline:candidate,samples=[];
  for(let repeat=0;repeat<12;repeat++){
   const {nav,worker,plant}=prepare(fixture),start=performance.now();
   const route=algorithm.wateringRoute(worker,plant,nav),ms=performance.now()-start;
   assert.ok(route);let previous=worker,length=0;
   for(const point of route.path){assert.ok(nav.segmentClear(previous,point,worker.radius??.28,null,true));length+=Math.hypot(point.x-previous.x,point.z-previous.z);previous=point;}
   assert.ok(algorithm.canWaterFrom({...route.destination,radius:worker.radius},plant,nav));
   samples.push({ms,length,destination:route.destination});
  }
  rows.push({fixture:fixture.suffix,index,arm,samples});
  console.log(JSON.stringify({fixture:fixture.suffix,index,arm,meanMs:samples.reduce((n,s)=>n+s.ms,0)/samples.length,length:samples[0].length}));
 }
 assert.equal(serialize(fixture.state),before);
}
writeFileSync(new URL('./watering-abba-canyon-bounded/equal-query-report.json',import.meta.url),JSON.stringify({scope:'Same real watering queries, fresh Navigation per sample prepared outside timed section; one process ABBA, 12 samples per arm; domain CPU only.',rows},null,2));
