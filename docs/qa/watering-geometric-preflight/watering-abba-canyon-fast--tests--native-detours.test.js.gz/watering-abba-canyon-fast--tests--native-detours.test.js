import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {Navigation} from 'file:///C:/Users/PC/source/repos/wild-guardians-africa/src/world/navigation.js';
import {wateringRoute,canWaterFrom} from '../candidate-work.mjs';
import {serialize,deserialize} from 'file:///C:/Users/PC/source/repos/wild-guardians-africa/src/persistence/snapshots.js';

for(const [suffix,plantId,maximum] of [['1','plant-38',14],['10','plant-24',16]]){
 test(`native Canyon watering detour ${suffix} uses a shorter physically valid side`,()=>{
  const s=deserialize(readFileSync(new URL(`../../canyon-detour-snapshots/gran-canon-saheliana-detour-${suffix}.json`,import.meta.url),'utf8'));
  const profile=JSON.parse(readFileSync(new URL('file:///C:/Users/PC/source/repos/wild-guardians-africa/public/content/biome-canyons.json'))).profile;
  const nav=new Navigation(s.seed,s.biome,profile);nav.setState(s);
  const worker=s.workers.find(w=>w.id==='worker-14'),plant=s.plants.find(p=>p.id===plantId),before=serialize(s);
  const original=worker.path.reduce((r,p)=>({point:p,length:r.length+Math.hypot(p.x-r.point.x,p.z-r.point.z)}),{point:worker,length:0}).length;
  assert.ok(original>30,'fixture retains the original real detour');
  const route=wateringRoute(worker,plant,nav);assert.ok(route);
  let length=0,previous=worker;
  for(const p of route.path){assert.ok(nav.segmentClear(previous,p,worker.radius??.28,null,true),'no shortcut through terrain or solids');length+=Math.hypot(p.x-previous.x,p.z-previous.z);previous=p;}
  assert.ok(length<maximum,`expected a bounded shorter route, got ${length}`);
  assert.ok(canWaterFrom({...route.destination,radius:worker.radius},plant,nav));
  assert.ok(Math.hypot(route.destination.x-plant.x,route.destination.z-plant.z)>=.82,'worker remains outside the crop');
  assert.equal(serialize(s),before,'route selection never advances or mutates the crop/task/save');
 });
}
test('ordinary unobstructed watering keeps its single path query',()=>{
 let calls=0;const worker={x:0,z:4,radius:.28},plant={id:'open',x:0,z:0,species:'mijo'},nav={walkable:()=>true,path:(_a,b)=>{calls++;return [{...b}];}};
 const route=wateringRoute(worker,plant,nav);assert.ok(route);assert.equal(calls,1);assert.equal(route.destination.id,'water-point-open-0');
});
