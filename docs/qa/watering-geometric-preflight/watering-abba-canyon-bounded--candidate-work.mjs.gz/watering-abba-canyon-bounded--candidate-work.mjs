import {centerGeometry} from 'file:///C:/Users/PC/source/repos/wild-guardians-africa/src/world/centers.js';
import {shortenBuildingRoute} from 'file:///C:/Users/PC/source/repos/wild-guardians-africa/src/world/building-route-shortcut.js';
function alternateWateringPath(worker,destination,route,radius,nav){
  const seed=[...route.slice(0,-1),destination];
  const shorter=shortenBuildingRoute(nav,worker,destination,seed,radius,null);
  // The seed only supplies a length bound: its new last edge is unverified.
  // Accept only a new shortcut whose two edges the helper validated.
  return shorter===seed?null:shorter;
}
// Service points outside the same footprints used by Navigation.
export function repairRoute(worker,target,nav){
  const radius=.28,clearance=.1;
  let points;
  if(target.kind==='center'){
    const angle=Math.atan2(worker.x-target.x,worker.z-target.z);
    points=Array.from({length:16},(_,i)=>{
      const offset=i===0?0:Math.ceil(i/2)*(i%2?1:-1)*Math.PI/8;
      return {x:target.x+Math.sin(angle+offset)*(centerGeometry(target,nav.state).radius+radius+clearance),z:target.z+Math.cos(angle+offset)*(centerGeometry(target,nav.state).radius+radius+clearance)};
    });
  }else{
    const scale=target.gate?(target.material==='reforzado'?1.6:['adobe','piedra'].includes(target.material)?1.4:1):1;
    const width=1.09*scale+radius+clearance,depth=.22+radius+clearance,c=Math.cos(target.yaw??0),s=Math.sin(target.yaw??0);
    points=[[0,depth],[0,-depth],[width,0],[-width,0]].map(([x,z])=>({x:target.x+x*c+z*s,z:target.z-x*s+z*c}));
    points.sort((a,b)=>Math.hypot(a.x-worker.x,a.z-worker.z)-Math.hypot(b.x-worker.x,b.z-worker.z));
  }
  for(const [index,point] of points.entries()){
    const destination={...point,id:`repair-point-${target.id}-${index}`},path=nav.path(worker,destination,radius,null,true);
    if(path)return {destination,path};
  }
  return null;
}

// Keep the worker body outside the crop interaction envelope. Try the near
// side first; blocked terrain/props/buildings use another physical approach.
export function canWaterFrom(worker,plant,nav){
  const reach=(plant.species==='platano'?.65:.45)+(worker.radius??.28)+.22;
  if(Math.hypot(worker.x-plant.x,worker.z-plant.z)>reach)return false;
  if(!nav.field?.surface||!nav.workerSurface)return true;
  // A close point on the canyon floor is not a watering point for a crop on
  // the plateau above it. River crossing permission does not extend the spout.
  return Math.abs(nav.workerSurface(worker.x,worker.z)-nav.field.surface(plant.x,plant.z))<=.5;
}
export function wateringRoute(worker,plant,nav){
  const radius=worker.radius??.28,standOff=(plant.species==='platano'?.65:.45)+radius+.1;
  const angle=Math.atan2(worker.x-plant.x,worker.z-plant.z);
  let best=null,bestLength=Infinity,initialLength=Infinity,alternateChecks=0;
  const offsets=[0,1,-1,2,-2,3,-3,4];
  // Preserve point IDs while prioritizing transverse detour exits.
  const pending=[...offsets];
  while(pending.length){
    const offset=pending.shift(),index=offsets.indexOf(offset);
    if(best&&alternateChecks>=4)break;
    const yaw=angle+offset*Math.PI/4,destination={x:plant.x+Math.sin(yaw)*standOff,z:plant.z+Math.cos(yaw)*standOff,id:`water-point-${plant.id}-${index}`};
    if(!canWaterFrom({...destination,radius},plant,nav))continue;
    if(nav.walkable?.(destination.x,destination.z,radius,null,true)===false)continue;
    let path;
    if(best){
      alternateChecks++;
      if(!nav.obstacles||!nav.segmentClear)break;
      path=nav.segmentClear(worker,destination,radius,null,true)?[{x:destination.x,z:destination.z}]:alternateWateringPath(worker,destination,best.path,radius,nav);
    }else path=nav.path(worker,destination,radius,null,true);
    if(path){
      let previous=worker,length=0;for(const point of path){length+=Math.hypot(point.x-previous.x,point.z-previous.z);previous=point;}
      const direct=Math.hypot(destination.x-worker.x,destination.z-worker.z);
      // Preserve the single-query near-side route in ordinary open ground.
      // A reachable near-side point can require circling a building or bank;
      // only those substantial detours justify checking other watering sides.
      if(!best&&(length<=direct*1.5||length-direct<=2))return {destination,path};
      if(!best){
        initialLength=length;
        pending.sort((a,b)=>[-2,1,2,-1,3,-3,4].indexOf(a)-[-2,1,2,-1,3,-3,4].indexOf(b));
      }
      if(length<bestLength){best={destination,path};bestLength=length;}
      if(bestLength<=initialLength*.8)return best;
      if(bestLength<=direct*1.25||bestLength-direct<=1)return best;
    }
  }
  return best;
}
