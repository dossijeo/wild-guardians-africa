import {readFileSync,writeFileSync} from 'node:fs';
let code=readFileSync('.cache/benchmark-worker-route-refinement-v3.mjs','utf8');
code=code.replace("import{Navigation}from'../src/world/navigation.js';","import{Navigation}from'./worker-route-refinement/candidate-navigation-v3.mjs';");
code="import * as GuardedGame from './candidate-game-v4.mjs';\n"+code;
code=code.replace("const Candidate=Original;","const Candidate=GuardedGame;");
code=code.replaceAll("candidate-navigation-v3.mjs'","candidate-navigation-v4.mjs'");
// Restore only the V3 reference import after replacing the candidate locations.
code=code.replace("import{Navigation}from'./worker-route-refinement/candidate-navigation-v4.mjs';","import{Navigation}from'./worker-route-refinement/candidate-navigation-v3.mjs';");
code=code.replace('refinement:nav.qaRefinement??null','refinement:nav.qaRefinement??null,movement:nav.qaMovementStats??null');
code=code.replace('sourceHashes:{game:hash(game),navigation:hash(idle),candidate:hash(candidate)}','sourceHashes:{game:hash(game),navigation:hash(idle),candidate:hash(candidate),candidateGame:hash(readFileSync(\'.cache/candidate-game-v4.mjs\')),guard:hash(readFileSync(\'.cache/worker-risk-clearance.mjs\')),v3:hash(readFileSync(\'.cache/worker-route-refinement/candidate-navigation-v3.mjs\'))}');
code=code.replace('report-v3.json','report-v4-guard-cost.json');
const a=code.indexOf("scope:'"),b=code.indexOf("',sourceHashes",a);
code=code.slice(0,a)+"scope:'QA guard-cost ABBA: reference V3 Navigation with original Game, candidate V4 Navigation and guarded Game. Native historical farm, ordinary paid hiring,100ticks per arm25warm75measured. Serialization outside timing, four live CPU campaigns. No GPU/phone acceptance. Compare full-state hashes before claiming identical work."+code.slice(b);
writeFileSync('.cache/benchmark-worker-route-refinement-v4-guard-cost.mjs',code);
