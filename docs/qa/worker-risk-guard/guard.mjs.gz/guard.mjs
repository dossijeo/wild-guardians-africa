import {fluidAt} from '../src/world/fluid-placement.js';
const verified=new WeakMap();
const peak=(nav,p,r)=>Math.max(...[[0,0],[r,0],[-r,0],[0,r],[0,-r]].map(([dx,dz])=>nav.field.canyon?Math.hypot(nav.workerSurface(p.x+dx+.8,p.z+dz)-nav.workerSurface(p.x+dx-.8,p.z+dz),nav.workerSurface(p.x+dx,p.z+dz+.8)-nav.workerSurface(p.x+dx,p.z+dz-.8))/1.6:nav.field.slope(p.x+dx,p.z+dz)));
export function workerRiskClearance(actor,nav,{radius,ignore},dynamicClear){
 let blocked=false;
 const clear=(start,end)=>{
  if(dynamicClear&&!dynamicClear(start,end))return false;
  const point=actor.path[0];if(!point)return true;
  nav.qaMovementStats??={classified:0,guarded:0,rejected:0};
  let record=verified.get(actor);
  if(!(record&&record.nav===nav&&record.version===nav.version&&record.radius===radius&&record.ignore===ignore&&record.path===actor.path&&record.point===point&&record.px===point.x&&record.pz===point.z&&record.x===start.x&&record.z===start.z&&Math.hypot(end.x-start.x,end.z-start.z)<=Math.hypot(record.boundary.x-start.x,record.boundary.z-start.z)+1e-9)){
   const length=Math.hypot(point.x-start.x,point.z-start.z),look=Math.max(4,Math.hypot(end.x-start.x,end.z-start.z));
   const boundary=length>look?{x:start.x+(point.x-start.x)*look/length,z:start.z+(point.z-start.z)*look/length}:point;
   const risk=nav.qaRiskSegment(start,boundary,radius,ignore);nav.qaMovementStats.classified++;
   record={nav,version:nav.version,radius,ignore,path:actor.path,point,px:point.x,pz:point.z,boundary,risky:!risk.valid||risk.peak>=.46};
  }
  if(record.risky){
   nav.qaMovementStats.guarded++;
   if(!nav.terrainValid(end.x,end.z,radius,true)){
    // Retain the existing marginal, improving recovery, never a new task exception.
    const recovering=['fleeing','returning','incapacitated'].includes(actor.status)&&!nav.terrainValid(start.x,start.z,radius,true);
    const before=recovering?peak(nav,start,radius):Infinity,after=recovering?peak(nav,end,radius):Infinity;
    const collision=Object.assign(Object.create(nav),{terrainValid:(x,z,r)=>nav.field.canyon||[[0,0],[r,0],[-r,0],[0,r],[0,-r]].every(([dx,dz])=>!fluidAt(nav.field,x+dx,z+dz)),segmentCache:new Map(),qaRefinedCache:new Map()});
    if(!(recovering&&before<=.51&&after<=before+1e-10&&collision.workerMotionClear(start,end,radius))){
     actor.qaTerrainAvoidance??=[];actor.qaTerrainAvoidance.push({x:end.x,z:end.z});if(actor.qaTerrainAvoidance.length>8)actor.qaTerrainAvoidance.shift();
     blocked=true;nav.qaMovementStats.rejected++;verified.delete(actor);return false;
    }
   }
  }
  record.x=end.x;record.z=end.z;verified.set(actor,record);return true;
 };
 return {clear,blocked:()=>blocked};
}
