import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
const base=new URL('../src/simulation/game.js',import.meta.url);
let game=readFileSync(base,'utf8').replace(/from '([^']+)'/g,(m,p)=>p.startsWith('.')?`from '${new URL(p,base).href}'`:m);
game="import {workerRiskClearance} from './worker-risk-clearance.mjs';\n"+game;
const assignment='w.path=nav.path(w,destination,w.radius??.28,ignore,worker);';assert.equal(game.split(assignment).length,2);
game=game.replace(assignment,'w.path=worker?nav.qaWorkerPath(w,destination,w.radius??.28,ignore):nav.path(w,destination,w.radius??.28,ignore,worker);');
game=game.replace('const routeClearance=worker?null:animalRouteClearance','const routeClearance=worker?workerRiskClearance(w,nav,{radius:w.radius??.28,ignore},dynamicClear):animalRouteClearance');
writeFileSync('.cache/candidate-game-v4.mjs',game);
let navigation=readFileSync('.cache/worker-route-refinement/candidate-navigation-v3.mjs','utf8');
const needle='  testSegmentClear(start,end,radius,ignore,worker,escapeProps=false) {';assert.equal(navigation.split(needle).length,2);
const methods=`  qaRiskSegment(start,end,radius,ignore){
    const previous=this.qaSweep,sweep={peak:0};this.qaSweep=sweep;let valid;
    try{valid=this.coarseSegmentClear(start,end,radius,ignore,true);}finally{this.qaSweep=previous;}
    return {valid,peak:sweep.peak};
  }
  qaWorkerPath(start,end,radius,ignore){
    const points=start.qaTerrainAvoidance;
    if(!points?.length)return this.path(start,end,radius,ignore,true);
    const view=Object.assign(Object.create(this),{segmentCache:new Map(),walkCache:new Map(),failedPaths:new Set(),closedRegions:new Map(),searchedRegions:[],searchNeighborCache:new Map(),portalGraphs:new Map(),preparedPaths:null,qaRefinedCache:new Map()});
    const test=view.testSegmentClear,walk=view.testWalkable;
    view.testSegmentClear=function(a,b,...args){return !points.some(p=>edgeDistance(a,b,p.x,p.z)<.00001)&&test.call(this,a,b,...args);};
    view.testWalkable=function(x,z,...args){return !points.some(p=>Math.hypot(x-p.x,z-p.z)<.00001)&&walk.call(this,x,z,...args);};
    return view.path(start,end,radius,ignore,true);
  }
`;
navigation=navigation.replace(needle,methods+needle);writeFileSync('.cache/worker-route-refinement/candidate-navigation-v4.mjs',navigation);
let quality=readFileSync('.cache/check-refinement-native-quality.mjs','utf8').replace("import * as Game from'../src/simulation/game.js';","import * as OriginalGame from'../src/simulation/game.js';import * as CandidateGame from'./candidate-game-v4.mjs';").replaceAll('candidate-navigation-v2.mjs','candidate-navigation-v4.mjs').replace(' const s=deserialize(raw)',' const Game=mode===\'reference\'?OriginalGame:CandidateGame;const s=deserialize(raw)').replaceAll('quality-v2.json','quality-v4.json');
writeFileSync('.cache/check-refinement-native-quality-v4.mjs',quality);
for(const [input,output] of [['.cache/check-worker-slope-native-v3.mjs','.cache/check-worker-slope-native-v4.mjs'],['.cache/check-refinement-v3-restore.mjs','.cache/check-refinement-v4-restore.mjs']]){
 const code=readFileSync(input,'utf8').replaceAll("'../src/simulation/game.js'","'./candidate-game-v4.mjs'").replaceAll('candidate-navigation-v3.mjs','candidate-navigation-v4.mjs').replaceAll('native-return-v3.json','native-return-v4.json').replaceAll('restore-v3.json','restore-v4.json');writeFileSync(output,code);
}
