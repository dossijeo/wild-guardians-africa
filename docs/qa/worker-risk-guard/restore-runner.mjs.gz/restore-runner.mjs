import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import * as Game from './candidate-game-v4.mjs';
import {deserialize,serialize} from '../src/persistence/snapshots.js';
import {Navigation} from './worker-route-refinement/candidate-navigation-v4.mjs';
const s=deserialize(gunzipSync(readFileSync('docs/qa/intensive-sabana-musgum-e461b550/state.json.gz')).toString()),profile=JSON.parse(readFileSync('public/content/biome-savanna.json')).profile;
const nav=new Navigation(s.seed,s.biome,profile);nav.setState(s);Game.continuePostgame(s);Game.hire(s,'qa-watering-diagnostic-hire',{olderFemale:Math.ceil(s.plants.filter(p=>p.alive).length/12)});
for(let i=0;i<10;i++)Game.tick(s,.1,nav);
const checkpoint=serialize(s),restored=deserialize(checkpoint),cold=new Navigation(restored.seed,restored.biome,profile);cold.setState(restored);
const rows=[];for(let i=1;i<=40;i++){Game.tick(s,.1,nav);Game.tick(restored,.1,cold);const a=serialize(s),b=serialize(restored);assert.equal(a,b,'Warm/cold serialized trajectory at tick '+i);rows.push({tick:i,sha256:createHash('sha256').update(a).digest('hex')});}
writeFileSync('.cache/worker-route-refinement/restore-v4.json',JSON.stringify({scope:'One native historical farm, saved after10 ticks and40 ordinary continuation ticks. Warm versus restored cold Navigation; full serialized equality every tick. Not all save states or biome acceptance.',checkpointSha256:createHash('sha256').update(checkpoint).digest('hex'),rows},null,2)+'\n');console.log('PASS40 warm/restored complete-state pairs');
