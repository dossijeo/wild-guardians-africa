import {readFileSync,writeFileSync} from 'node:fs';
let tests=readFileSync('tests/crop-navigation-cache.test.js','utf8')
 .replace("import {createOpeningWorld} from '../tools/check_opening.mjs';","import {createOpeningWorld as nativeOpening} from '../tools/check_opening.mjs';")
 .replace("import {Navigation} from '../src/world/navigation.js';","import {Navigation} from './no-crop-epoch-navigation.mjs';\nfunction createOpeningWorld(){const {s,nav:old}=nativeOpening();const nav=new Navigation(s.seed,s.biome,old.profile);nav.setState(s);return {s,nav};}")
 .replace('route epoch semantics','retained route epoch')
 .replace('assert.equal(nav.version,version+1);assert.equal(s.navigationVersion,nav.version);assert.equal(nav.state,s);','assert.equal(nav.version,version);assert.equal(s.navigationVersion,nav.version);assert.equal(nav.state,s);')
 .replace("Game.plant(s,'empty-crop-2','mijo',second.p.x,second.p.z,nav);assert.equal(nav.version,version+2);","Game.plant(s,'empty-crop-2','mijo',second.p.x,second.p.z,nav);assert.equal(nav.version,version);");
tests+=`
test('native moving worker remains full-state equivalent across cold restore and another cleared-ground purchase',()=>{
 const {s,nav}=createOpeningWorld(),plots=[];
 for(let i=0;i<4;i++)plots.push(site(s,nav,{away:plots.map(x=>x.p)}));
 for(let i=0;i<3;i++)Game.plant(s,'restore-seed-'+i,'mijo',plots[i].p.x,plots[i].p.z,nav);
 Game.openInitialHiring(s);Game.hire(s,'restore-paid-worker',{olderFemale:1});
 assert.equal(s.workers.length,1);assert.equal(s.pauses.length,0);
 const start={x:s.workers[0].x,z:s.workers[0].z};
 for(let i=0;i<80;i++)Game.tick(s,.1,nav);
 assert(Math.hypot(s.workers[0].x-start.x,s.workers[0].z-start.z)>1e-6,'Worker must physically move before restore');
 assert.notEqual(s.workers[0].status,'home');
 const loaded=deserialize(serialize(s)),cold=new Navigation(s.seed,s.biome,nav.profile);cold.setState(loaded);
 const epoch=nav.version;assert.equal(cold.version,epoch);let compared=0,movingTicks=0;
 for(let i=0;i<50;i++){
  if(i===10)for(const [state,n] of [[s,nav],[loaded,cold]]){
   const p=plots[3].p,check=n.placement(p.x,p.z,.4);assert(check.valid&&check.suppress.length===0);
   Game.plant(state,'restore-after-load-plant','mijo',p.x,p.z,n);assert.equal(n.version,epoch);
  }
  const before={x:s.workers[0].x,z:s.workers[0].z};
  Game.tick(s,.1,nav);Game.tick(loaded,.1,cold);assert.equal(serialize(s),serialize(loaded));compared++;
  if(Math.hypot(s.workers[0].x-before.x,s.workers[0].z-before.z)>1e-6)movingTicks++;
 }
 assert.equal(compared,50);assert(movingTicks>0,'Cold comparison must exercise physical movement');
});
`;
writeFileSync('.cache/no-crop-epoch-restore.test.mjs',tests);
