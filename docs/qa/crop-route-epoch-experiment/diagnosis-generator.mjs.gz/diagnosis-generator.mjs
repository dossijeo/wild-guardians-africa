import {readFileSync,writeFileSync} from 'node:fs';
const benchmark=readFileSync('.cache/benchmark-no-crop-epoch.mjs','utf8');
const prefix=benchmark.slice(0,benchmark.indexOf('for(const mode of'));
const body=`
const reference=setup(Native),candidate=setup(Candidate),checkpoints=[];
const project=s=>{const p=JSON.parse(serialize(s));delete p.navigationVersion;for(const w of p.workers)delete w.pathVersion;for(const a of p.raid?.animals??[])delete a.pathVersion;return p;};
function differences(a,b,path='',out=[]){
 if(Object.is(a,b))return out;
 if(!a||!b||typeof a!=='object'||typeof b!=='object'){if(out.length<80)out.push({path,reference:a,candidate:b});return out;}
 for(const k of new Set([...Object.keys(a),...Object.keys(b)]))differences(a[k],b[k],path+'.'+k,out);
 return out;
}
for(let tick=0;tick<100;tick++){
 for(const {state,nav} of [reference,candidate]){
  if(tick%10===0){const p=sites[tick/10],check=nav.placement(p.x,p.z,.4);assert(check.valid&&check.suppress.length===0);Game.plant(state,'qa-clear-replant-'+tick,'mijo',p.x,p.z,nav);}
  Game.tick(state,.1,nav);
 }
 const a=project(reference.state),b=project(candidate.state),diff=differences(a,b);
 const workerDifferences=reference.state.workers.flatMap(w=>{const q=candidate.state.workers.find(q=>q.id===w.id);if(!q)return [{id:w.id,missing:true}];const distance=Math.hypot(w.x-q.x,w.z-q.z);return distance>1e-9||w.status!==q.status||w.taskId!==q.taskId?[{id:w.id,distance,status:[w.status,q.status],taskId:[w.taskId,q.taskId]}]:[];});
 if((diff.length&&!checkpoints.length)||tick===20||tick===50||tick===99)checkpoints.push({tick,differences:diff,workerDifferences});
}
const report={scope:'Untimed native paired diagnosis, identical ten paid normal replants and 100 ticks as benchmark. Only epoch metadata excluded from state differences; first differences capped at80 per checkpoint.',sites,checkpoints,final:{reference:project(reference.state),candidate:project(candidate.state)}};
writeFileSync('.cache/no-crop-epoch-diagnosis.json',JSON.stringify(report,null,2)+'\\n');console.log(JSON.stringify(checkpoints.map(c=>({tick:c.tick,firstDifferences:c.differences.slice(0,8),workerCount:c.workerDifferences.length,maxDistance:Math.max(0,...c.workerDifferences.map(w=>w.distance??0))})),null,2));
`;
writeFileSync('.cache/no-crop-epoch-diagnostic-run.mjs',prefix+body);
await import('./no-crop-epoch-diagnostic-run.mjs');
