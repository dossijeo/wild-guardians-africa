import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import {Navigation as Native} from '../src/world/navigation.js';
import {Navigation as Candidate} from './no-crop-epoch-navigation.mjs';
import * as Game from '../src/simulation/game.js';
import {deserialize,serialize} from '../src/persistence/snapshots.js';
import {centerServicePoint} from '../src/world/centers.js';
const raw=gunzipSync(readFileSync('docs/qa/intensive-sabana-musgum-e461b550/state.json.gz')).toString(),profile=JSON.parse(readFileSync('public/content/biome-savanna.json')).profile;
const hash=b=>createHash('sha256').update(b).digest('hex'),median=a=>[...a].sort((a,b)=>a-b)[Math.floor(a.length/2)];
const setup=Class=>{const state=deserialize(raw),nav=new Class(state.seed,state.biome,profile);nav.setState(state);Game.continuePostgame(state);Game.hire(state,'qa-crop-epoch-hire',{olderFemale:Math.ceil(state.plants.filter(p=>p.alive).length/12)});return {state,nav};};
const {state:selection,nav:selectionNav}=setup(Native),origin=centerServicePoint(selection.structures[0],selection,.8),sites=[];
for(const p of selection.plants){if(p.alive||sites.some(q=>Math.hypot(p.x-q.x,p.z-q.z)<1.1)||selection.plants.some(q=>q.alive&&Math.hypot(p.x-q.x,p.z-q.z)<1.1))continue;const c=selectionNav.placement(p.x,p.z,.4);if(c.valid&&c.suppress.length===0&&selectionNav.path(origin,p,.28,null,true)&&selectionNav.path(p,origin,.28,null,true))sites.push({x:p.x,z:p.z});if(sites.length===10)break;}
assert.equal(sites.length,10,'Need ten genuinely clear, separated, natively reachable replants');const runs=[];

const reference=setup(Native),candidate=setup(Candidate),checkpoints=[];
const project=s=>{const p=JSON.parse(serialize(s));delete p.navigationVersion;for(const w of p.workers)delete w.pathVersion;for(const a of p.raid?.animals??[])delete a.pathVersion;return p;};
function differences(a,b,path='',out=[]){
 if(Object.is(a,b))return out;
 if(!a||!b||typeof a!=='object'||typeof b!=='object'){if(out.length<80)out.push({path,reference:a,candidate:b});return out;}
 for(const k of new Set([...Object.keys(a),...Object.keys(b)]))differences(a[k],b[k],path+'.'+k,out);
 return out;
}
for(let tick=0;tick<100;tick++){
 for(const {state,nav} of [reference,candidate]){
  if(tick%10===0){const p=sites[tick/10],check=nav.placement(p.x,p.z,.4);assert(check.valid&&check.suppress.length===0);Game.plant(state,'qa-clear-replant-'+tick,'mijo',p.x,p.z,nav);}
  Game.tick(state,.1,nav);
 }
 const a=project(reference.state),b=project(candidate.state),diff=differences(a,b);
 const workerDifferences=reference.state.workers.flatMap(w=>{const q=candidate.state.workers.find(q=>q.id===w.id);if(!q)return [{id:w.id,missing:true}];const distance=Math.hypot(w.x-q.x,w.z-q.z);return distance>1e-9||w.status!==q.status||w.taskId!==q.taskId?[{id:w.id,distance,status:[w.status,q.status],taskId:[w.taskId,q.taskId]}]:[];});
 if((diff.length&&!checkpoints.length)||tick===20||tick===50||tick===99)checkpoints.push({tick,differences:diff,workerDifferences});
}
const report={scope:'Untimed native paired diagnosis, identical ten paid normal replants and 100 ticks as benchmark. Only epoch metadata excluded from state differences; first differences capped at80 per checkpoint.',sites,checkpoints,final:{reference:project(reference.state),candidate:project(candidate.state)}};
writeFileSync('.cache/no-crop-epoch-diagnosis.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(checkpoints.map(c=>({tick:c.tick,firstDifferences:c.differences.slice(0,8),workerCount:c.workerDifferences.length,maxDistance:Math.max(0,...c.workerDifferences.map(w=>w.distance??0))})),null,2));
