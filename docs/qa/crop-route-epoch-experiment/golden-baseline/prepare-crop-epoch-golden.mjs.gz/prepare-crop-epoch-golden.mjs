import {readFileSync as read,writeFileSync as write} from 'node:fs';
import {gunzipSync} from 'node:zlib';
const original=gunzipSync(read('docs/qa/crop-route-epoch-experiment/production-navigation.js.gz')).toString();
write('.cache/golden-reference-navigation.mjs',original.replaceAll("from './","from '../src/world/"));
write('.cache/golden-reference-opening.mjs',read('tools/check_opening.mjs','utf8').replace("from '../src/world/navigation.js'","from './golden-reference-navigation.mjs'"));
write('.cache/golden-reference-intensive.mjs',read('tools/check_intensive_farm.mjs','utf8').replaceAll("from './","from '../tools/").replaceAll("from '../tools/check_opening.mjs'","from './golden-reference-opening.mjs'"));
console.log('Prepared archived navigation-only reference, unchanged current Game and strategy');
