import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import {Navigation as Native} from '../src/world/navigation.js';
import {Navigation as Candidate} from './no-crop-epoch-navigation.mjs';
import * as Game from '../src/simulation/game.js';
import {deserialize,serialize} from '../src/persistence/snapshots.js';
import {centerServicePoint} from '../src/world/centers.js';
const raw=gunzipSync(readFileSync('docs/qa/intensive-sabana-musgum-e461b550/state.json.gz')).toString(),profile=JSON.parse(readFileSync('public/content/biome-savanna.json')).profile;
const hash=b=>createHash('sha256').update(b).digest('hex'),median=a=>[...a].sort((a,b)=>a-b)[Math.floor(a.length/2)];
const setup=Class=>{const state=deserialize(raw),nav=new Class(state.seed,state.biome,profile);nav.setState(state);Game.continuePostgame(state);Game.hire(state,'qa-crop-epoch-hire',{olderFemale:Math.ceil(state.plants.filter(p=>p.alive).length/12)});return {state,nav};};
const {state:selection,nav:selectionNav}=setup(Native),origin=centerServicePoint(selection.structures[0],selection,.8),sites=[];
for(const p of selection.plants){if(p.alive||sites.some(q=>Math.hypot(p.x-q.x,p.z-q.z)<1.1)||selection.plants.some(q=>q.alive&&Math.hypot(p.x-q.x,p.z-q.z)<1.1))continue;const c=selectionNav.placement(p.x,p.z,.4);if(c.valid&&c.suppress.length===0&&selectionNav.path(origin,p,.28,null,true)&&selectionNav.path(p,origin,.28,null,true))sites.push({x:p.x,z:p.z});if(sites.length===10)break;}
assert.equal(sites.length,10,'Need ten genuinely clear, separated, natively reachable replants');const runs=[];
for(const mode of ['reference','candidate','candidate','reference']){
 const {state:s,nav}=setup(mode==='reference'?Native:Candidate),calls={path:0},path=nav.path;nav.path=function(...args){calls.path++;return path.apply(this,args);};
 const samples=[],plantSamples=[],hashes=[],physicalHashes=[],violations=[],pathCalls=[];let validBefore=null;
 for(let tick=0;tick<100;tick++){
  const before=new Map(s.workers.filter(w=>w.status!=='home').map(w=>[w.id,nav.walkable(w.x,w.z,w.radius??.28,null,true)])),queryStart=calls.path;
  let plantMs=0;
  if(tick%10===0){const p=sites[tick/10],check=nav.placement(p.x,p.z,.4);assert(check.valid&&check.suppress.length===0);const t=performance.now();Game.plant(s,'qa-clear-replant-'+tick,'mijo',p.x,p.z,nav);plantMs=performance.now()-t;plantSamples.push(plantMs);}
  const t=performance.now();Game.tick(s,.1,nav);const ms=performance.now()-t;if(tick>=25)samples.push(ms);pathCalls.push(calls.path-queryStart);
  for(const w of s.workers)if(before.get(w.id)&&w.status!=='home'&&!nav.walkable(w.x,w.z,w.radius??.28,null,true))violations.push({tick,id:w.id,x:w.x,z:w.z,status:w.status});
  const serialized=serialize(s);hashes.push(hash(serialized));const projected=JSON.parse(serialized);delete projected.navigationVersion;for(const w of projected.workers)delete w.pathVersion;for(const a of projected.raid?.animals??[])delete a.pathVersion;physicalHashes.push(hash(JSON.stringify(projected)));
 }
 const row={mode,medianMs:median(samples),samplesMs:samples,plantSamplesMs:plantSamples,pathCalls,totalPathCalls:calls.path,hashes,physicalHashes,violations,final:{day:s.day,time:s.time,epoch:nav.version,money:s.ledger.balance,living:s.plants.filter(p=>p.alive).length,tasks:s.tasks.length}};runs.push(row);console.log(JSON.stringify({mode,medianMs:row.medianMs,totalPathCalls:row.totalPathCalls,violations:row.violations.length}));
}
const sourceHashes=Object.fromEntries(['.cache/no-crop-epoch-navigation.mjs','src/world/navigation.js','src/simulation/game.js'].map(p=>[p,hash(readFileSync(p))]));
const report={scope:'QA native historical Sabana/Musgum dense farm,112paid workers,ten normal millet replants on verified cleared/reachable separated old plots at one per simulated second; production Nav/Game vs QA no-epoch-change only for identical state and no removed props. ABBA100ticks/25warm/75measured, plant times separate, validity/serialization/projection outside timing. Physical projection omits only nav/path epoch metadata; differing trajectories remain detectable. Four background campaigns known live; no GPU/phone or production promotion.',sites,sourceHashes,runs,firstFullDivergence:runs.map(r=>r.hashes.findIndex((h,i)=>h!==runs[0].hashes[i])),firstPhysicalDivergence:runs.map(r=>r.physicalHashes.findIndex((h,i)=>h!==runs[0].physicalHashes[i])),referenceMedian:median(runs.filter(r=>r.mode==='reference').flatMap(r=>r.samplesMs)),candidateMedian:median(runs.filter(r=>r.mode==='candidate').flatMap(r=>r.samplesMs))};
writeFileSync('.cache/no-crop-epoch-report.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({referenceMedian:report.referenceMedian,candidateMedian:report.candidateMedian,firstFullDivergence:report.firstFullDivergence,firstPhysicalDivergence:report.firstPhysicalDivergence}));
