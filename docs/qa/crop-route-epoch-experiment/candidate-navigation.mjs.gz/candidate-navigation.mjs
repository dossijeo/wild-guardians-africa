import {Navigation as Native} from '../src/world/navigation.js';
// QA candidate only: ordinary real geometry/state changes keep full rebuilds.
export class Navigation extends Native {
 syncCropPlacement(state,removedProps=[]){
  if(this.state!==state||removedProps.length)return this.setState(state);
 }
}
