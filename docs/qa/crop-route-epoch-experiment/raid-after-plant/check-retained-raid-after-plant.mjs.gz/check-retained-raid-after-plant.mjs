import assert from 'node:assert/strict';
import {writeFileSync} from 'node:fs';
import {createOpeningWorld} from '../tools/check_opening.mjs';
import * as Game from '../src/simulation/game.js';
import {Navigation} from '../src/world/navigation.js';
import {activeChunkRegion} from '../src/world/active-region.js';
import {centerServicePoint} from '../src/world/centers.js';
import {raidEntryKey,raidEntryRequest} from '../src/world/raid-entry-data.js';
import {computeRaidEntry} from '../src/world/compute-raid-entry.js';
import {spawnRaid} from '../src/simulation/raids.js';
import {serialize,deserialize} from '../src/persistence/snapshots.js';
const {s,nav}=createOpeningWorld(),center=s.structures[0],origin=centerServicePoint(center,s,.8),sites=[];
for(let dz=-15;dz<=15;dz+=1.5)for(let dx=6;dx<=30;dx+=1.5){const p={x:center.x+dx,z:center.z+dz},check=nav.placement(p.x,p.z,.4);if(check.valid&&!check.suppress.length&&nav.segmentClear(origin,p,.28,null,true))sites.push(p);}
assert(sites.length>1);Game.plant(s,'intensive-plant-raid-first','mijo',sites[0].x,sites[0].z,nav);Game.openInitialHiring(s);Game.hire(s,'raid-paid-worker',{olderFemale:1});
nav.setActiveBounds(activeChunkRegion(center).bounds);nav.setRaidView({x:center.x,z:center.z+8},center);
const group=['warthog'],key=raidEntryKey(s,nav,group),before=serialize(s),reply=computeRaidEntry(raidEntryRequest(s,nav,group,key,1));assert.equal(serialize(s),before);assert(reply.entry);
const spawn=reply.entry.entries[0],second=sites.filter(p=>Math.hypot(p.x-sites[0].x,p.z-sites[0].z)>1.5).sort((a,b)=>Math.hypot(a.x-spawn.x,a.z-spawn.z)-Math.hypot(b.x-spawn.x,b.z-spawn.z))[0];assert(second);
const epoch=nav.version;Game.plant(s,'intensive-plant-raid-after-prepare','maiz',second.x,second.z,nav);assert.equal(nav.version,epoch);assert.equal(raidEntryKey(s,nav,group),key);
const make=()=>{const state=deserialize(serialize(s)),n=new Navigation(s.seed,s.biome,nav.profile);n.setState(state);n.setActiveBounds(nav.activeBounds);n.setRaidView(nav.raidView.eye,nav.raidView.target);return {state,nav:n};};
const reference=make(),prepared=make();prepared.nav.preparedRaidEntry=(state,g,b)=>raidEntryKey(state,prepared.nav,g,b)===reply.key?reply:undefined;
const plan={group,introductory:true};spawnRaid(reference.state,plan,reference.nav);spawnRaid(prepared.state,plan,prepared.nav);assert.equal(serialize(prepared.state),serialize(reference.state));
let moving=0;const targets=new Set();
for(let step=0;step<200;step++){const animal=prepared.state.raid?.animals[0],prior=animal&&{x:animal.x,z:animal.z};Game.tick(reference.state,.05,reference.nav);Game.tick(prepared.state,.05,prepared.nav);assert.equal(serialize(prepared.state),serialize(reference.state),'Prepared old warmth changed complete state at '+step);const next=prepared.state.raid?.animals[0];if(next?.targetId)targets.add(next.targetId);if(prior&&next&&Math.hypot(next.x-prior.x,next.z-prior.z)>1e-6)moving++;}
assert(moving>0);assert(targets.has(s.plants[1].id),'Animal must choose the new higher-value crop absent from the preparation request');
const report={scope:'Native paid crop added after entry preparation, retained geometry epoch. Current live targets/reservations and complete motion state compared over200x.05seconds; one seed712 Sabana/Mapungubwe/warthog case, no GPU or all-biome claim.',epoch,first:s.plants[0].id,second:s.plants[1].id,movingTicks:moving,targets:[...targets],preparedPaths:reply.warmth.paths.length,statesCompared:201,finalState:serialize(prepared.state)};
writeFileSync('.cache/retained-raid-after-plant-report.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({...report,finalState:undefined}));
