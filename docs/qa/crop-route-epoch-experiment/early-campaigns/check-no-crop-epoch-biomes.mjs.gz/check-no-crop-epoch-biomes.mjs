import {spawnSync} from 'node:child_process';
const cases=[['gran-rio','saheliana'],['manglares','suajili'],['volcanes','etiope'],['gran-canon','mapungubwe'],['desierto','musgum']];
for(const [biome,culture] of cases){
 console.log(JSON.stringify({starting:biome+'-'+culture}));
 const r=spawnSync(process.execPath,['.cache/check-no-crop-epoch-campaign.mjs',biome,culture],{stdio:'inherit'});
 if(r.status!==0){process.exitCode=r.status??1;console.error('Case failed: '+biome+'/'+culture);break;}
}
