import {readFileSync as read,writeFileSync as write} from 'node:fs';
write('.cache/no-crop-epoch-campaign-navigation.mjs',`import {Navigation as Candidate} from './no-crop-epoch-navigation.mjs';
export {BIOME_IDS} from '../src/world/navigation.js';
export class Navigation extends Candidate {
 syncCropPlacement(state,removedProps=[]){
  const version=this.version,retained=this.state===state&&!removedProps.length;
  super.syncCropPlacement(state,removedProps);
  const stats=this.qaCropEpoch??={retained:0,rebuild:0,retainedEpochViolations:0,removedProps:0};
  stats[retained?'retained':'rebuild']++;stats.removedProps+=removedProps.length;
  if(retained&&this.version!==version)stats.retainedEpochViolations++;
 }
}
`);
const opening=read('tools/check_opening.mjs','utf8').replace("from '../src/world/navigation.js'","from './no-crop-epoch-campaign-navigation.mjs'");
write('.cache/opening-no-crop-epoch.mjs',opening);
let intensive=read('tools/check_intensive_farm.mjs','utf8').replace("from './check_opening.mjs'","from './opening-no-crop-epoch.mjs'");
for(const p of ['intensive-run-provenance','farm-defense-policy'])intensive=intensive.replace(`from './${p}.mjs'`,`from '../tools/${p}.mjs'`);
write('.cache/intensive-no-crop-epoch.mjs',intensive);
