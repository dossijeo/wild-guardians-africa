import {Navigation as Candidate} from './no-crop-epoch-navigation.mjs';
export {BIOME_IDS} from '../src/world/navigation.js';
export class Navigation extends Candidate {
 syncCropPlacement(state,removedProps=[]){
  const version=this.version,retained=this.state===state&&!removedProps.length;
  super.syncCropPlacement(state,removedProps);
  const stats=this.qaCropEpoch??={retained:0,rebuild:0,retainedEpochViolations:0,removedProps:0};
  stats[retained?'retained':'rebuild']++;stats.removedProps+=removedProps.length;
  if(retained&&this.version!==version)stats.retainedEpochViolations++;
 }
}
