import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {simulateIntensiveFarm,auditIntensiveFarm} from './intensive-no-crop-epoch.mjs';
import {serialize} from '../src/persistence/snapshots.js';
import {createIntensiveHeartbeat} from '../tools/intensive-heartbeat.mjs';
const biome=process.argv[2]??'sabana',culture=process.argv[3]??'musgum',key=biome+'-'+culture;
const sourceHashes=Object.fromEntries(['.cache/no-crop-epoch-navigation.mjs','.cache/no-crop-epoch-campaign-navigation.mjs','.cache/opening-no-crop-epoch.mjs','.cache/intensive-no-crop-epoch.mjs','src/world/navigation.js','src/simulation/game.js','tools/check_opening.mjs','tools/check_intensive_farm.mjs','public/content/villages.json'].map(p=>[p,createHash('sha256').update(readFileSync(p)).digest('hex')]));
const heartbeat=createIntensiveHeartbeat();let last=null,prior=new Map(),violationCount=0,sampledCallbacks=0;const violations=[];
try{
 const result=simulateIntensiveFarm({days:5,biome,culture,seed:712,mixed:true,onDay:day=>console.log(JSON.stringify({day})),onTick:(s,nav)=>{
  last=s;sampledCallbacks++;
  const next=new Map();
  for(const w of s.workers)if(w.status!=='home'){
   const valid=nav.walkable(w.x,w.z,w.radius??.28,null,true);
   if(prior.get(w.id)?.valid&&!valid){violationCount++;if(violations.length<100)violations.push({day:s.day,time:s.time,id:w.id,before:prior.get(w.id),after:{x:w.x,z:w.z,status:w.status},raid:!!s.raid});}
   next.set(w.id,{valid,x:w.x,z:w.z,status:w.status});
  }
  prior=next;const live=heartbeat(s);if(live){writeFileSync('.cache/no-crop-epoch-'+key+'-status.json',JSON.stringify({pid:process.pid,status:'running',live})+'\n');console.log(JSON.stringify({live}));}
 }});
 auditIntensiveFarm(result);const {state,nav,...report}=result;
 if(report.completedNights!==5||report.result==='defeat')throw Error('Responsible opening did not finish five nights');
 if(!report.daily.every(d=>d.staff>0&&d.delivered>0))throw Error('Day lacks paid labour or physical deliveries');
 if(!nav.qaCropEpoch?.retained||nav.qaCropEpoch.retainedEpochViolations)throw Error('Retained clear-plant epoch contract not exercised correctly');
 const bytes=serialize(state),stateHash=createHash('sha256').update(bytes).digest('hex');writeFileSync('.cache/no-crop-epoch-'+key+'-state.json',bytes);
 const output={scope:'QA no-crop-epoch candidate with unchanged production Game: responsible seed712 opening, five nights, paid ordinary commands/native terrain, physical delivery and automatic raid snapshot reloads. Callback endpoint validity observations are not continuous/internal-tick proof; invalid-before origins excluded. No CPU/GPU timing, equality against original or full100night/category acceptance.',...report,sourceHashes,stateHash,cropEpoch:nav.qaCropEpoch,sampledCallbacks,violationCount,violations};
 writeFileSync('.cache/no-crop-epoch-'+key+'-report.json',JSON.stringify(output,null,2)+'\n');
 writeFileSync('.cache/no-crop-epoch-'+key+'-status.json',JSON.stringify({pid:process.pid,status:'passed',completedNights:report.completedNights,violationCount})+'\n');
 console.log(JSON.stringify({completedNights:report.completedNights,money:report.money,reloads:report.reloads,counts:report.counts,cropEpoch:nav.qaCropEpoch,violationCount}));
}catch(e){if(last)writeFileSync('.cache/no-crop-epoch-'+key+'-failure-state.json',serialize(last));const error={name:e.name,message:e.message};writeFileSync('.cache/no-crop-epoch-'+key+'-error.json',JSON.stringify(error,null,2)+'\n');writeFileSync('.cache/no-crop-epoch-'+key+'-status.json',JSON.stringify({pid:process.pid,status:'failed',error})+'\n');console.error(e.message);process.exitCode=1;}
