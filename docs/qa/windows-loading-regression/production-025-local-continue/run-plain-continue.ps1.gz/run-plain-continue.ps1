$ErrorActionPreference='Stop'
$exe=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot 'wild-guardians-africa.exe')).Path
$fixture=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../windows-pair-28b-38024049488-root/local-control/fixture.json')).Path
if((Get-FileHash -LiteralPath $exe -Algorithm SHA256).Hash -ne '984a4ed7000a43ae1cb3939a89d9c3d0a3268cb30fa314b73c16f3a83f3fdfcb'){throw 'EXE mismatch'}
if((Get-FileHash -LiteralPath $fixture -Algorithm SHA256).Hash -ne '28d8bf348c61900a7f4f94a53026a86e638acbca5b058981a43de969788a6406'){throw 'Fixture mismatch'}
if(Get-Process -Name 'wild-guardians-africa' -ErrorAction SilentlyContinue){throw 'Game process already active'}
$output=Join-Path $PSScriptRoot 'plain-continue-control'
if(Test-Path -LiteralPath $output){throw 'Prior evidence exists; do not overwrite'}
New-Item -ItemType Directory -Path $output | Out-Null
$report=Join-Path $output 'desktop-smoke.json'
$profile=Join-Path $output 'webview-profile'
$previousProfile=[Environment]::GetEnvironmentVariable('WEBVIEW2_USER_DATA_FOLDER','Process')
$receipt=[ordered]@{source='02554d0a';exeSha256='984a4ed7000a43ae1cb3939a89d9c3d0a3268cb30fa314b73c16f3a83f3fdfcb';fixtureSha256='28d8bf348c61900a7f4f94a53026a86e638acbca5b058981a43de969788a6406';helperPid=$PID;startedAt=[DateTime]::UtcNow.ToString('o');scope='Plain native Continue; unchanged local90s budget; no trace, overlap or visual capture. Cross-build performance attribution unavailable.'}
if([Environment]::GetEnvironmentVariable('WG_DESKTOP_SMOKE_CI','Process')){throw 'Unexpected CI environment for local test'}
$owned=$null
try {
 [Environment]::SetEnvironmentVariable('WEBVIEW2_USER_DATA_FOLDER',$profile,'Process')
 $args=@('--smoke-report',('"'+$report+'"'),'--smoke-fixture',('"'+$fixture+'"'))
 $receipt.arguments=$args
 $owned=Start-Process -FilePath $exe -ArgumentList $args -WindowStyle Hidden -PassThru
 $receipt.pid=$owned.Id
 $receipt | ConvertTo-Json -Depth 20 | Set-Content -LiteralPath (Join-Path $output 'receipt.json') -Encoding utf8
 Write-Output ('Owned native65 PID '+$owned.Id)
 $watch=[Diagnostics.Stopwatch]::StartNew()
 while(-not $owned.WaitForExit(1000)){if($watch.ElapsedMilliseconds -ge 900000){throw 'Unchanged900000ms watchdog exceeded'}}
 $receipt.exitCode=$owned.ExitCode;$receipt.finishedAt=[DateTime]::UtcNow.ToString('o')
 if(-not(Test-Path -LiteralPath $report)){throw 'Original report missing'}
 $receipt.reportSha256=(Get-FileHash -LiteralPath $report -Algorithm SHA256).Hash.ToLowerInvariant()
 $receipt | ConvertTo-Json -Depth 20 | Set-Content -LiteralPath (Join-Path $output 'receipt.json') -Encoding utf8
 $result=Get-Content -LiteralPath $report -Raw | ConvertFrom-Json
 if($owned.ExitCode -ne 0 -or $result.ok -ne $true){throw 'Native65 failed; original report retained'}
 Write-Output 'Native65 completed with original report'
} catch {$receipt.error=$_.Exception.Message;$receipt | ConvertTo-Json -Depth 20 | Set-Content -LiteralPath (Join-Path $output 'receipt.json') -Encoding utf8;throw}
finally {if($null -ne $owned){if(-not $owned.HasExited){$owned.Kill()};$owned.Dispose()};[Environment]::SetEnvironmentVariable('WEBVIEW2_USER_DATA_FOLDER',$previousProfile,'Process')}

