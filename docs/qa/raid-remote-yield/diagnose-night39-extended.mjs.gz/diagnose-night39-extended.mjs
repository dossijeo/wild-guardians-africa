import {readFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {deserialize} from '../src/persistence/snapshots.js';
import {Navigation,BIOME_IDS} from '../src/world/navigation.js';
import {prepareActorMotion,actorBlockers} from '../src/simulation/actor-motion.js';
import {movePath} from '../src/simulation/locomotion.js';
const s=deserialize(gunzipSync(readFileSync('docs/qa/paid-defense-failure-ee25c8c/failure-state.json.gz')).toString());
const profile=JSON.parse(readFileSync(`public/content/biome-${BIOME_IDS[s.biome]}.json`)).profile;
const nav=new Navigation(s.seed,s.biome,profile);nav.setState(s);
for(const a of s.raid.animals.filter(a=>a.id==='animal-95773')){
 console.log('START',JSON.stringify({id:a.id,x:a.x,z:a.z,path:a.path.slice(0,5),len:a.path.length,approach:a.approach}));
 for(let i=0;i<125;i++){
  const before={x:a.x,z:a.z},path=a.path.slice(0,3);
  const clear=prepareActorMotion(s,a,nav,false);
  const prepared=a.path.slice(0,3),moved=movePath(a,3.8*.1,clear);
  console.log(JSON.stringify({i,before,path,prepared,len:a.path.length,moved,staticClear:nav.segmentClear(before,a,a.radius,null,false),walkable:nav.walkable(a.x,a.z,a.radius,null,false),after:{x:a.x,z:a.z},blockers:actorBlockers(s,a,false).filter(b=>Math.hypot(b.x-a.x,b.z-a.z)<6).map(b=>({id:b.id,x:b.x,z:b.z,r:b.radius,status:b.status,path:b.path?.slice(0,2)}))}));
 }
}

