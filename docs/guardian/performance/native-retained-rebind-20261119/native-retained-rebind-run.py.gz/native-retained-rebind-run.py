from pathlib import Path
import json,hashlib,subprocess,os
n='native-retained-rebind';read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();write=lambda p,v:Path(p).write_bytes((json.dumps(v,indent=2)+'\n').encode())
own=read(f'.cache/{n}-candidate-files.json');write(f'.cache/{n}-owned-files.json',own);old=read(f'.cache/{n}-pre-tested-hashes.json');native=read(f'.cache/{n}-pre-built-hashes.json');foreign=read(f'.cache/{n}-pre-preserved-hashes.json')
focused=list(dict.fromkeys(read('.cache/native-retained-cursor-focused-files.json')+['tests/retained-recovery-transport.test.js','tests/confirmed-presentation-stream.test.js','tests/confirmed-presentation-native-hold.test.js','tests/presentation-input-channel.test.js','tests/far-visual-presentation-stream.test.js','tests/terrain-native-proposal.test.js','tests/simulation-terrain-history-worker.test.js','tests/confirmed-terrain-receiver.test.js','tests/terrain-history-detached.test.js','tests/terrain-history-cancellation.test.js']))
selected=list(dict.fromkeys(read('.cache/native-retained-cursor-regression-files.json')+focused));write(f'.cache/{n}-focused-files.json',focused);write(f'.cache/{n}-regression-files.json',selected)
inputs={p:sha(p) for p in sorted(set(old)|set(own)|set(focused)|set(selected)|{'src/rendering/terrain-proposal-receiver.js','src/simulation/far-visual-port.js'})};write(f'.cache/{n}-tested-hashes.json',inputs)
def verify():assert all(sha(p)==h for m in [inputs,native,foreign] for p,h in m.items())
verify();print('Frozen',len(inputs),'inputs;',len(focused),'directed;',len(selected),'selected files;64native/16foreign exact.',flush=True);syntax=[]
for p in own:
 r=subprocess.run(['.cache/tooling/node20.exe','--check',p],capture_output=True,text=True);syntax.append({'file':p,'sha256':sha(p),'exitCode':r.returncode,'output':r.stdout+r.stderr});assert r.returncode==0
write(f'.cache/{n}-syntax.json',syntax)
env=os.environ.copy();env['WILD_ENGINE_NATIVE_ROUTE_WASM']=str(Path('src/world/wild-engine/spatial-savanna.wasm').resolve());env['WILD_ENGINE_SPATIAL_SERVICES_WASM']=env['WILD_ENGINE_NATIVE_ROUTE_WASM']
with open(f'.cache/{n}-complete-baseline.log','w',encoding='utf-8') as output:r=subprocess.run(['.cache/tooling/node20.exe','--experimental-loader',f'./.cache/{n}-baseline-loader.mjs','--test','tests/retained-recovery-transport.test.js'],env=env,stdout=output,stderr=output)
assert r.returncode!=0;print('Original source complete baseline',r.returncode,flush=True);verify()
controls=[]
for mode in ['before','current']:
 for case,file in [('timeline','tests/confirmed-presentation-timeline.test.js'),('host','tests/worker-runtime-host-timeline.test.js')]:
  command=['.cache/tooling/node20.exe']+(['--experimental-loader',f'./.cache/{n}-baseline-loader.mjs'] if mode=='before' else [])+['--test',file];log=f'.cache/{n}-control-{mode}-{case}.log'
  with open(log,'w',encoding='utf-8') as output:
   process=subprocess.Popen(command,env=env,stdout=output,stderr=output);timeout=False;terminated=None
   try:code=process.wait(timeout=25)
   except subprocess.TimeoutExpired:
    timeout=True;kill=subprocess.run(['taskkill','/PID',str(process.pid),'/T','/F'],capture_output=True,text=True);terminated={'pid':process.pid,'exitCode':kill.returncode,'stdout':kill.stdout,'stderr':kill.stderr};code=process.wait(timeout=10)
  row={'mode':mode,'case':case,'file':file,'command':command,'exitCode':code,'timeout':timeout,'secondsLimit':25,'termination':terminated,'log':log,'sha256':sha(log)};controls.append(row);write(f'.cache/{n}-controls.json',controls);print('control',mode,case,code,'timeout',timeout,flush=True);verify()
for label,command in [('focused',['.cache/tooling/node20.exe','--test',*focused]),('regression',['.cache/tooling/node20.exe','--test',*selected]),('build',['.cache/tooling/node20.exe','node_modules/vite/bin/vite.js','build'])]:
 with open(f'.cache/{n}-{label}.log','w',encoding='utf-8') as output:r=subprocess.run(command,env=env,stdout=output,stderr=output)
 print(label,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
 verify()
print('Exact',len(inputs),'tested/64native unchanged/16foreign;20new transport cases;CPU/build complete;final actual GPU rebind/control cases still required. Ordinary host/WorldWorker/client/UI selection remains pending.',flush=True)
