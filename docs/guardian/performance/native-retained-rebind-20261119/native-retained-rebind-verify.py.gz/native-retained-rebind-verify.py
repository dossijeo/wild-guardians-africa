from pathlib import Path
import json,hashlib,gzip,re,subprocess,sys
n='native-retained-rebind'
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
e=read(f'docs/guardian/performance/{n}-validation-20261119.json')
files=read(f'.cache/{n}-commit-files.json')
owned=read(f'.cache/{n}-owned-files.json')
assert len(files)==len(set(files)) and len(files)>30 and len(owned)==6
for key,count in [('testedInputs',540),('nativeBuiltInputs',64),('preservedFiles',16)]:
 assert len(e[key])==count and all(sha(p)==h for p,h in e[key].items()),key
before=read(f'.cache/{n}-pre-tested-hashes.json')
assert len(before)==536 and e['changedPriorInputs']==sorted(p for p,h in before.items() if e['testedInputs'][p]!=h) and set(e['changedPriorInputs'])<=set(owned) and e['addedInputs']==sorted(set(e['testedInputs'])-set(before))
assert e['productionChangedFiles']==owned[:3] and e['nativeChangedFiles']==[]
assert Path('public/wild-engine/spatial-threaded.worker.mjs').read_bytes()==Path('.cache/native-idle-stroll-preserved-worker.mjs').read_bytes()
def refs(v):
 if isinstance(v,dict):
  if 'source' in v and 'sha256' in v:assert sha(v['source'])==v['sha256'],v['source']
  if 'original' in v and 'raw' in v:assert gzip.decompress(Path(v['raw']['source']).read_bytes())==Path(v['original']['source']).read_bytes(),v['original']['source']
  if 'original' in v and 'copy' in v:assert Path(v['copy']['source']).read_bytes()==Path(v['original']['source']).read_bytes()
  for x in v.values():refs(x)
 elif isinstance(v,list):
  for x in v:refs(x)
refs(e)
normal=e['validationSourceNormalization']
assert normal['equivalent'] and normal['syntaxExitCode']==0 and normal['before']['sha256']==read(f'.cache/{n}-final-tested-hashes.json')[normal['file']]
assert Path(normal['before']['source']).read_bytes().replace(b'\r\n',b'\n').replace(b'\r',b'\n')==Path(normal['file']).read_bytes() and normal['afterSha256']==sha(normal['file'])
for label,t in e['tests'].items():
 s=Path(t['original']['source']).read_text(encoding='utf-8-sig')
 assert all(int(re.search(r'^# '+k+r' (\d+)\s*$',s,re.M).group(1))==t[k] for k in ['tests','pass','fail','cancelled','skipped']),label
t=e['tests']
assert (t['baseline']['pass'],t['baseline']['fail'])==(0,16)
assert (t['final-complete-baseline']['tests'],t['final-complete-baseline']['pass'],t['final-complete-baseline']['fail'])==(21,1,20) and e['newTests']==21
assert (t['final-handshake-baseline']['fail'],t['final-handshake-baseline']['skipped'])==(1,20)
assert t['final-focused']['pass']==450 and t['final-regression']['pass']==4060 and t['final-regression']['tests']==4061 and t['final-regression']['skipped']==1 and all(t[k]['fail']==t[k]['cancelled']==0 for k in ['final-focused','final-regression'])
assert len(e['focusedFiles'])==30 and len(e['regressionFiles'])==318
assert t['normalized-focused']['pass']==450 and t['normalized-focused']['fail']==t['normalized-focused']['cancelled']==0
assert len(e['syntax'])==6 and all(x['exitCode']==0 and x['sha256']==sha(x['file']) for x in e['syntax']) and e['build']['seconds']==47.08
assert sha(f'.cache/{n}-stream-before-handshake.js')==read(f'.cache/{n}-tested-hashes.json')['src/rendering/confirmed-presentation-stream.js']
controls=e['separatePreexistingFailures'];assert len(controls)==4
assert {(x['mode'],x['case']) for x in controls}=={(a,b) for a in ['before','current'] for b in ['timeline','host']}
for row in controls:
 assert row['exitCode']!=0 and sha(row['log'])==row['sha256']
 s=Path(row['log']).read_text(encoding='utf-8-sig',errors='replace')
 if row['case']=='timeline':
  assert not row['timeout'] and 'Visual handshake timed out' in s and re.search(r'^# tests 20\s*$',s,re.M) and re.search(r'^# pass 19\s*$',s,re.M)
 else:assert row['timeout'] and row['secondsLimit']==25 and row['termination']['exitCode']==0
for name in ['integrated-gpu-migration-plan-20261104.md','MIGRATION-OBJECTIVE.md','A6-CHECKLIST.md','CURRENT-STATUS.md']:
 old=Path(f'.cache/{n}-{name}.before').read_bytes();new=(Path('docs/guardian')/name).read_bytes();pos=old.index(b'\n')+1
 assert new[:pos]==old[:pos] and len(new)>len(old) and new[pos+len(new)-len(old):]==old[pos:]
for row in e['productionBefore']:
 body=Path(row['snapshot']['original']['source']).read_bytes();committed=subprocess.check_output(['git','show',e['baseCommit']+':'+row['file']])
 assert body.replace(b'\r\n',b'\n')==committed.replace(b'\r\n',b'\n')
g=e['gpu'];assert g['newFinalRuns']==4 and len(g['cases'])==4
assert [x['label'] for x in g['cases']]==['rebind','readmission','negative','fresh']
for row in g['cases']:
 assert row['exitCode']==0 and row['metrics']['drain']
 m=row['metrics']
 if row['label']=='fresh':assert m['resourcesCreated']==1893 and m['draw']=={'frames':6,'packets':3,'gpuErrors':0}
 else:
  assert (m['retainedChunks'],m['retainedNodes'],m['retainedImmutableNativeGenerations'])==(9,175,180)
  assert m['visual']['ok'] and m['visual']['blankControlRejected'] and m['visual']['differingPixels']==58104 and m['visual']['workerRegionPixels']==2316 and m['visual']['screenshotSha256']==g['identicalRetainedPng']
  if row['label']=='negative':assert m['created']==0 and m['preparedWorld'] is None
  else:
   assert m['created']==80 and all(v==0 for v in m['noop'].values()) and m['preparedWorld']==m['requiredWorld'] and m['requiredWorld']['ticket']==2
   if row['label']=='rebind':
    b=m['transportRebind'];assert m['sequence']==4 and b['sequence']==2 and b['streamRetained'] and b['terrainRetained'] and b['stateRetained']
    assert all(b[k]==0 for k in ['created','factories','nativeForks','liveCreated','liveFactories','liveNativeForks']) and b['liveSequences']==b['ackedSequences']==[3,4] and b['liveKinds']==['full','delta']
   else:assert m['readmission']['previousVersion']==0 and m['readmission']['version']==1 and m['readmission']['compilesAfter']>m['readmission']['compilesBefore'] and m['readmission']['created']==0
assert subprocess.check_output(['git','branch','--show-current']).decode().strip()=='codex/guardian-3d-animation' and not subprocess.check_output(['git','diff','--cached','--name-only']).strip()
head=subprocess.check_output(['git','rev-parse','HEAD']).decode().strip()
assert head==e['baseCommit'] or subprocess.check_output(['git','rev-parse','HEAD^']).decode().strip()==e['baseCommit']
if '--published' in sys.argv:
 assert not subprocess.check_output(['git','status','--porcelain','--',*files]).strip()
 assert subprocess.check_output(['git','rev-list','--left-right','--count','HEAD...origin/codex/guardian-3d-animation']).decode().strip()=='0\t0'
 assert subprocess.check_output(['git','ls-remote','origin','refs/heads/codex/guardian-3d-animation']).decode().split()[0]==head
subprocess.run(['git','diff','--check','--',*files],check=True)
print('Verified',len(files),'paths;540/64native/16foreign;21new/450directed/4060of4061selected1skip;build47.08;fourGPUcases;retained rebind and full3/delta4 zero allocations/forks;ordinary host/UI and cadence pending.',flush=True)
