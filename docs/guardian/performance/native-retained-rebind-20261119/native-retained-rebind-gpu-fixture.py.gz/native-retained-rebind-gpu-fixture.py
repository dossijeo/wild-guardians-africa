from pathlib import Path
p=Path('tests/browser/webgpu-temporal-ground-worker.js');s=p.read_bytes().decode()
def change(a,b):
 global s
 assert s.count(a)==1,(a[:95],s.count(a));s=s.replace(a,b)
change('steadyFrames=[],unchangedCheckpoint=null,readmission=null;', 'steadyFrames=[],unchangedCheckpoint=null,readmission=null,transportRebind=null,reboundPorts=null;')
a='noopBefore=await remote.inspectAsync();await surface.restoreTimelineCheckpoint(same,{retainCurrent:true});'
b="""noopBefore=await remote.inspectAsync();
    if(data.nativeRetainedRebind){
     const terrainChannel=new MessageChannel(),presentationChannel=new MessageChannel(),messages=[],stream=surface.stream,terrain=surface.terrain,confirmed=surface.state,before=await remote.inspectAsync(),createdBefore=createdResources.length,factoriesBefore=remote.inspect().resourcesCreated;
     ports.push(terrainChannel.port2,presentationChannel.port2);terrainChannel.port2.onmessage=({data})=>messages.push(data);presentationChannel.port2.onmessage=({data})=>{messages.push(data);if(data.kind==='presentationTimelineHello')presentationChannel.port2.postMessage({kind:'presentationTimelineReady',session:'ground-native',version:1});};
     const checkpoint=surface.rebindTimelineRecovery({terrainPort:terrainChannel.port1,presentationPort:presentationChannel.port1});
     if(surface.stream!==stream||surface.terrain!==terrain||surface.state!==confirmed||checkpoint.sequence!==2||surface.nativeFrameReadiness!=='waiting'||surface.render()!==false)throw Error('Surface transport rebind replaced a committed owner or allowed drawing');
     terrainChannel.port2.postMessage({kind:'terrainHello',session:'ground-native',epoch:'e',version:1});
     const after=await remote.inspectAsync();transportRebind={sequence:checkpoint.sequence,created:createdResources.length-createdBefore,factories:remote.inspect().resourcesCreated-factoriesBefore,before,after,streamRetained:true,terrainRetained:true,stateRetained:true};reboundPorts={terrain:terrainChannel.port2,presentation:presentationChannel.port2,messages};
     if(transportRebind.created||transportRebind.factories||['uniformForks','bindingForks','bufferForks','textureForks'].some(key=>(after.consumer[key]??0)!==(before.consumer[key]??0)))throw Error('Transport-only rebind allocated native resources');check();verifyNative(after);
    }
    await surface.restoreTimelineCheckpoint(same,{retainCurrent:true});"""
change(a,b)
anchor='    if(data.nativeRetainedReadmission)'
extra="""    if(reboundPorts){
     const deadline=performance.now()+10000;while((!surface.stream.timelineStatus().negotiated||!reboundPorts.messages.some(m=>m.kind==='terrainHelloAck'))&&performance.now()<deadline&&!errors.length)await new Promise(resolve=>setTimeout(resolve,4));
     if(!surface.stream.timelineStatus().negotiated||!reboundPorts.messages.some(m=>m.kind==='terrainHelloAck'))throw Error('Rebound transport did not negotiate after replay');
     const {createMainSnapshotEncoder}=await import('../../src/simulation/main-thread-snapshot-transport.js'),encoder=createMainSnapshotEncoder(),live=[],createdBefore=createdResources.length,factoriesBefore=remote.inspect().resourcesCreated,before=await remote.inspectAsync();let id=0;
     try{for(const sequence of [3,4]){
      reboundPorts.terrain.postMessage({kind:'terrainBatchBegin',session:'ground-native',epoch:'e',sequence,id:++id,count:0,bytes:0});reboundPorts.terrain.postMessage({kind:'terrainBatchEnd',session:'ground-native',epoch:'e',sequence,id:++id});
      const wire=encoder.encode({kind:'publication',session:'ground-native',publication:{session:'ground-native',sequence,elapsed:10,physicsPose:null,snapshot:serializeConfirmedState(state),events:[],terrainChanged:false}}),kind=typeof wire.publication.snapshot==='string'?'full':wire.publication.snapshotDelta?'delta':'unknown';
      if(kind!==(sequence===3?'full':'delta'))throw Error('Unexpected rebound snapshot kind '+kind);reboundPorts.presentation.postMessage(wire);const deadline=performance.now()+10000;
      while(surface.stream.status().sequence!==sequence&&performance.now()<deadline&&!errors.length){surface.timelinePump.advance();await new Promise(resolve=>setTimeout(resolve,4));}
      if(surface.stream.status().sequence!==sequence||!await render()||renderTiming.created.length||renderTiming.factoriesAfter!==renderTiming.factoriesBefore)throw Error('Rebound live publication failed or allocated during draw');live.push({sequence,kind,frame:renderTiming});
     }}finally{encoder.dispose();}
     await remote.device.queue.onSubmittedWorkDone();const after=await remote.inspectAsync();check();verifyNative(after);transportRebind.live={publications:live,created:createdResources.length-createdBefore,factories:remote.inspect().resourcesCreated-factoriesBefore,before,after,acks:reboundPorts.messages.filter(m=>m.kind==='publicationAck'||m.kind==='terrainAck'||m.kind==='terrainCredit')};
     if(transportRebind.live.created||transportRebind.live.factories||errors.length||['uniformForks','bindingForks','bufferForks','textureForks'].some(key=>(after.consumer[key]??0)!==(before.consumer[key]??0)))throw Error('Unchanged live rebound publications allocated native resources');
    }
"""
change(anchor,extra+anchor)
change('unchangedCheckpoint,readmission,steadyFrames,retainedNodes:', 'unchangedCheckpoint,readmission,transportRebind,steadyFrames,retainedNodes:')
change("mode:data.nativeRetainedRecoveryNegative?'retained-recovery-presentation-rejection':'retained-surface-native-recovery'", "mode:data.nativeRetainedRecoveryNegative?'retained-recovery-presentation-rejection':data.nativeRetainedRebind?'retained-surface-transport-rebind':'retained-surface-native-recovery'")
p.write_bytes(s.encode())
p=Path('tools/experiments/audit_webgpu_temporal_ground.mjs');s=p.read_bytes().decode()
change("!['false','true','negative','readmission'].includes(retainedMode)", "!['false','true','negative','readmission','rebind'].includes(retainedMode)")
change("if(['true','negative','readmission'].includes(retainedMode))", "if(['true','negative','readmission','rebind'].includes(retainedMode))")
change("readmission:retainedMode==='readmission'}", "readmission:retainedMode==='readmission',rebind:retainedMode==='rebind'}")
change('auditRetainedSurfaceRecovery({negative=false,readmission=false}={})', 'auditRetainedSurfaceRecovery({negative=false,readmission=false,rebind=false}={})')
change("['host','**/src/rendering/remote-webgpu-host.js*']]", "['host','**/src/rendering/remote-webgpu-host.js*'],['stream','**/src/rendering/confirmed-presentation-stream.js*'],['terrain','**/src/rendering/terrain-history-receiver.js*']]")
assert s.count('({negative,readmission})')==1;s=s.replace('({negative,readmission})','({negative,readmission,rebind})')
change('nativeRetainedReadmission:readmission,nativeDelta:false', 'nativeRetainedReadmission:readmission,nativeRetainedRebind:rebind,nativeDelta:false')
change('}),{negative,readmission});','}),{negative,readmission,rebind});')
p.write_bytes(s.encode());print('Actual Surface API GPU mode rebind:retains both facades/owners,negotiates new ports,then consumes full3/delta4 with real draw/control. Inventory-only QA capture now includes served stream/terrain source.')
