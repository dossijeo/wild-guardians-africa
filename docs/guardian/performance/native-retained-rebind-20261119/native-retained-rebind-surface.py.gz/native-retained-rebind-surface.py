from pathlib import Path
p=Path('src/rendering/webgpu-world-surface.js');s=p.read_bytes().decode()
def change(a,b):
 global s
 assert s.count(a)==1,(a[:100],s.count(a));s=s.replace(a,b)
change('timelineRecovering=experimentalTimelineRecovery,','timelineRecovering=experimentalTimelineRecovery,recoveryTransportPending=false,')
anchor='  function captureTemporalPresentationCheckpoint(sequence)'
addition="""  function rebindTimelineRecovery({terrainPort:nextTerrainPort,presentationPort:nextPresentationPort}={}){
   const recovery=temporalRecoverySurface?.status(),sequence=stream?.status().sequence,elapsed=state?.elapsed,pump=timelinePump?.status();
   if(closed||!retainedTimelineRecovery||timelineRecovering||recovery?.busy||!['checkpoint','live'].includes(recovery?.phase)||nativeGateProposal||nativeRoutePreparations||pump?.closed||pump?.historicalPending!==null&&pump?.historicalPending!==undefined||historicalClock?.status().active||nextTerrainPort===nextPresentationPort)throw Error('Retained Surface transport unavailable');
   const boundary={sequence,elapsed};stream.assertRecoveryTransport({port:nextPresentationPort,...boundary});terrain.assertRecoveryTransport({port:nextTerrainPort,...boundary});
   const work=presentationWorkRecovery||experimentalWorkRecovery?agricultureVfx.exportWorkCheckpoint(sequence,{allowHidden:true}):null,presentation=captureTemporalPresentationCheckpoint(sequence);
   timelineRecovering=true;recoveryTransportPending=true;grassTimeline?.beginRecovery();
   try{terrain.rebindForRecovery({port:nextTerrainPort,...boundary});stream.rebindForRecovery({port:nextPresentationPort,...boundary});}catch(error){try{onError(error);}catch{}throw error;}
   return {sequence,presentationCheckpoint:presentation,...(work===null?{}:{workCheckpoint:work})};
  }
"""
change(anchor,addition+anchor)
change('...(temporalRecoverySurface?{async restoreTimelineCheckpoint', '...(temporalRecoverySurface?{...(retainedTimelineRecovery?{rebindTimelineRecovery}:{}),async restoreTimelineCheckpoint')
change("if(retainCurrent&&!retainedTimelineRecovery)throw Error('Retained temporal recovery unavailable');", "if(retainCurrent&&!retainedTimelineRecovery||recoveryTransportPending&&!retainCurrent)throw Error('Retained temporal recovery unavailable');")
change("timelineRecovering&&status.phase==='live')throw Error('Temporal checkpoint unavailable');timelineRecovering=true;", "timelineRecovering&&status.phase==='live'&&!recoveryTransportPending)throw Error('Temporal checkpoint unavailable');recoveryTransportPending=false;timelineRecovering=true;")
p.write_bytes(s.encode());print('Surface exports its actual retained effects/cursor and rebinds both existing receiver facades after both preflights. GPU owners remain untouched;draw/pick held until actual checkpoint/replay/native-world finish.')
