from pathlib import Path
import json,hashlib,gzip,re
n='native-retained-rebind';root=Path(f'docs/guardian/performance/{n}-20261119');receipt=Path(f'docs/guardian/performance/{n}-validation-20261119.json')
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
e=read(receipt);files=read(f'.cache/{n}-commit-files.json');x=read(f'.cache/{n}-eol-normalization.json')
assert 'validationSourceNormalization' not in e and x['before']['sha256']==e['testedInputs'][x['file']] and x['afterSha256']==sha(x['file']) and Path(x['before']['source']).read_bytes().replace(b'\r\n',b'\n').replace(b'\r',b'\n')==Path(x['file']).read_bytes()
def archive(p):
 p=Path(p);target=root/(p.name+'.gz');body=gzip.compress(p.read_bytes(),mtime=0)
 if target.exists():assert target.read_bytes()==body
 else:target.write_bytes(body);files.append(target.as_posix())
 return {'original':{'source':p.as_posix(),'sha256':sha(p)},'raw':{'source':target.as_posix(),'sha256':sha(target)}}
x['beforeEvidence']=archive(x['before']['source']);x['normalizationEvidence']=archive(f'.cache/{n}-eol-normalization.json');e['validationSourceNormalization']=x;e['testedInputs'][x['file']]=x['afterSha256']
for row in e['syntax']:
 if row['file']==x['file']:row['sha256']=x['afterSha256'];row['beforeLineNormalizationSha256']=x['before']['sha256']
log=Path(f'.cache/{n}-normalized-focused.log');s=log.read_text();t=archive(log)
for k in ['tests','pass','fail','cancelled','skipped']:t[k]=int(re.search(r'^# '+k+r' (\d+)\s*$',s,re.M).group(1))
assert t['pass']==450 and t['fail']==t['cancelled']==0;e['tests']['normalized-focused']=t
e['notes']=[v.replace('No source changes after final CPU freeze.','After final GPU runs, only terrain receiver line terminators were normalized (CRLF and one CR to LF). Exact original tested/served bytes are retained and universal-newline equivalence is verified;syntax and450directed rerun pass. No semantic source change.') for v in e['notes']]
for p in [f'.cache/{n}-verify.py',f'.cache/{n}-document-normalization.py']:e['diagnostics'][Path(p).name]=archive(p)
receipt.write_text(json.dumps(e,indent=2)+'\n',encoding='utf-8');Path(f'.cache/{n}-commit-files.json').write_text(json.dumps(files,indent=2)+'\n',encoding='utf-8')
doc=Path(f'docs/guardian/{n}-20261119.md');body=doc.read_text();marker='## GPU NVIDIA: propietarios retenidos y canales nuevos'
assert body.count(marker)==1
body=body.replace(marker,'Antes del commit se normalizan únicamente los terminadores de línea del receptor de terreno (CRLF y un CR a LF). Se conservan los bytes originales de CPU/GPU y se comprueba equivalencia exacta tras normalizar saltos; se repiten sintaxis y las **450 dirigidas**, todas pasan. El recibo distingue el SHA probado anterior y el publicado; no se atribuye otra ejecución GPU a este cambio de formato.\n\n'+marker)
doc.write_bytes(body.encode());print('Recorded newline-only normalization and450directed rerun;',len(files),'owned paths.')
