from pathlib import Path
p=Path('src/rendering/terrain-history-receiver.js');s=p.read_bytes().decode()
def change(a,b):
 global s
 assert s.count(a)==1,(a[:100],s.count(a));s=s.replace(a,b)
change('let batchFrameId=null,closed=false,','let transportVersion=0,disposed=false,rebindPending=false,batchFrameId=null,closed=false,')
start=s.index(' const proposals=createTerrainProposalReceiver(');end=s.index('\n',start);old=s[start:end]
new=old.replace(' const proposals=', ' function createProposals(){const version=transportVersion;return ')
new=new.replace('onChange:onReady,onError:fail','onChange:()=>{if(version===transportVersion)onReady();},onError:error=>{if(version===transportVersion)fail(error);}')+'}\n let proposals=createProposals();'
s=s[:start]+new+s[end:]
change('const batch=batches[0];if(batch.graphicalStarted)', 'const version=transportVersion,batch=batches[0];if(batch.graphicalStarted)')
change('if(closed||controller.signal.aborted||batches[0]!==batch)return;', 'if(version!==transportVersion||closed||controller.signal.aborted||batches[0]!==batch)return;')
change('if(closed||controller.signal.aborted||batches[0]!==batch){handle?.abort();return;}', 'if(version!==transportVersion||closed||controller.signal.aborted||batches[0]!==batch){handle?.abort();return;}')
change('}).catch(fail);}', '}).catch(error=>{if(version===transportVersion)fail(error);});}')
start=s.index(' port.onmessage=({data})=>{');end=s.index(' // This coordinates',start);block=s[start:end]
block=block.replace(' port.onmessage=({data})=>{',' function bindTransport(){const current=port,version=transportVersion;current.onmessage=({data})=>{if(version!==transportVersion||port!==current)return;',1)
a=" port.onmessageerror=()=>fail(Error('Terrain publication transfer failed'));port.start?.();"
b=" current.onmessageerror=()=>{if(version===transportVersion&&port===current)fail(Error('Terrain publication transfer failed'));};current.start?.();"
assert block.count(a)==1;block=block.replace(a,b);block+=' }\n bindTransport();\n';s=s[:start]+block+s[end:]
change("if(batch.creditId!==undefined)queueMicrotask(()=>{if(!closed)port.postMessage({kind:'terrainCredit',session,id:batch.creditId});});", "if(batch.creditId!==undefined){const version=transportVersion;queueMicrotask(()=>{if(version===transportVersion&&!closed)port.postMessage({kind:'terrainCredit',session,id:batch.creditId});});}")
anchor=' function beginReplay({sequence,epoch:sourceEpoch}={})'
addition=""" function assertRecoveryTransport({port:next,sequence,elapsed}={}){
  if(!allowRetainedReplay||disposed||!next||typeof next.postMessage!=='function'||next===port||replaying||rebindPending||!Number.isSafeInteger(sequence)||sequence<1||sequence!==confirmedSequence||elapsed!==confirmedElapsed||typeof epoch!=='string'||!epoch||proposals.status()||typeof residency.visualReady!=='function'||residency.visualReady()!==true)throw Error('Retained terrain recovery transport unavailable');
  return true;
 }
 function rebindForRecovery(options){
  assertRecoveryTransport(options);transportVersion++;closed=true;const previous=port;previous.onmessage=null;previous.onmessageerror=null;previous.close?.();proposals.dispose();rejectReplay(Error('Terrain transport rebound'));
  for(const batch of batches){batch.graphicalController?.abort();batch.graphical?.abort();}queue.length=0;batches.length=0;active=null;waiting=null;reservedBytes=0;reservedCount=0;batchFrameId=null;pendingHello=null;admitted=null;
  port=options.port;closed=false;lastId=0;complete=lastSequence=confirmedSequence;checkpointSequence=-1;negotiated=false;replaying=true;replayEpoch=null;rebindPending=true;generation++;proposals=createProposals();bindTransport();return {sequence:confirmedSequence,elapsed:confirmedElapsed};
 }
"""
change(anchor,addition+anchor)
change('const retained=allowRetainedReplay&&!replaying;if(closed||', 'const retained=allowRetainedReplay&&!replaying;if(rebindPending&&sourceEpoch!==epoch||closed||')
change("throw Error('Invalid retained or fresh terrain replay checkpoint');replaying=true;", "throw Error('Invalid retained or fresh terrain replay checkpoint');rebindPending=false;replaying=true;")
change('return {ready,confirm,admittedBoundary(sequence)', 'return {ready,confirm,...(allowRetainedReplay?{assertRecoveryTransport,rebindForRecovery}:{}),admittedBoundary(sequence)')
change('dispose(){if(closed)return;closed=true;', 'dispose(){if(disposed)return;disposed=true;transportVersion++;if(closed)return;closed=true;')
p.write_bytes(s.encode());print('Terrain facade retains committed revision/resource owner, cancels old preparations, isolates completions/credits/proposals by connection generation and defers replacement hello until replay finishes.')
