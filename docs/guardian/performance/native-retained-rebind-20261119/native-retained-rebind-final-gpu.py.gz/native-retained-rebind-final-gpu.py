from pathlib import Path
import json,hashlib,subprocess,os,re
n='native-retained-rebind';read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();write=lambda p,v:Path(p).write_bytes((json.dumps(v,indent=2)+'\n').encode())
inputs=read(f'.cache/{n}-final-tested-hashes.json');native=read(f'.cache/{n}-pre-built-hashes.json');foreign=read(f'.cache/{n}-pre-preserved-hashes.json')
def verify():assert all(sha(p)==h for m in [inputs,native,foreign] for p,h in m.items())
run=Path(f'.cache/{n}-final-run.log').read_text();assert 'final-build 0' in run and 'Exact 540' in run;verify()
log=f'.cache/{n}-final-handshake-baseline.log'
with open(log,'w',encoding='utf-8') as output:r=subprocess.run(['.cache/tooling/node20.exe','--experimental-loader',f'./.cache/{n}-handshake-baseline-loader.mjs','--test','--test-name-pattern=fresh-created stream','tests/retained-recovery-transport.test.js'],stdout=output,stderr=output)
text=Path(log).read_text();assert r.returncode!=0 and '# fail 1\n' in text and '# skipped 20\n' in text and 'Transport fixture timed out' in text;verify();print('Exact pre-fix handshake module reproduces1failure/20skipped on final fresh->retained test. CPU/build already complete.',flush=True)
source=Path('tools/experiments/audit_webgpu_temporal_ground.mjs').read_text();anchor="await page.goto((process.env.QA_BASE_URL??'http://127.0.0.1:5200')+'/ground-qa');";assert source.count(anchor)==2
hook="""await page.route('**/tests/browser/webgpu-temporal-ground-worker.js*',async route=>{const response=await route.fetch();let source=await response.text();const anchor='adapter:inspection.consumer.adapterInfo,checkpointWorld:';if(source.split(anchor).length!==2)throw Error('Readonly fresh resource counter anchor missing');source=source.replace(anchor,'adapter:inspection.consumer.adapterInfo,resourcesCreated:remote.inspect().resourcesCreated,checkpointWorld:');await writeFile(process.env.QA_ARTIFACT_PREFIX+'-worker-served.js',source,{flag:'wx'});await route.fulfill({response,body:source});});"""
adapter=f'.cache/{n}-final-fresh-audit.mjs';assert not Path(adapter).exists();Path(adapter).write_bytes(source.replace(anchor,hook+anchor,1).encode())
rows=[]
for mode,label in [('rebind','rebind'),('readmission','readmission'),('negative','negative'),('false','fresh')]:
 prefix=f'.cache/{n}-final-{label}';env=os.environ.copy();env.update({'PLAYWRIGHT_MODULE':str(Path('.cache/microevent-qa/node_modules/playwright-core').resolve()),'QA_BASE_URL':'http://127.0.0.1:5181','QA_NATIVE_RETAINED_RECOVERY':mode,'QA_ARTIFACT_PREFIX':prefix,'OUTPUT':prefix+'.json','QA_SCREENSHOT':prefix+'.png','QA_NATIVE_REPLAY':'true' if label=='fresh' else 'false','QA_NATIVE_DELTA':'false','QA_NATIVE_COLOR':'false','QA_NATIVE_OBSOLETE':'false'})
 command=['.cache/tooling/node20.exe',adapter if label=='fresh' else 'tools/experiments/audit_webgpu_temporal_ground.mjs']
 with open(prefix+'.log','w',encoding='utf-8') as output:code=subprocess.run(command,env=env,stdout=output,stderr=output).returncode
 row={'mode':mode,'label':label,'exitCode':code,'command':command,'report':prefix+'.json','log':prefix+'.log'};rows.append(row);write(f'.cache/{n}-final-gpu.json',rows);print(json.dumps(row),flush=True);verify()
 if code:raise SystemExit(code)
print('Four actual GPU cases sequential after CPU/build;540inputs/64native/16foreign exact. Ordinary host/WorldWorker/client/UI selection and cadence remain pending.',flush=True)
