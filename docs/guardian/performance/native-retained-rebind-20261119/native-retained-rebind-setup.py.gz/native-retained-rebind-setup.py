from pathlib import Path
import json,hashlib,subprocess
n='native-retained-rebind';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_text());write=lambda p,v:Path(p).write_bytes((json.dumps(v,indent=2)+'\n').encode())
assert subprocess.check_output(['git','rev-parse','HEAD']).decode().strip()=='3b545d908e75eb7446cf453708bb89eec20238b4'
inputs=read('.cache/native-retained-cursor-final-tested-hashes.json');native=read('.cache/native-retained-cursor-pre-built-hashes.json');foreign=read('.cache/native-retained-cursor-pre-preserved-hashes.json');assert len(inputs)==536 and all(sha(p)==h for m in [inputs,native,foreign] for p,h in m.items())
for label,m in [('pre-tested',inputs),('pre-built',native),('pre-preserved',foreign)]:write(f'.cache/{n}-{label}-hashes.json',m)
files=['src/rendering/confirmed-presentation-stream.js','src/rendering/terrain-history-receiver.js','src/rendering/webgpu-world-surface.js','tests/retained-recovery-transport.test.js','tests/browser/webgpu-temporal-ground-worker.js','tools/experiments/audit_webgpu_temporal_ground.mjs'];write(f'.cache/{n}-candidate-files.json',files)
for p in files[:3]+files[4:]+['docs/guardian/integrated-gpu-migration-plan-20261104.md','docs/guardian/MIGRATION-OBJECTIVE.md','docs/guardian/A6-CHECKLIST.md','docs/guardian/CURRENT-STATUS.md']:
 target=Path(f'.cache/{n}-{Path(p).name}.before');assert not target.exists();target.write_bytes(Path(p).read_bytes())
research=read('.cache/native-retained-cursor-research.json');assert sha(research['snapshot']['source'])==research['snapshot']['sha256'];research['symbols']=['replicationResurrectCachedMaster','masterTryPartialResynchronization'];research['decision']='Guarded transport rebind on the existing stream/terrain facade,retaining actual committed state/clock/resource owners and source identity;replace decoder and handlers only after preflight,ignore stale async completions by connection generation. No new dependency/registry/owner or native permit.';write(f'.cache/{n}-research.json',research)
print('536prior/64native/16foreign verified;5candidate backups+4raw primary docs;Redis pinned actual reconnect source inspected.')
