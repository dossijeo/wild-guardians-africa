from pathlib import Path
p=Path('src/rendering/confirmed-presentation-stream.js');s=p.read_bytes().decode()
def change(a,b):
 global s
 assert s.count(a)==1,(a[:100],s.count(a));s=s.replace(a,b)
change('const timing=[],liveDecoder=createMainSnapshotDecoder();','const timing=[];let liveDecoder=createMainSnapshotDecoder(),transportVersion=0,disposed=false,rebindPending=false,needsRecoveryHello=false;')
change('const far=allowFarVisualQueries?','let far=allowFarVisualQueries?')
change('checkpointPending=true;checkpointReadyEarly=false;Promise.resolve()', 'const checkpointVersion=transportVersion;checkpointPending=true;checkpointReadyEarly=false;Promise.resolve()')
change('.then(workCheckpoint=>{checkpointPending=false;', '.then(workCheckpoint=>{if(checkpointVersion!==transportVersion)return;checkpointPending=false;')
change('},error=>{checkpointPending=false;', '},error=>{if(checkpointVersion!==transportVersion)return;checkpointPending=false;')
change('.then(()=>{if(!closed&&timeline&&!timeline.manualBoundaries)drainTimeline();}).catch(fail);', '.then(()=>{if(checkpointVersion===transportVersion&&!closed&&timeline&&!timeline.manualBoundaries)drainTimeline();}).catch(error=>{if(checkpointVersion===transportVersion)fail(error);});')
start=s.index(' port.onmessage=({data})=>{');end=s.index(' function submitInput(',start);block=s[start:end]
block=block.replace(' port.onmessage=({data})=>{',' function bindTransport({hello=true}={}){const current=port,version=transportVersion;current.onmessage=({data})=>{if(version!==transportVersion||port!==current)return;',1)
block=block.replace("if(data?.kind==='presentationTimelineReady'&&timeline?.handshake===true&&!timelineReady){", "if(data?.kind==='presentationTimelineReady'&&timeline?.handshake===true&&!timelineReady){if(needsRecoveryHello){fail(Error('Live negotiation during transport replay'));return;}",1)
a=" port.onmessageerror=()=>fail(Error('Presentation publication transfer failed'));port.start?.();if(timeline?.handshake===true)"
b=" current.onmessageerror=()=>{if(version===transportVersion&&port===current)fail(Error('Presentation publication transfer failed'));};current.start?.();if(hello&&timeline?.handshake===true)"
assert block.count(a)==1;block=block.replace(a,b);block+=' }\n bindTransport();\n';s=s[:start]+block+s[end:]
change('if(closed||replaying||!timelineReady||hold||held||historicalEvents||checkpointPending||checkpointDeferred||queued.length', 'if(closed||replaying||!timelineReady&&!rebindPending||hold||held||historicalEvents||checkpointPending||checkpointDeferred||queued.length')
change("throw Error('Retained timeline replay boundary unavailable');replaying=true;}", "throw Error('Retained timeline replay boundary unavailable');rebindPending=false;replaying=true;}")
change("throw Error('Timeline replay not caught up');replaying=false;}", "throw Error('Timeline replay not caught up');replaying=false;if(needsRecoveryHello){needsRecoveryHello=false;if(timeline.handshake===true){timelineReady=false;try{port.postMessage({kind:'presentationTimelineHello',session,version:1,maxPublications:timeline.maxPublications,maxBytes:timeline.maxBytes});}catch(error){fail(error);throw error;}}else timelineReady=true;}}")
anchor=' // Retention starts only at the exact drained live boundary.'
addition=""" function assertRecoveryTransport({port:next,sequence,elapsed}={}){
  const current=receiver.status();
  if(timeline?.retainedReplay!==true||disposed||!next||typeof next.postMessage!=='function'||next===port||replaying||rebindPending||mutationActive||historicalEvents||hold||held||checkpointPending||pendingInputs.size||current.fault||!Number.isSafeInteger(sequence)||sequence<1||sequence!==current.sequence||elapsed!==current.lastElapsed||elapsed!==state.elapsed||elapsed!==presentationClock.elapsed)throw Error('Retained state recovery transport unavailable');
  return true;
 }
 function rebindForRecovery(options){
  assertRecoveryTransport(options);transportVersion++;const previous=port;
  previous.onmessage=null;previous.onmessageerror=null;previous.close?.();far?.dispose();discardStaged();rejectSuppression(Error('Presentation transport rebound'));liveDecoder.dispose();
  port=options.port;liveDecoder=createMainSnapshotDecoder();closed=false;decoded=null;pendingPoses=null;pendingHeadings=null;queued.length=0;queuedBytes=0;waiting=null;checkpointDeferred=false;checkpointReadyEarly=false;
  receivedSequence=timelineSequence=projectedSequence=options.sequence;receivedElapsed=timelineElapsed=timelineTarget=options.elapsed;projectedSuppressed=[...(state.suppressed??[])];timelineReady=false;rebindPending=true;needsRecoveryHello=true;
  far=allowFarVisualQueries?createFarVisualPortClient({session,port,sequence:()=>receiver.status().sequence,revision:()=>farVisualRevision}):null;
  bindTransport({hello:false});return {sequence:options.sequence,elapsed:options.elapsed};
 }
"""
change(anchor,addition+anchor)
change('timeline?.retainedReplay===true?{beginTimelineReplay}:{}','timeline?.retainedReplay===true?{beginTimelineReplay,assertRecoveryTransport,rebindForRecovery}:{}')
change('dispose(){if(closed)return;closed=true;far?.dispose();','dispose(){if(disposed)return;disposed=true;transportVersion++;if(closed)return;closed=true;far?.dispose();')
p.write_bytes(s.encode());print('State facade retains receiver/state/clock, replaces only decoder/transport, gates handshake until replay finishes and isolates stale callbacks by connection generation.')
