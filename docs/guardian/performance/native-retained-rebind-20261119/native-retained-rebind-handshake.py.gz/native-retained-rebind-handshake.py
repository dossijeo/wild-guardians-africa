from pathlib import Path
import json,re
p=Path('src/rendering/confirmed-presentation-stream.js');s=p.read_bytes().decode()
for a,b in [('rebindPending=false,needsRecoveryHello=false;','rebindPending=false,needsRecoveryHello=false,timelineHandshake=timeline?.handshake===true;'),('timelineReady=timeline?.handshake!==true,','timelineReady=!timelineHandshake,'),("data?.kind==='presentationTimelineReady'&&timeline?.handshake===true", "data?.kind==='presentationTimelineReady'&&timelineHandshake"),('if(hello&&timeline?.handshake===true)', 'if(hello&&timelineHandshake)'),('if(timeline.handshake===true){timelineReady=false;', 'if(timelineHandshake){timelineReady=false;'),('rebindPending=true;needsRecoveryHello=true;', 'rebindPending=true;needsRecoveryHello=true;timelineHandshake=true;')]:
 assert s.count(a)==1,(a,s.count(a));s=s.replace(a,b)
p.write_bytes(s.encode())
partial=Path('.cache/native-retained-rebind-regression.log');body=partial.read_text(encoding='utf-8-sig') if partial.exists() else '';passes=re.findall(r'^ok (\d+) -',body,re.M)
Path('.cache/native-retained-rebind-stopped-run.json').write_bytes((json.dumps({'controllerPid':22892,'testParentPid':22600,'reason':'Found missing replacement negotiation for fresh-created stream whose initial handshake flag was false. New failing focused control reproduces timeout. Terminated only owned controller/test tree before changing frozen sources.','partialPassThrough':max(map(int,passes)) if passes else None,'partialLog':partial.as_posix(),'originalInputs':'.cache/native-retained-rebind-tested-hashes.json'},indent=2)+'\n').encode())
print('Each replacement transport now negotiates independently of initial fresh/replay flags;original transport defaults unchanged. Partial first run retained,not claimed as final validation.')
