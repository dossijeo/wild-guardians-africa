import {readFile} from 'node:fs/promises';
export async function load(url,context,nextLoad){if(url.startsWith('file:')&&url.endsWith('/confirmed-presentation-stream.js'))return {format:'module',shortCircuit:true,source:await readFile(new URL('./native-retained-rebind-stream-before-handshake.js',import.meta.url),'utf8')};return nextLoad(url,context);}
