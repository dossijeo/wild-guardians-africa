from pathlib import Path
import json,hashlib,gzip,re,subprocess
n='native-retained-host';date='20261119';read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();write=lambda p,v:Path(p).write_bytes((json.dumps(v,indent=2)+'\n').encode())
base='a6643b56c33a0b290ddcc4c3a19991022ed287b1';assert subprocess.check_output(['git','rev-parse','HEAD']).decode().strip()==base
own=read(f'.cache/{n}-owned-files.json');inputs=read(f'.cache/{n}-tested-hashes.json');native=read(f'.cache/{n}-pre-built-hashes.json');foreign=read(f'.cache/{n}-pre-preserved-hashes.json');before=read(f'.cache/{n}-pre-tested-hashes.json')
assert len(inputs)==556 and len(native)==64 and len(foreign)==16 and all(sha(p)==h for m in [inputs,native,foreign] for p,h in m.items())
adopted=read(f'.cache/{n}-adopted-validation.json');assert adopted['testExitCode']==adopted['buildExitCode']==0 and adopted['exact556Native64Foreign16'] and not adopted['treeTermination']
folder=Path(f'docs/guardian/performance/{n}-{date}');assert not folder.exists();folder.mkdir();artifacts=[]
def ref(p):return {'source':Path(p).as_posix(),'sha256':sha(p)}
def archive(p):
 p=Path(p);target=folder/(p.name+'.gz');body=gzip.compress(p.read_bytes(),mtime=0)
 if target.exists():assert target.read_bytes()==body
 else:target.write_bytes(body);artifacts.append(target.as_posix())
 return {'original':ref(p),'raw':ref(target)}
def summary(p):
 t=archive(p);s=Path(p).read_text(encoding='utf-8-sig')
 for k in ['tests','pass','fail','cancelled','skipped']:
  m=re.search(r'^# '+k+r' (\d+)\s*$',s,re.M);assert m,(p,k);t[k]=int(m.group(1))
 return t
labels=['deferred-baseline','second','third','fourth','final-original-new','historical-before','historical-current','final-focused','final-regression'];tests={k:summary(f'.cache/{n}-{k}.log') for k in labels};t=tests
assert (t['deferred-baseline']['fail'],t['deferred-baseline']['skipped'])==(2,23) and (t['final-original-new']['pass'],t['final-original-new']['fail'])==(0,10)
assert t['fourth']['pass']==80 and t['final-focused']['pass']==599 and all(t[k]['fail']==t[k]['cancelled']==0 for k in ['fourth','final-focused','final-regression']) and t['final-regression']['skipped']==1
assert all((t[k]['tests'],t[k]['pass'],t[k]['fail'])==(5,3,2) for k in ['historical-before','historical-current'])
controls=read(f'.cache/{n}-controls.json');assert len(controls)==4
for row in controls:
 row['evidence']=archive(row['log']);assert row['sha256']==sha(row['log']) and row['exitCode']!=0
 if row['case']=='host':
  assert row['timeout'] and row['secondsLimit']==25 and row['termination']['exitCode']==0
  for k in ['stdoutFile','stderrFile']:row['termination'][k+'Evidence']=archive(row['termination'][k])
 else:
  s=Path(row['log']).read_text();assert not row['timeout'] and 'Visual handshake timed out' in s and re.search(r'^# pass 19\s*$',s,re.M) and re.search(r'^# tests 20\s*$',s,re.M)
syntax=read(f'.cache/{n}-syntax.json');assert len(syntax)==5 and all(r['exitCode']==0 and r['sha256']==sha(r['file']) for r in syntax)
build=archive(f'.cache/{n}-final-build.log');seconds=float(re.search(r'built in ([\d.]+)s',Path(build['original']['source']).read_text()).group(1));build['seconds']=seconds
research=read(f'.cache/{n}-research.json');research['archivedSnapshot']=archive(research['snapshot']['source'])
adopted['evidence']=archive(f'.cache/{n}-adopted-validation.json');adopted['processEvidence']=archive(f'.cache/{n}-adopted-process.json')
diagnostics={}
for p in sorted(Path('.cache').glob(n+'-*')):
 if p.is_file() and p.suffix in ['.log','.json','.py','.mjs','.md','.before','.bin']:diagnostics[p.name]=archive(p)
e={'version':1,'date':date,'baseCommit':base,'scope':'Production source host accepts retained Surface cursor/effects, obtains own authority terrain handoff, prepares existing replay before reattachment and starts it afterward. Original journal base retained; no UI/WorldWorker/client rebind or new GPU acceptance in this step.','productionChangedFiles':own[:3],'nativeChangedFiles':[],'testedInputs':inputs,'nativeBuiltInputs':native,'preservedFiles':foreign,'changedPriorInputs':sorted(p for p,h in before.items() if inputs[p]!=h),'addedInputs':sorted(set(inputs)-set(before)),'newTests':12,'tests':tests,'focusedFiles':read(f'.cache/{n}-focused-files.json'),'regressionFiles':read(f'.cache/{n}-regression-files.json'),'separatePreexistingFailures':controls,'probes':read(f'.cache/{n}-probes.json'),'syntax':syntax,'build':build,'research':research,'gpu':{'newRuns':0,'latestMeasuredCommit':base,'scope':'Inherited only: a6643b56c measured Surface rebind2/full3/delta4 at zero allocations/forks; this source-only step does not repeat or extend that GPU acceptance.'},'diagnostics':diagnostics,'productionBefore':[{'file':p,'snapshot':archive(f'.cache/{n}-{Path(p).name}.before')} for p in own[:3]],'notes':['12new tests:2deferred-start protocol tests plus10actual host/runtime tests;original replay0pass2fail/23skip;original host0pass10fail. Final80including new cases pass.','Real production-mode host module,WorkerGameRuntime,journal/snapshot encoder,Wild Engine authority and MessageChannel temporal recovery/confirmed state receiver. Authority-client attachment adapter,terrain transport/FX headers are fixtures;no browser/GPU/ordinary UI or physical permit claim.','Direct/prepared host2->3skip prefix,source frozen while deferred terrain switch;checkpoint ACK required before attached;new source encoderfull4/delta5,actor retained;original base1 kept;no native control reattachment.','Wrong cursor/effects/worktime/caller handoff/stale actual handoff/native control replacement reject before terrain reattachment/replay;failed switch retires prepared replay and allows explicit retry.','Two existing historical-host cases fail identically before/current releaseCommand is not a function,3pass/2fail. Existing timeline19/20timeout and host25s reproduced separately before/current. No universal green-suite claim;exact selections retained.','Initial failed fixture omitted main queue ACK and a valid startup publication. Tests corrected;first owned test tree retired explicitly,raw failed/intermediate logs kept;none counted as final acceptance.','No dependency,second journal/cache/physical owner or permit. A6/A/B/C remain open;D not begun. Next actual Worker/client/UI same-binding handoff,then producer/cohort/stops/handoffs/cadence/platform.']}
e['validationContinuation']=adopted;e['notes'].append('The original controller360s was shorter than prior measured587.97s. Only its deadline controller was retired;the same live Node regression16224 was adopted by an open Windows process handle,terminal exit0 observed,then build0. No restart or partial-log acceptance;exact process command and final receipt retained.')
receipt=f'docs/guardian/performance/{n}-validation-{date}.json';assert not Path(receipt).exists();write(receipt,e)
rp=t['final-regression']['pass'];rt=t['final-regression']['tests']
doc=f'docs/guardian/{n}-{date}.md';assert not Path(doc).exists();body=f'''# Attachment retenido en el host de producción — 2026-11-19

Continúa `a6643b56c`, A4/e-R3/f-R4. El host existente acepta el cursor y los checkpoints de efectos capturados por la Surface retenida y utiliza la proyección de `3b545d908`. Obtiene su propio handoff de terreno de la autoridad, prepara el replay antes de sustituir el transporte y lo inicia después de resolver esa sustitución. **La selección desde WorldWorker/cliente/UI todavía está pendiente.**

## Referencia y decisión

Se vuelve a leer el código real de [Redis 8.2.1, `masterTryPartialResynchronization` y `replicationResurrectCachedMaster`](https://github.com/redis/redis/blob/cd0b12938b6c99978440c6f7e44e34d7ff0aa537/src/replication.c): identidad/rango e historial se verifican antes de activar la conexión y enviar el sufijo; el cliente retenido conserva su estado. Revisión y bytes exactos se archivan en el recibo. Nuestra adaptación separa preparación e inicio del replay existente para que un ACK temprano no pueda abrir el stream vivo durante el relevo de terreno. No se atribuye a Redis nuestra API `deferStart/start`.

No se añade dependencia, diario, cola de publicaciones, caché, propietario físico ni permiso GPU. Se mantienen la congelación de autoridad, watchdog, rechazo/reintento, renovación de checkpoint, visibilidad y activación existentes.

## Cambios

- `worker-hosted-runtime` transmite opcionalmente `retainedCheckpoint` como datos, transfiriendo solo los tres endpoints de transporte. El consumidor no puede suministrar un handoff autoritativo ni sustituir el control nativo en una recuperación retenida.
- `worker-runtime-host` exige perfil temporal/de trabajo, valida la historia y obtiene `inspectTerrainRecoveryHandoff` en su propia frontera congelada. Proyecta el checkpoint y el sufijo antes de `reattachTerrain`; el handoff procede de la autoridad. Solo después de resolver terreno y, para recuperación fresca, control, comienza el replay. La base original del diario se conserva.
- `presentation-recovery-replay` admite preparación diferida. `wake()` no la salta; `start()` revalida la base y no duplica mensajes. La disposición es terminal. Los fallos de attachment retiran el replay preparado para permitir el reintento explícito existente.

## Evidencia

**12 pruebas nuevas pasan.** Dos de inicio diferido fallan con la fuente anterior (23 casos previos omitidos por filtro); las diez nuevas de host fallan con los tres módulos anteriores. La selección intermedia completa pasa 80/80. El host se empaqueta en modo producción `DEV:false`, con WorkerGameRuntime, diario y encoder existentes, autoridad Wild Engine real y canales MessageChannel/receptor temporal/estado confirmado reales.

Los casos directo y preparado parten de base1, retienen2 y reproducen solo3; un relevo de terreno bloqueado no emite checkpoint y su resolución tampoco confirma attachment antes del ACK real. Se conserva la identidad del actor de datos. Tras negociación/finish/visibilidad/activación, el mismo host publica snapshot completo4 y delta5 desde el nuevo encoder. No se reatacha el control nativo. Cursor, efectos o tiempo de trabajo incoherentes, handoff aportado por cliente, handoff real obsoleto y puerto de control sustituto rechazan antes de cambiar terreno. Un fallo del cambio de transporte retira el replay preparado y permite reintentar.

El adaptador de conexión con la autoridad, el transporte de terreno y los headers de efectos son fixtures. No se demuestra todavía un relevo con la Surface dentro del WorldWorker ordinario, ni un frame GPU/UI, ni ausencia de tirones.

Validación final: **599 dirigidas/40 archivos**, **{rp} de {rt} seleccionadas/328 archivos**, una omisión opcional, cero fallos/cancelaciones en esas selecciones; build Vite **{seconds}s**, cinco sintaxis. Fuentes congeladas: **556 inputs, 64 nativos intactos, 16 ajenos exactos**; no se recompila WASM.

Se contrastan por separado los fallos existentes: dos casos de `worker-runtime-host-historical-recovery` producen `releaseCommand is not a function` tanto antes como ahora (3 pases/2 fallos). Los otros controles anteriores siguen con timeline19/20 por timeout de negociación y host timeline sin terminar en25s, también antes/ahora; se retiran solo sus árboles propios. No se declara suite universal ni se ocultan esos pendientes. Las primeras pruebas nuevas omitían ACK del consumidor principal y una publicación de arranque válida; los arneses se corrigen y los logs fallidos/parciales se conservan fuera de la aceptación final.

El controlador inicial tenía un plazo de360s, menor que los587,97s registrados en la regresión completa anterior. Se retira únicamente ese controlador y se observa el **mismo proceso Node16224** mediante su handle de Windows abierto hasta su salida0; después se compila. No se reinician las pruebas ni se cuenta un log parcial como aceptación. Comando, recibo terminal y hashes se conservan.

**No hay ejecución GPU nueva en este avance.** Los cuatro casos y ceros de asignaciones/forks de `a6643b56c` son evidencia heredada del componente Surface, no una validación GPU del attachment ordinario del host.

Logs completos, baseline con fuentes anteriores, controles, listas exactas, fuente externa y hashes: [recibo](performance/{n}-validation-{date}.json).

## Siguiente punto

Conectar el RPC de reconexión de WorldWorker/cliente y seleccionar el camino retenido en la UI sobre el mismo binding/canvas. Invalidar testigos de frame anteriores, comprobar salud GPU real, exigir admisión nativa y frame nuevo de cámara/viewport actuales antes de publicar. Conservar imagen/dispatch bloqueado ante un attachment ambiguo y usar la recuperación fresca donde no sobrevivan los propietarios. Después siguen productor/cohort/paradas/relevos/cadencia/plataforma. A6/e-R3/e-R4/f-R4/A/B/C siguen abiertos; f-R3 seguridad conserva su cierre y D no iniciado.
''';Path(doc).write_bytes(body.encode())
paragraph=f'Continuación A4/e-R3/f-R4: [attachment retenido del host](native-retained-host-20261119.md). Host de producción obtiene su handoff autoritativo y prepara checkpoint/sufijo antes del relevo de terreno; replay inicia después, conserva base original y no sustituye control nativo. Patrón Redis8.2.1 leído en código; sin dependencia/diario/dueño nuevos.12nuevas,baselines2fallos+10fallos;599dirigidas/40,{rp}/{rt}seleccionadas/328/1omisión,build{seconds}s/5sintaxis;556inputs/64nativos intactos/16ajenos exactos. Modo producción/autoridad Wild Engine/MessageChannel reales,con adaptadores de conexión/terreno/FX. Directo/preparado2→3sin prefijo,ACK real y completo4/delta5 tras activación. Tres controles separados antes/actual:histórico3pases/2fallos releaseCommand,timeline19/20timeout,host25s;raws íntegros. Sin GPU nueva:ceros de Surface solo HEREDADOS de a6643b56c. Siguiente WorldWorker/cliente/UI mismos binding/canvas/frame nuevo;productor/cohort/paradas/relevos/cadencia/plataforma y A6/A/B/C abiertos,D no iniciado,f-R3 seguridad cerrado.'
docs=[]
for name in ['integrated-gpu-migration-plan-20261104.md','MIGRATION-OBJECTIVE.md','A6-CHECKLIST.md','CURRENT-STATUS.md']:
 p=Path('docs/guardian')/name;old=Path(f'.cache/{n}-{name}.before').read_bytes();assert p.read_bytes()==old;pos=old.index(b'\n')+1;p.write_bytes(old[:pos]+('\n'+paragraph+'\n\n').encode()+old[pos:]);assert p.read_bytes()[pos+len(p.read_bytes())-len(old):]==old[pos:];docs.append(p.as_posix())
files=own+docs+[doc,receipt]+artifacts;assert len(files)==len(set(files));write(f'.cache/{n}-commit-files.json',files);print('Documented',len(files),'owned paths;',rp,'of',rt,'selected;build',seconds,';source host only,no newGPU/UI claim.')
