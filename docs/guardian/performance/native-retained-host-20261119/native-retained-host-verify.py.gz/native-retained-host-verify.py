from pathlib import Path
import json,hashlib,gzip,re,subprocess,sys
n='native-retained-host';read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
e=read(f'docs/guardian/performance/{n}-validation-20261119.json');files=read(f'.cache/{n}-commit-files.json');own=read(f'.cache/{n}-owned-files.json')
assert len(files)==len(set(files)) and len(files)>25 and len(own)==5
for key,count in [('testedInputs',556),('nativeBuiltInputs',64),('preservedFiles',16)]:assert len(e[key])==count and all(sha(p)==h for p,h in e[key].items()),key
before=read(f'.cache/{n}-pre-tested-hashes.json');assert len(before)==540 and e['changedPriorInputs']==sorted(p for p,h in before.items() if e['testedInputs'][p]!=h) and set(e['changedPriorInputs'])<=set(own) and e['addedInputs']==sorted(set(e['testedInputs'])-set(before))
assert e['productionChangedFiles']==own[:3] and e['nativeChangedFiles']==[] and e['gpu']['newRuns']==0
assert Path('public/wild-engine/spatial-threaded.worker.mjs').read_bytes()==Path('.cache/native-idle-stroll-preserved-worker.mjs').read_bytes()
def refs(v):
 if isinstance(v,dict):
  if 'source' in v and 'sha256' in v:assert sha(v['source'])==v['sha256'],v['source']
  if 'original' in v and 'raw' in v:assert gzip.decompress(Path(v['raw']['source']).read_bytes())==Path(v['original']['source']).read_bytes(),v['original']['source']
  for x in v.values():refs(x)
 elif isinstance(v,list):
  for x in v:refs(x)
refs(e)
for label,t in e['tests'].items():
 s=Path(t['original']['source']).read_text(encoding='utf-8-sig');assert all(int(re.search(r'^# '+k+r' (\d+)\s*$',s,re.M).group(1))==t[k] for k in ['tests','pass','fail','cancelled','skipped']),label
t=e['tests'];assert e['newTests']==12 and (t['deferred-baseline']['pass'],t['deferred-baseline']['fail'],t['deferred-baseline']['skipped'])==(0,2,23) and (t['final-original-new']['pass'],t['final-original-new']['fail'])==(0,10)
assert t['fourth']['pass']==80 and t['final-focused']['pass']==599 and t['final-regression']['pass']>=4200 and t['final-regression']['tests']==t['final-regression']['pass']+1 and t['final-regression']['skipped']==1 and all(t[k]['fail']==t[k]['cancelled']==0 for k in ['fourth','final-focused','final-regression'])
assert all((t[k]['tests'],t[k]['pass'],t[k]['fail'])==(5,3,2) for k in ['historical-before','historical-current'])
assert len(e['focusedFiles'])==40 and len(e['regressionFiles'])==328 and len(e['syntax'])==5 and all(x['exitCode']==0 and x['sha256']==sha(x['file']) for x in e['syntax']) and e['build']['seconds']>0
controls=e['separatePreexistingFailures'];assert len(controls)==4 and {(x['mode'],x['case']) for x in controls}=={(a,b) for a in ['before','current'] for b in ['timeline','host']}
for row in controls:
 assert row['exitCode']!=0 and row['sha256']==sha(row['log'])
 s=Path(row['log']).read_text(encoding='utf-8-sig',errors='replace')
 if row['case']=='timeline':assert not row['timeout'] and 'Visual handshake timed out' in s and re.search(r'^# tests 20\s*$',s,re.M) and re.search(r'^# pass 19\s*$',s,re.M)
 else:assert row['timeout'] and row['secondsLimit']==25 and row['termination']['exitCode']==0
a=e['validationContinuation'];assert a['controllerPid']==22852 and a['sameTestPid']==16224 and a['controllerOnlyTerminationExitCode']==0 and not a['treeTermination'] and a['testExitCode']==a['buildExitCode']==0 and a['exact556Native64Foreign16']
process=read(a['processEvidence']['original']['source']);assert process['ProcessId']==16224 and process['ParentProcessId']==22852 and process['CommandLine']=='.cache/tooling/node20.exe --test '+' '.join(e['regressionFiles'])
for name in ['integrated-gpu-migration-plan-20261104.md','MIGRATION-OBJECTIVE.md','A6-CHECKLIST.md','CURRENT-STATUS.md']:
 old=Path(f'.cache/{n}-{name}.before').read_bytes();new=(Path('docs/guardian')/name).read_bytes();pos=old.index(b'\n')+1;assert new[:pos]==old[:pos] and len(new)>len(old) and new[pos+len(new)-len(old):]==old[pos:]
for row in e['productionBefore']:
 body=Path(row['snapshot']['original']['source']).read_bytes();committed=subprocess.check_output(['git','show',e['baseCommit']+':'+row['file']]);assert body.replace(b'\r\n',b'\n')==committed.replace(b'\r\n',b'\n')
assert subprocess.check_output(['git','branch','--show-current']).decode().strip()=='codex/guardian-3d-animation' and not subprocess.check_output(['git','diff','--cached','--name-only']).strip()
head=subprocess.check_output(['git','rev-parse','HEAD']).decode().strip();assert head==e['baseCommit'] or subprocess.check_output(['git','rev-parse','HEAD^']).decode().strip()==e['baseCommit']
if '--published' in sys.argv:
 assert not subprocess.check_output(['git','status','--porcelain','--',*files]).strip()
 assert subprocess.check_output(['git','rev-list','--left-right','--count','HEAD...origin/codex/guardian-3d-animation']).decode().strip()=='0\t0'
 assert subprocess.check_output(['git','ls-remote','origin','refs/heads/codex/guardian-3d-animation']).decode().split()[0]==head
subprocess.run(['git','diff','--check','--',*files],check=True);print('Verified',len(files),'paths;556/64native/16foreign;12new/599directed;',t['final-regression']['pass'],'of',t['final-regression']['tests'],'selected1skip/build',e['build']['seconds'],';5syntax,same adopted regression terminal0,original/current controls. Source host integration only;no newGPU/ordinary UI/cadence claim.',flush=True)
