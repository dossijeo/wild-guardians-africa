from pathlib import Path
import ctypes,ctypes.wintypes as w,json,subprocess,hashlib,os,time
n='native-retained-host';read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
k=ctypes.WinDLL('kernel32',use_last_error=True);k.OpenProcess.argtypes=[w.DWORD,w.BOOL,w.DWORD];k.OpenProcess.restype=w.HANDLE;k.GetExitCodeProcess.argtypes=[w.HANDLE,ctypes.POINTER(w.DWORD)];k.QueryFullProcessImageNameW.argtypes=[w.HANDLE,w.DWORD,w.LPWSTR,ctypes.POINTER(w.DWORD)];k.WaitForSingleObject.argtypes=[w.HANDLE,w.DWORD];k.CloseHandle.argtypes=[w.HANDLE]
testPid=16224;controllerPid=22852;handle=k.OpenProcess(0x100000|0x1000,False,testPid);assert handle
size=w.DWORD(32768);image=ctypes.create_unicode_buffer(size.value);assert k.QueryFullProcessImageNameW(handle,0,image,ctypes.byref(size));assert Path(image.value).resolve()==Path('.cache/tooling/node20.exe').resolve()
code=w.DWORD();assert k.GetExitCodeProcess(handle,ctypes.byref(code)) and code.value==259
kill=subprocess.run(['taskkill','/PID',str(controllerPid),'/F'],capture_output=True);Path(f'.cache/{n}-controller-only-stop.stdout.bin').write_bytes(kill.stdout);Path(f'.cache/{n}-controller-only-stop.stderr.bin').write_bytes(kill.stderr);assert kill.returncode==0
record={'controllerPid':controllerPid,'sameTestPid':testPid,'testImage':image.value,'controllerOnlyTerminationExitCode':kill.returncode,'treeTermination':False,'reason':'Original controller360s was shorter than recorded prior complete regression587.97s;adopt exact live test handle without restarting test.','startedAt':time.time()};target=Path(f'.cache/{n}-adopted-validation.json');target.write_text(json.dumps(record,indent=2)+'\n');print('Adopted SAME live regression process',testPid,'after stopping ONLY deadline controller',controllerPid,flush=True)
try:
 while True:
  result=k.WaitForSingleObject(handle,5000)
  if result==0:break
  assert result==258
 assert k.GetExitCodeProcess(handle,ctypes.byref(code));record['testExitCode']=code.value;record['finishedAt']=time.time();target.write_text(json.dumps(record,indent=2)+'\n');print('SAME regression terminal exit',code.value,flush=True);assert code.value==0
finally:k.CloseHandle(handle)
maps=[read(f'.cache/{n}-tested-hashes.json'),read(f'.cache/{n}-pre-built-hashes.json'),read(f'.cache/{n}-pre-preserved-hashes.json')];assert all(sha(p)==h for m in maps for p,h in m.items())
env=os.environ.copy();env['WILD_ENGINE_NATIVE_ROUTE_WASM']=str(Path('src/world/wild-engine/spatial-savanna.wasm').resolve());env['WILD_ENGINE_SPATIAL_SERVICES_WASM']=env['WILD_ENGINE_NATIVE_ROUTE_WASM']
with open(f'.cache/{n}-final-build.log','w',encoding='utf-8') as output:r=subprocess.run(['.cache/tooling/node20.exe','node_modules/vite/bin/vite.js','build'],env=env,stdout=output,stderr=output)
record['buildExitCode']=r.returncode;record['exact556Native64Foreign16']=all(sha(p)==h for m in maps for p,h in m.items());target.write_text(json.dumps(record,indent=2)+'\n');assert r.returncode==0 and record['exact556Native64Foreign16'];print('Build terminal0;556tested/64native/16foreign exact. No test restart.',flush=True)
