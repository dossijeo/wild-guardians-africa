from pathlib import Path
import json,subprocess,os,re
n='native-recovery-checkpoint';own=json.loads(Path('.cache/'+n+'-owned-files.json').read_text());sources=[p for p in own if p.startswith('src/')]
mapping={Path(p).resolve().as_uri():str(Path('.cache/'+n+'-'+Path(p).name+'.before').resolve()) for p in sources}
loader=Path('.cache/'+n+'-baseline-loader.mjs');loader.write_text("import {readFile} from 'node:fs/promises';\nconst sources=new Map("+json.dumps(list(mapping.items()))+");\nexport async function load(url,context,next){const file=sources.get(url);return file?{format:'module',source:await readFile(file,'utf8'),shortCircuit:true}:next(url,context);}\n")
absolute={str(Path(p).resolve()).replace('\\','/'):{'before':str(Path('.cache/'+n+'-'+Path(p).name+'.before').resolve()),'dir':str(Path(p).resolve().parent)} for p in sources}
plugin="const __originalNativeSources="+json.dumps(absolute)+";p.onLoad({filter:/\\.js$/},args=>{const item=__originalNativeSources[args.path.replaceAll('\\\\','/')];if(item)return {contents:readFileSync(item.before,'utf8'),loader:'js',resolveDir:item.dir};});"
helper=Path('.cache/'+n+'-baseline-host-helper.mjs');text=Path('tests/helpers/native-recovery-host.js').read_text(encoding='utf-8').replace('../../src/','../src/').replace("from './","from '../tests/helpers/");text="import {readFileSync} from 'node:fs';\n"+text.replace('setup(p){','setup(p){'+plugin);helper.write_text(text,encoding='utf-8')
copies=[]
for original in ['tests/native-recovery-checkpoint.test.js','tests/native-resource-flush.test.js','tests/webgpu-retained-worker.test.js']:
 text=Path(original).read_text(encoding='utf-8').replace("from './helpers/native-recovery-host.js'","from './"+helper.name+"'")
 if 'setup(p){' in text:text="import {readFileSync} from 'node:fs';\n"+text.replace('setup(p){','setup(p){'+plugin)
 p=Path('.cache/'+n+'-baseline-'+Path(original).name.replace('.js','.mjs'));p.write_text(text,encoding='utf-8');copies.append(str(p))
env=os.environ.copy();env['WILD_ENGINE_NATIVE_ROUTE_WASM']=str(Path('src/world/wild-engine/spatial-savanna.wasm').resolve());env['WILD_ENGINE_SPATIAL_SERVICES_WASM']=env['WILD_ENGINE_NATIVE_ROUTE_WASM']
with open('.cache/'+n+'-final-original-new.log','w',encoding='utf-8') as out:p=subprocess.run(['.cache/tooling/node20.exe','--loader',loader.resolve().as_uri(),'--test',*copies],env=env,stdout=out,stderr=out,timeout=150)
s=Path('.cache/'+n+'-final-original-new.log').read_text(encoding='utf-8');print('Baseline exit',p.returncode);print(s[-330:]);print('\n'.join(l[:180] for l in s.splitlines() if 'asynchronous activity' in l));assert p.returncode==1 and 'asynchronous activity' not in s
counts={k:int(re.findall(r'^# '+k+r' (\d+)\s*$',s,re.M)[-1]) for k in ['tests','pass','fail','cancelled','skipped']};print(counts);assert counts=={'tests':50,'pass':23,'fail':27,'cancelled':0,'skipped':0},counts
