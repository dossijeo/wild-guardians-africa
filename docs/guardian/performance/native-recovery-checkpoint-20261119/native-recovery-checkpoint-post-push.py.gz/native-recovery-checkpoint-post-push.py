from pathlib import Path
import json,subprocess,hashlib
n='native-recovery-checkpoint';r=json.loads(Path('docs/guardian/performance/'+n+'-validation-20261119.json').read_text())
for name in ['testedInputs','nativeBuiltInputs','preservedFiles']:
 for p,d in r[name].items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==d,p
files=json.loads(Path('.cache/'+n+'-publish-files.json').read_text());assert not subprocess.check_output(['git','diff','--cached','--name-only']).strip()
for p in files:
 assert not subprocess.check_output(['git','status','--porcelain','--',p]).strip(),p
 assert subprocess.check_output(['git','ls-files','--error-unmatch','--',p]).strip()
assert subprocess.check_output(['git','rev-list','--left-right','--count','HEAD...origin/codex/guardian-3d-animation']).strip()==b'0\t0'
print('Post-push:',len(files),'owned paths clean/tracked;index empty;616 inputs/64 native/16 foreign exact;HEAD/origin 0/0.')
