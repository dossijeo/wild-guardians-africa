from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys

prefix=Path(sys.argv[1]);variant=sys.argv[2]
assert prefix.parent.resolve()==Path('.cache').resolve() and variant in ('baseline','candidate')
assert not list(prefix.parent.glob(prefix.name+'*')),prefix
receipt=json.loads(Path('.cache/native-task-stop-home-graphics-validation.json').read_bytes())
assert receipt.get('finishedAt') and not any(receipt['changed'].values())
assert all(j['exitCode']==0 for j in receipt['jobs'].values())
archived=json.loads(Path('docs/guardian/performance/native-60fps-capture-20261120/native-ordinary-60hz-stream1-frozen.json').read_bytes())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
head=lambda:subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
paths=set(receipt['frozenInputs'])|set(receipt['nativeBuiltInputs'])|set(archived['files'])
paths|={p.as_posix() for p in Path('tools/guardian').glob('native-audit-*.mjs')}
paths.add('tools/guardian/audit_native_farm_birth_world_owner.mjs')
paths={p for p in paths if Path(p).is_file()}
files={p:sha(p) for p in sorted(paths)}
env={**archived['environment'],'OUTPUT':prefix.as_posix()+'.json','QA_NATIVE_TRACE_ONLY_HISTORY':'true',
     'QA_NATIVE_PIPELINE_PHASE_TRACE':'true','QA_NATIVE_TRACE_BUFFER_MB':'512'}
record={'head':head(),'variant':variant,'files':files,'environment':env,'targetMs':1000/60,'startedAt':now(),
 'scope':'Fresh 4K60 GPU comparison for same-call binding predicate memo with exact Host baseline/candidate and identical lean trace flags. Headless submitted draw history; physical scanout unmeasured.'}
tag=prefix.name
modeScript='.cache/native-60hz-temporary-display.py'
metadata=Path(str(prefix)+'-frozen.json')
def save():metadata.write_text(json.dumps(record,ensure_ascii=True,indent=2)+'\n',encoding='utf-8')
save()
try:
 subprocess.run([sys.executable,modeScript,'apply',tag],check=True)
 record['desktop']=json.loads(Path(f'.cache/native-60hz-{tag}-apply-receipt.json').read_bytes());save()
 with Path(str(prefix)+'.log').open('wb') as log:
  result=subprocess.run(['.cache/tooling/node20.exe','tools/guardian/audit_native_farm_birth_world_owner.mjs'],env={**os.environ,**env},stdout=log,stderr=subprocess.STDOUT)
 record['exitCode']=result.returncode;save()
finally:
 if Path(f'.cache/native-60hz-{tag}-apply-receipt.json').is_file():
  restore=subprocess.run([sys.executable,modeScript,'restore',tag]);record['restoreExitCode']=restore.returncode
  if restore.returncode==0:record['restore']=json.loads(Path(f'.cache/native-60hz-{tag}-restore-receipt.json').read_bytes())
 record['changed']=[p for p,h in files.items() if not Path(p).is_file() or sha(p)!=h]
 record['endHead']=head();record['finishedAt']=now();save()
assert record['restoreExitCode']==0 and record['restore']['after']['hz']==30
assert record['head']==record['endHead'] and not record['changed'],record['changed']
assert record['exitCode']==0,record['exitCode']
subprocess.run(['.cache/tooling/node20.exe','tools/guardian/native-audit-ordinary-report.mjs',prefix.as_posix()],check=True)
