// Private candidate: transform the existing Host, never write production.
export function bindingPass(source){
 const start=source.indexOf('  function admitClockBindings(packet,preparing=false){');
 const end=source.indexOf('  async function initializePreparedWorldFrame(',start);
 if(start<0||end<0)throw Error('Host admission seam changed');
 return {start,end,body:source.slice(start,end)};
}
export function candidate(source){
 const {start,end,body}=bindingPass(source);let next=body;
 const seam='    const leases=new Map();';
 if(!next.includes(seam))throw Error('Existing lease reuse changed');
 next=next.replace(seam,`${seam}
    // References and keys were copied/validated by this Host. Reuse only the
    // same predicate over the same key in this synchronous admission pass.
    // Never retain these results across READY, a control event or a yield.
    const checkedMotion=new Map();
    const checkMotion=(binding,predicate,check)=>{
      if(!binding.nativeClockKey)return check();
      const key=predicate+':'+binding.nativeClockKey;
      if(!checkedMotion.has(key))checkedMotion.set(key,check());
      return checkedMotion.get(key);
    };`);
 const names=['InitialIdleBody','IdleCycle','Settlement','Action','Stroll','FarmArrival','Home','Consequence','Start'];
 const comparators={InitialIdleBody:'sameNativeInitialIdleBodyReference',IdleCycle:'sameNativeIdleCycleReference',Settlement:'sameNativeTaskSettlementReference',Action:'sameNativeTaskActionReference',Stroll:'sameNativeIdleStrollReference',FarmArrival:'sameNativeFarmArrivalRouteReference',Home:'sameNativeHomeRouteReference',Consequence:'sameNativeTaskConsequenceReference',Start:'sameNativeTaskStartReference'};
 const templates={Settlement:'TaskSettlement',Action:'TaskAction',Stroll:'IdleStroll',Home:'HomeRoute',Consequence:'TaskConsequence',Start:'TaskStart'};
 for(const name of names){
  const expression=`${comparators[name]}(binding.native${name},packet.metadata.native${templates[name]??name}Template)`;
  if(next.split(expression).length!==2)throw Error('Template seam changed: '+name);
  next=next.replace(expression,`checkMotion(original,'template',()=>${expression})`);
 }
 const terminals=[
  "preparedBindings.some(b=>b.semantic==='relative'&&b.nativeIdleCycle&&sameNativeIdleCycleReference(b.nativeIdleCycle,binding.nativeIdleCycle)&&b.resourceEnd===undefined)",
  "preparedBindings.some(b=>b.semantic==='relative'&&b.nativeStroll&&sameNativeIdleStrollReference(b.nativeStroll,binding.nativeStroll)&&b.resourceEnd===nativeClockResourceEnd(binding.epoch,binding.nativeStroll.endTime))",
  "preparedBindings.some(b=>b.semantic==='relative'&&b.nativeFarmArrival&&sameNativeFarmArrivalRouteReference(b.nativeFarmArrival,binding.nativeFarmArrival)&&b.resourceEnd===nativeClockResourceEnd(binding.epoch,binding.nativeFarmArrival.endTime))"
 ];
 for(const expression of terminals){
  if(next.split(expression).length!==2)throw Error('Relative-clock seam changed');
  next=next.replace(expression,`checkMotion(original,'relative-clock',()=>${expression})`);
 }
 return source.slice(0,start)+next+source.slice(end);
}
export function observe(source){
 const {start,end,body}=bindingPass(source);
 // Count only calls made by the production admission pass, not bridge/DTO
 // calls elsewhere. No timings, artificial delays or authority substitutions.
 let next=body.replaceAll('sameNativeFarmArrivalRouteReference','countedFarmReference');
 next=next.replace('  function admitClockBindings(packet,preparing=false){',`  function admitClockBindings(packet,preparing=false){
    const qa={preparing,farmComparisons:0};
    globalThis.__nativeBindingPasses?.push(qa);
    const countedFarmReference=(...args)=>{qa.farmComparisons++;return sameNativeFarmArrivalRouteReference(...args);};`);
 return source.slice(0,start)+next+source.slice(end);
}
