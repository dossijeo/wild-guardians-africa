import {candidate,observe} from './native-binding-checks-candidate.mjs';
export async function load(url,context,nextLoad){
 const result=await nextLoad(url,context);
 if(!url.endsWith('/src/rendering/remote-webgpu-host.js'))return result;
 let source=String(result.source);
 if(process.env.QA_BINDING_CANDIDATE==='1')source=candidate(source);
 return {...result,source:observe(source)};
}
