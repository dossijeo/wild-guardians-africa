import test from 'node:test';
import assert from 'node:assert/strict';
import {setup,admit,present} from '../tests/helpers/native-farm-arrival-remote.js';

// Real WASM/authority/client/Host; the existing deterministic GPU double.
// This is an operation-count regression, not a wall-time or 60 fps claim.
test('duplicate Farm uniforms reuse checks only within each synchronous admission pass',async()=>{
 const f=await setup({idlePhaseCapability:true});let p;
 const passes=globalThis.__nativeBindingPasses=[];
 try{
  const copies=24;
  f.buffer=f.client.device.createBuffer({size:copies*8,usage:72});
  f.group=f.client.device.createBindGroup({entries:[{binding:0,resource:{buffer:f.buffer}}]});
  const register=f.client.registerClockBinding;
  f.client.registerClockBinding=(buffer,binding)=>{
   for(let i=0;i<copies;i++)register(buffer,{...binding,byteOffset:i*8+binding.byteOffset});
  };
  p=admit(f,{idlePhase:true,mode:'late'});
  const result=await p.promise;
  assert.equal(result.status,'committed',result.error);
  const pick=await present(f,p);
  assert.equal(pick.getFarmArrivalElapsed(p.reference),0);
  assert(passes.length>=3,'preparation, Quiesce and release must revalidate independently');
  assert(passes.every(pass=>pass.farmComparisons>0),'no admission result survives a control boundary');
  console.log('Farm admission comparisons:',passes.map(pass=>pass.farmComparisons));
  assert(passes.every(pass=>pass.farmComparisons<=3),'one check per complete Host key/predicate, not per duplicated uniform');
  assert.deepEqual(f.errors,[]);assert.deepEqual(f.sourceErrors,[]);
 }finally{delete globalThis.__nativeBindingPasses;p?.prepared?.abort();await f.close();}
});

test('a different source in a repeated uniform cannot borrow the first key approval',async()=>{
 const f=await setup({idlePhaseCapability:true});let p;
 try{
  const register=f.client.registerClockBinding;
  f.client.registerClockBinding=(buffer,binding)=>{
   register(buffer,binding);
   if(binding.semantic==='idle-offset'){
    const other=structuredClone(binding.nativeFarmArrival);other.sourceRequest.pose.yaw+=.1;
    // A producer-supplied key cannot replace the Host-generated complete key.
    register(buffer,{...binding,byteOffset:8,nativeFarmArrival:other,nativeClockKey:'forged'});
   }
  };
  p=admit(f,{idlePhase:true});const result=await p.promise;
  assert.notEqual(result.status,'committed');
  assert.equal(f.planner.nativeFarmArrivalRouteBinding(f.actor),null);
  assert.equal(f.gpu.canvasSubmissions.length,0);
 }finally{p?.prepared?.abort();await f.close();}
});

test('a repeated Idle-phase binding cannot replace its required terminal decoder',async()=>{
 const f=await setup({idlePhaseCapability:true});let p;
 try{
  p=admit(f,{idlePhase:true,decoderClock:false});const result=await p.promise;
  assert.notEqual(result.status,'committed');
  assert.equal(f.planner.nativeFarmArrivalRouteBinding(f.actor),null);
  assert.equal(f.gpu.canvasSubmissions.length,0);
 }finally{p?.prepared?.abort();await f.close();}
});
