import json,math,sys
from pathlib import Path

def read(name):return json.loads(Path(name).read_bytes())
def summarize(prefix):
    receipt=read(prefix+'.json');frozen=read(prefix+'-frozen.json')
    report=read(prefix+'-report.json');ordinary=read(prefix+'-ordinary-report.json')
    done=read(prefix+'.trace-complete.json');artifacts={}
    assert frozen['exitCode']==0 and frozen['changed']==[] and frozen['restore']['after']['hz']==30
    assert done['dataLossOccurred'] is False and done['collectionComplete'] is True
    assert report['wholeHistoryPresent'] and report['coverage']['terminal']=='retired-drained'
    assert report['targetMs']==1000/60 and ordinary['traceLossFree'] and not ordinary['incompleteSequences']
    assert not receipt['errors'] and not receipt['consoleErrors'] and not receipt['httpFailures']
    queue=[receipt];jobs={}
    while queue:
        current=queue.pop()
        if isinstance(current,dict):
            for key,value in current.items():
                if key=='qaPipelineTimings':
                    for row in value:
                        key=row['id'];jobs[key]={**jobs.get(key,{}),**{k:v for k,v in row.items() if v is not None}}
                elif isinstance(value,(dict,list)):queue.append(value)
        elif isinstance(current,list):queue.extend(v for v in current if isinstance(v,(dict,list)))
    assert jobs and all(isinstance(r.get('startedAt'),(int,float)) and isinstance(r.get('finishedAt'),(int,float)) and r['finishedAt']>=r['startedAt'] for r in jobs.values())
    edges=[edge for r in jobs.values() if r['finishedAt']>r['startedAt'] for edge in [(r['startedAt'],1),(r['finishedAt'],-1)]]
    peak=active=0
    for _,delta in sorted(edges):
        active+=delta;peak=max(peak,active)
    assert active==0
    intervals=sorted(r['intervalMs'] for r in report['history']['frames'] if r.get('intervalMs') is not None)
    target=1000/60;percentiles={f'p{int(p*100)}':intervals[math.ceil(len(intervals)*p)-1] for p in (0.50,0.95,0.99)}
    worst=ordinary['worstWindow']
    overlap=[r['id'] for r in jobs.values() if r['startedAt']<worst['to'] and r['finishedAt']>worst['from']]
    return {'prefix':prefix,'head':frozen['head'],'peakExplicitFactories':peak,'factories':len(jobs),'scopeFactories':'Unique jobs with start/end observed in audit snapshots. Counts explicit Host factories only.',
        'counts':report['counts'],'coverage':report['coverage'],'maxima':report['maxima'],'drawIntervalPercentilesMs':percentiles,
        'targetExceedances':{k:len(v) for k,v in report['targetExceedances'].items()},'intervalsAtLeastTwoPeriods':sum(v>=2*target for v in intervals),
        'ordinaryComplete':ordinary['ordinarySequences'],'largestIntervalWindow':worst['frame'],'explicitFactoriesOverlappingLargestInterval':overlap,
        'holds':[{k:h[k] for k in ['holdId','holdMs','drainMs','missedOpportunities']} for h in report['holds']],
        'trace':{k:done[k] for k in ['dataLossOccurred','collectionComplete','sha256','exportedBytes','peakBufferUsage','browserVersion']},'jobs':list(jobs.values())},frozen

before,bf=summarize(sys.argv[1]);after,af=summarize(sys.argv[2]);allowed={'src/rendering/remote-webgpu-host.js','tests/remote-pipeline-admission.test.js'}
assert {p for p,h in bf['files'].items() if af['files'].get(p)!=h}|(set(af['files'])-set(bf['files'])) <= allowed
assert bf['files']['src/rendering/remote-webgpu-host.js']!=af['files']['src/rendering/remote-webgpu-host.js']
assert {k:v for k,v in bf['environment'].items() if k!='OUTPUT'}=={k:v for k,v in af['environment'].items() if k!='OUTPUT'}
assert after['peakExplicitFactories']==1 and before['peakExplicitFactories']>1
out={'scope':'Matched exploratory 4K60 pair with exact frozen runtime/configuration apart from Host candidate. Visible presentation, GPU task attribution and universal cadence require additional evidence.','targetMs':1000/60,'baseline':before,'candidate':after}
Path(sys.argv[3]).write_text(json.dumps(out,ensure_ascii=True,indent=2)+'\n',encoding='utf-8')
for row in [before,after]:print(json.dumps({k:v for k,v in row.items() if k not in ['jobs','holds']}))
