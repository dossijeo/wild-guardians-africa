from pathlib import Path
import json,subprocess,os,re
n='native-quiescence-failure';own=json.loads(Path('.cache/'+n+'-owned-files.json').read_text());sources=[p for p in own if p.startswith('src/')]
absolute={str(Path(p).resolve()).replace('\\','/'):{'before':str(Path('.cache/'+n+'-'+Path(p).name+'.before').resolve()),'dir':str(Path(p).resolve().parent)} for p in sources}
plugin='const __originalNativeSources='+json.dumps(absolute)+";p.onLoad({filter:/\\.js$/},args=>{const item=__originalNativeSources[args.path.replaceAll('\\\\','/')];if(item)return {contents:readFileSync(item.before,'utf8'),loader:'js',resolveDir:item.dir};});"
text=Path('tests/native-production-lifecycle.test.js').read_text(encoding='utf-8').replace("from './helpers/","from '../tests/helpers/").replace('setup(p){','setup(p){'+plugin)
p=Path('.cache/'+n+'-final-original.test.mjs');p.write_text(text,encoding='utf-8');env=os.environ.copy();env['WILD_ENGINE_NATIVE_ROUTE_WASM']=str(Path('src/world/wild-engine/spatial-savanna.wasm').resolve());env['WILD_ENGINE_SPATIAL_SERVICES_WASM']=env['WILD_ENGINE_NATIVE_ROUTE_WASM']
with open('.cache/'+n+'-final-original-new.log','w',encoding='utf-8') as out:result=subprocess.run(['.cache/tooling/node20.exe','--test',str(p)],env=env,stdout=out,stderr=out,timeout=90)
s=Path('.cache/'+n+'-final-original-new.log').read_text(encoding='utf-8');print('Original modules exit',result.returncode);print(s[-240:]);assert result.returncode==1 and 'asynchronous activity' not in s
counts={k:int(re.findall(r'^# '+k+r' (\d+)\s*$',s,re.M)[-1]) for k in ['tests','pass','fail','cancelled','skipped']};assert counts=={'tests':21,'pass':18,'fail':3,'cancelled':0,'skipped':0},counts
