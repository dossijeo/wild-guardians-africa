from pathlib import Path
import json,hashlib,subprocess
n='native-quiescence-failure';previous='native-recovery-checkpoint'
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
def write(p,v):Path(p).write_bytes((json.dumps(v,indent=2)+'\n').encode())
own=['src/simulation/simulation-authority-worker.js','src/simulation/worker-runtime-host.js','tests/native-production-lifecycle.test.js']
assert subprocess.check_output(['git','rev-parse','HEAD']).strip()==b'1070cb6e9552187b421dc29d2ddcb4148100471e'
assert not subprocess.check_output(['git','diff','--cached','--name-only']).strip()
for label in ['pre-built-hashes','pre-preserved-hashes']:
 value=read('.cache/'+previous+'-'+label+'.json')
 for p,h in value.items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h,p
 write('.cache/'+n+'-'+label+'.json',value)
for p in own:
 assert not subprocess.check_output(['git','status','--porcelain','--',p]).strip(),p
 Path('.cache/'+n+'-'+Path(p).name+'.before').write_bytes(Path(p).read_bytes())
for name in ['CURRENT-STATUS.md','MIGRATION-OBJECTIVE.md','A6-CHECKLIST.md','integrated-gpu-migration-plan-20261104.md']:Path('.cache/'+n+'-'+name+'.before').write_bytes(Path('docs/guardian/'+name).read_bytes())
write('.cache/'+n+'-owned-files.json',own)
reference=read('.cache/native-resource-flush-research.json')[0];assert hashlib.sha256(Path(reference['local']).read_bytes()).hexdigest()==reference['sha256']
write('.cache/'+n+'-decision.json',{'readBeforeImplementation':True,'reference':reference,'symbolsRead':['Conn.drainConnection5543','drainConnection5621-5638:error callback then Close after FlushTimeout failure'],'actualReproduction':'.cache/'+n+'-diagnostic.log','observation':'Actual production hosted/runtime/authorityclient/sourceWorker/C++authority+resourceport:rejected resourcecommit/flush leaves producer suspended with faultnull,source wrapper deletes its opaquehold,second quiesce fails again;RPC errors reportedrecoverable. Native no-longer-controllable hold is not successful cleanup.','adaptation':'Like NATS failed drain terminalconnection:retain real local receipt in EXISTING sourcehold immediately after producerquiescence,mark settled onlyafteractualflush. If flushfails whileactualproducerreceipt exists,keep matchingunsettledrecord until existing terminal nativeIntentControlFailure makes authorityclientfail/terminate;no resume/forgedreceipt/newcounter/owner/dependency. Host observes existing authorityclient failed state and forwards existing failure for explicitcontrol and automaticcheckpoint preparation,so Window fails/closes actualowners ratherthanreporting recoverableRPC/unfreezing orphanproducer.','constraints':'Invalid/stale request and failures before acquiring an actual producerreceipt retain existingrecoverablecontrolerror. Inactive/null receipt doesnot make ordinary graphicsloss an authorityfatalfailure:existing sourceholdcan be recreated,resourceport replaced,actualnullhold explicitlyresumed. Failedactivecohort/device-loss recovery remainsunaccepted;thisis observable terminalfailure safety,not a reconstructedworld/rollback/claim of continuity.'})
print('Prepared3owned paths;64native/16foreign exact;actualNATSsourceSHAverified;decisionbefore implementation.')
