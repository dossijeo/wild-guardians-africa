from pathlib import Path
import subprocess,os
n='native-quiescence-failure'
source=Path('tests/native-production-lifecycle.test.js').read_text(encoding='utf-8').replace("from './helpers/","from '../tests/helpers/")
needle="assert.equal(f.native.authority.nativeResourcePreparationStatus().phase,'failed');}"
assert source.count(needle)==1
source=source.replace(needle,"assert.equal(f.native.authority.nativeResourcePreparationStatus().phase,'failed');console.log('quiescence-failure-after-resource-rejection',JSON.stringify(f.native.authority.nativeIntentProductionStatus()));await assert.rejects(f.runtime.quiesceNativeIntentProduction(),/commit|closed|unavailable|flush/i);console.log('quiescence-failure-after-second-attempt',JSON.stringify(f.native.authority.nativeIntentProductionStatus()));console.log('quiescence-failure-source-controls',JSON.stringify(f.source.messages.filter(m=>m.kind.startsWith('nativeIntentProduction'))));}")
p=Path('.cache/'+n+'-diagnostic.test.mjs');p.write_text(source,encoding='utf-8')
env=os.environ.copy();env['WILD_ENGINE_NATIVE_ROUTE_WASM']=str(Path('src/world/wild-engine/spatial-savanna.wasm').resolve());env['WILD_ENGINE_SPATIAL_SERVICES_WASM']=env['WILD_ENGINE_NATIVE_ROUTE_WASM']
with open('.cache/'+n+'-diagnostic.log','w',encoding='utf-8') as out:result=subprocess.run(['.cache/tooling/node20.exe','--test','--test-name-pattern=source Worker suspension waits',str(p)],env=env,stdout=out,stderr=out,timeout=90)
print('Diagnostic exit',result.returncode)
text=Path('.cache/'+n+'-diagnostic.log').read_text(encoding='utf-8');print('\n'.join(line for line in text.splitlines() if 'quiescence-failure-' in line));print(text[-220:]);raise SystemExit(result.returncode)
