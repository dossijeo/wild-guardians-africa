import './native-worker-world-audit-worker.js';
import {WebGPURenderer} from 'three/webgpu';

// QA only: observe the production endpoint and retain one genuine newborn
// READY reply. Source and hardware draw keep their ordinary independent ports.
const productionMessage=self.onmessage,send=self.postMessage.bind(self),render=WebGPURenderer.prototype.render;
let diagnostic=null,oldActor=null,held=null,heldOnce=false,scene=null;
WebGPURenderer.prototype.render=function(...args){scene=args[0];return render.apply(this,args);};
function rigs(){
 const result=[];for(const root of scene?.children??[]){const bones=[];root.traverse(n=>{if(n.isBone)bones.push({id:n.id,position:n.position.toArray(),quaternion:n.quaternion.toArray(),scale:n.scale.toArray()});});if(bones.length)result.push({root:root.id,bones});}return result;
}
function footsteps(){const result=[];scene?.traverse(n=>{if(n._wgFootstepSamples)result.push({mesh:n.id,geometry:n.geometry?.id,texture:n._wgFootstepSamples.id});});return result;}
function block(stage,ms){
 const start=performance.timeOrigin+performance.now();diagnostic.postMessage({kind:'birth-block-start',stage,start});
 const until=performance.now()+ms;while(performance.now()<until){}
 diagnostic.postMessage({kind:'birth-block-end',stage,start,end:performance.timeOrigin+performance.now()});
}
self.onmessage=event=>{
 const data=event.data;
 if(data?.kind==='configure-birth-audit'){diagnostic=data.port;oldActor=data.oldActor;diagnostic.start();return;}
 if(data?.kind==='block-birth-preparation'){block('preparation',data.durationMs);return;}
 if(data?.kind==='release-birth-ready'){if(!held)throw Error('No newborn READY reply retained');const forward=held;held=null;forward();block('commit',data.durationMs);return;}
 if(data?.remoteGpuPort)data.remoteGpuPort.addEventListener('message',({data:reply})=>{if(reply.result?.disposed===true)diagnostic?.postMessage({kind:'birth-gpu-drained',receipt:reply.result});});
 if(data?.kind==='attachNativeResourcePreparation'){
  const port=data.port,post=port.postMessage.bind(port);port.postMessage=(message,...args)=>{
   const reference=message?.result?.preparedFarmArrivalTemplate;
   if(!heldOnce&&message.kind==='nativeGateResourcesResult'&&reference&&reference.actorId!==oldActor){heldOnce=true;held=()=>post(message,...args);diagnostic.postMessage({kind:'birth-resources-ready',at:performance.timeOrigin+performance.now(),reference});return;}
   return post(message,...args);
  };
 }
 return productionMessage(event);
};
self.postMessage=(message,...args)=>{if(message.kind==='disposed')diagnostic?.postMessage({kind:'birth-disposed'});return send(message.kind==='inspection'?{...message,qaBirthRigs:rigs(),qaBirthFootsteps:footsteps()}:message,...args);};
