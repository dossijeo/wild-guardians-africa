from pathlib import Path
import json,subprocess,os
n='native-paused-publication';sources=['src/simulation/paused-authority-quiescence.js','src/simulation/simulation-authority.js']
mapping={Path(p).resolve().as_uri():str(Path('.cache/'+n+'-'+Path(p).name+'.before').resolve()) for p in sources}
loader=Path('.cache/'+n+'-baseline-loader.mjs');loader.write_text("import {readFile} from 'node:fs/promises';\nconst sources=new Map("+json.dumps(list(mapping.items()))+");\nexport async function load(url,context,next){const file=sources.get(url);return file?{format:'module',source:await readFile(file,'utf8'),shortCircuit:true}:next(url,context);}\n")
env=os.environ.copy();env['WILD_ENGINE_NATIVE_ROUTE_WASM']=str(Path('src/world/wild-engine/spatial-savanna.wasm').resolve());env['WILD_ENGINE_SPATIAL_SERVICES_WASM']=env['WILD_ENGINE_NATIVE_ROUTE_WASM']
with open('.cache/'+n+'-final-original-new.log','w',encoding='utf-8') as out:p=subprocess.run(['.cache/tooling/node20.exe','--loader',loader.resolve().as_uri(),'--test','tests/native-paused-publication.test.js'],env=env,stdout=out,stderr=out,timeout=120)
s=Path('.cache/'+n+'-final-original-new.log').read_text(encoding='utf-8');print('Baseline exit',p.returncode);print(s[-350:]);assert p.returncode==1 and '# pass 1\n' in s and '# fail 4\n' in s and 'asynchronous activity' not in s
