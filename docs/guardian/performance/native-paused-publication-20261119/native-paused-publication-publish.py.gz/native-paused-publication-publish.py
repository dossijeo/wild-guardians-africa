from pathlib import Path
import subprocess,json,hashlib,gzip
n='native-paused-publication'
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a]).strip()
files=read('.cache/'+n+'-publish-files.json');rp=Path('docs/guardian/performance/'+n+'-validation-20261119.json');receipt=read(rp)
assert len(files)==len(set(files))
assert git('branch','--show-current')==b'codex/guardian-3d-animation'
assert git('rev-parse','HEAD')==receipt['baseCommit'].encode()
assert not git('diff','--cached','--name-only')
for mapping in [receipt['testedInputs'],receipt['nativeBuiltInputs'],receipt['preservedFiles']]:
 for p,h in mapping.items():assert sha(Path(p).read_bytes())==h,p
assert not set(files)&set(receipt['preservedFiles'])
for row in receipt['primaryBefore']:
 p=Path(row['file']);before=Path('.cache/'+n+'-'+p.name+'.before').read_bytes();assert sha(before)==row['sha256'];split=before.index(b'\n')+1;assert p.read_bytes().startswith(before[:split]) and p.read_bytes().endswith(before[split:])
for row in receipt['artifacts']:
 body=Path(row['artifact']).read_bytes();assert sha(body)==row['artifactSha256'];assert sha(gzip.decompress(body))==row['sha256']
pathspec=Path('.cache/'+n+'-publish-pathspec.bin');pathspec.write_bytes(b'\0'.join(p.encode() for p in files)+b'\0')
subprocess.run(['git','add','--pathspec-from-file='+str(pathspec),'--pathspec-file-nul'],check=True)
staged=git('diff','--cached','--name-only','-z').decode().strip('\0').split('\0');assert set(staged)==set(files)
normalized=[]
for p in receipt['changedFiles']:
 work=Path(p).read_bytes().replace(b'\r\n',b'\n');index=subprocess.check_output(['git','show',':'+p]);assert work==index,p;normalized.append({'file':p,'indexLFNormalizedSha256':sha(index),'matchesTestedWorktreeAfterLFNormalization':True})
receipt['gitIndexTextNormalization']=normalized;rp.write_bytes((json.dumps(receipt,indent=2)+'\n').encode());subprocess.run(['git','add','--',str(rp)],check=True)
subprocess.run(['git','diff','--cached','--check'],check=True)
print('Staged exactly',len(staged),'owned paths;613 tested/64native/16foreign exact;',len(receipt['artifacts']),'verified archives;four index source bodies equal tested inputs after LF normalization.')
print(git('diff','--cached','--numstat','--',*[p['file'] for p in receipt['primaryBefore']]).decode())
