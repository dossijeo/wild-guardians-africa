import fs from 'node:fs';import assert from 'node:assert/strict';import {pathToFileURL} from 'node:url';
import {createThreadedSpatialWorld} from '../../src/world/wild-engine/spatial-thread-runtime.js';
const fresh=['nav_task_route_stop_proposal_source_matches'];
const oldModule=new WebAssembly.Module(fs.readFileSync('src/world/wild-engine/spatial-savanna.wasm')),nextModule=new WebAssembly.Module(fs.readFileSync('.cache/native-task-stop-bridge-canonical/standalone/spatial-savanna.wasm'));
const sorted=m=>WebAssembly.Module.exports(m).map(e=>[e.name,e.kind]).sort((a,b)=>a[0].localeCompare(b[0]));
assert.deepEqual(sorted(nextModule).filter(([n])=>!fresh.includes(n)),sorted(oldModule));assert.deepEqual(WebAssembly.Module.imports(nextModule),WebAssembly.Module.imports(oldModule));
assert.deepEqual(sorted(nextModule).filter(([n])=>fresh.includes(n)),fresh.map(n=>[n,'function']).sort((a,b)=>a[0].localeCompare(b[0])));
const publicNames=[];for(const name of ['public/wild-engine/spatial-threaded.mjs','.cache/native-task-stop-bridge-canonical/pthread/spatial-threaded.mjs']){
 const {default:factory}=await import(pathToFileURL(process.cwd()+'/'+name));const wasmBinary=fs.readFileSync(name.replace(/mjs$/,'wasm'));const rt=await createThreadedSpatialWorld(factory,{wasmBinary});try{
  publicNames.push(Object.keys(rt.runtime).filter(n=>n.startsWith('_')&&typeof rt.runtime[n]==='function').sort());if(name.startsWith('.cache/'))assert.equal(typeof rt.runtime._nav_task_route_stop_proposal_source_matches,'function');
 }finally{await rt.dispose();}
}
assert.deepEqual(publicNames[1].filter(n=>!fresh.map(n=>'_'+n).includes(n)),publicNames[0]);assert.deepEqual(publicNames[1].filter(n=>fresh.map(n=>'_'+n).includes(n)),fresh.map(n=>'_'+n).sort());
const threadedOld=new WebAssembly.Module(fs.readFileSync('public/wild-engine/spatial-threaded.wasm')),threadedNew=new WebAssembly.Module(fs.readFileSync('.cache/native-task-stop-bridge-canonical/pthread/spatial-threaded.wasm'));
assert.equal(WebAssembly.Module.exports(threadedNew).length,WebAssembly.Module.exports(threadedOld).length+1);
console.log(JSON.stringify({standalone:{before:WebAssembly.Module.exports(oldModule).length,after:WebAssembly.Module.exports(nextModule).length,oldNamesAndKindsPreserved:true,importsUnchanged:true},pthread:{before:WebAssembly.Module.exports(threadedOld).length,after:WebAssembly.Module.exports(threadedNew).length,publicBefore:publicNames[0].length,publicAfter:publicNames[1].length,publicNamesPreserved:true,pairedFactoryInstantiated:true},additiveNames:fresh}));
