from pathlib import Path
import datetime,hashlib,json,os,re,shutil,subprocess,sys,time

r=Path.cwd();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
prior=json.loads((r/'docs/guardian/performance/native-idle-home-pending-proposal-20261120-validation.json').read_text(encoding='utf-8'))
baseline=json.loads((r/'.cache/native-task-stop-bridge-baseline.json').read_text(encoding='utf-8'))
folder=r/'.cache/native-task-stop-bridge-canonical';assert not folder.exists();folder.mkdir()
script=r/'tools/build-spatial-savanna-wasm.sh';text=script.read_text(encoding='utf-8')
match=re.search(r"EXPORTED_FUNCTIONS=(\[.*?\])'",text,re.S);assert match
exports=json.loads(match.group(1));exportFile=folder/'exports.json';exportFile.write_text(json.dumps(exports)+'\n',encoding='utf-8')
oldScript=(r/'.cache/native-task-stop-bridge-before-build.sh').read_bytes()
newNames=['_nav_task_route_stop_proposal_source_matches']
assert script.read_bytes().replace(('"'+newNames[0]+'",').encode(),b'')==oldScript
sourceInputs={p:sha(p) for p in baseline['nativeInputs'] if not p.endswith(('.wasm','.mjs'))}
record={'scope':'Task25 stop selector and receipt integration, one additive read-only API. No Host/Game/ordinary producer enablement or GPU acceptance. Both variants built privately and checked before installation.','startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baseHead':baseline['baseHead'],'scriptSha256':sha(script),'exportsCount':len(exports),'exportsSha256':sha(exportFile),'sourceInputs':sourceInputs,'commands':[],'outputs':{}}
recordFile=r/'.cache/native-task-stop-bridge-canonical-build.json'
def save():recordFile.write_text(json.dumps(record,ensure_ascii=True,indent=2)+'\n',encoding='utf-8')
environment={'EM_CONFIG':str(r/'.cache/emsdk/.emscripten'),'EMSDK':str(r/'.cache/emsdk'),'EMSDK_PYTHON':sys.executable}
record['environment']=environment
for entry in prior['nativeBuild']['commands']:
 label=entry['label'];outdir=folder/label;outdir.mkdir();out=outdir/('spatial-savanna.wasm' if label=='standalone' else 'spatial-threaded.mjs')
 old=entry['command'];compilerIndex=next(i for i,a in enumerate(old) if a.endswith('em++.py'));args=old[compilerIndex+1:]
 args=[('EXPORTED_FUNCTIONS=@'+str(exportFile)) if a.startswith('EXPORTED_FUNCTIONS=@') else a for a in args];args[args.index('-o')+1]=str(out)
 command=[sys.executable,'-E',str(r/'.cache/emsdk/upstream/emscripten/em++.py'),*args];log=folder/(label+'.log');item={'label':label,'command':command,'log':str(log),'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()};record['commands'].append(item);save();print(label+' compile starts',flush=True);start=time.monotonic()
 with log.open('wb') as stream:result=subprocess.run(command,env={**os.environ,**environment},stdout=stream,stderr=subprocess.STDOUT)
 item.update({'exitCode':result.returncode,'seconds':time.monotonic()-start,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'logSha256':sha(log)});save();assert result.returncode==0,label
for p,h in sourceInputs.items():assert sha(p)==h,p
abiFile=folder/'abi.mjs'
abiFile.write_text('''import fs from 'node:fs';import assert from 'node:assert/strict';import {pathToFileURL} from 'node:url';
import {createThreadedSpatialWorld} from '../../src/world/wild-engine/spatial-thread-runtime.js';
const fresh=['nav_task_route_stop_proposal_source_matches'];
const oldModule=new WebAssembly.Module(fs.readFileSync('src/world/wild-engine/spatial-savanna.wasm')),nextModule=new WebAssembly.Module(fs.readFileSync('.cache/native-task-stop-bridge-canonical/standalone/spatial-savanna.wasm'));
const sorted=m=>WebAssembly.Module.exports(m).map(e=>[e.name,e.kind]).sort((a,b)=>a[0].localeCompare(b[0]));
assert.deepEqual(sorted(nextModule).filter(([n])=>!fresh.includes(n)),sorted(oldModule));assert.deepEqual(WebAssembly.Module.imports(nextModule),WebAssembly.Module.imports(oldModule));
assert.deepEqual(sorted(nextModule).filter(([n])=>fresh.includes(n)),fresh.map(n=>[n,'function']).sort((a,b)=>a[0].localeCompare(b[0])));
const publicNames=[];for(const name of ['public/wild-engine/spatial-threaded.mjs','.cache/native-task-stop-bridge-canonical/pthread/spatial-threaded.mjs']){
 const {default:factory}=await import(pathToFileURL(process.cwd()+'/'+name));const wasmBinary=fs.readFileSync(name.replace(/mjs$/,'wasm'));const rt=await createThreadedSpatialWorld(factory,{wasmBinary});try{
  publicNames.push(Object.keys(rt.runtime).filter(n=>n.startsWith('_')&&typeof rt.runtime[n]==='function').sort());if(name.startsWith('.cache/'))assert.equal(typeof rt.runtime._nav_task_route_stop_proposal_source_matches,'function');
 }finally{await rt.dispose();}
}
assert.deepEqual(publicNames[1].filter(n=>!fresh.map(n=>'_'+n).includes(n)),publicNames[0]);assert.deepEqual(publicNames[1].filter(n=>fresh.map(n=>'_'+n).includes(n)),fresh.map(n=>'_'+n).sort());
const threadedOld=new WebAssembly.Module(fs.readFileSync('public/wild-engine/spatial-threaded.wasm')),threadedNew=new WebAssembly.Module(fs.readFileSync('.cache/native-task-stop-bridge-canonical/pthread/spatial-threaded.wasm'));
assert.equal(WebAssembly.Module.exports(threadedNew).length,WebAssembly.Module.exports(threadedOld).length+1);
console.log(JSON.stringify({standalone:{before:WebAssembly.Module.exports(oldModule).length,after:WebAssembly.Module.exports(nextModule).length,oldNamesAndKindsPreserved:true,importsUnchanged:true},pthread:{before:WebAssembly.Module.exports(threadedOld).length,after:WebAssembly.Module.exports(threadedNew).length,publicBefore:publicNames[0].length,publicAfter:publicNames[1].length,publicNamesPreserved:true,pairedFactoryInstantiated:true},additiveNames:fresh}));
''',encoding='utf-8')
abi=subprocess.run([str(r/'.cache/tooling/node20.exe'),str(abiFile)],capture_output=True,text=True)
record['abi']={'exitCode':abi.returncode,'output':abi.stdout,'error':abi.stderr};save();assert abi.returncode==0,abi.stderr
for group in ['preservedFiles','externalCommittedInputs']:
 for p,h in baseline[group].items():assert sha(p)==h,p
for p in ['src/world/wild-engine/spatial-savanna.wasm','public/wild-engine/spatial-threaded.mjs','public/wild-engine/spatial-threaded.wasm']:assert sha(p)==baseline['nativeInputs'][p],p
mapping={'src/world/wild-engine/spatial-savanna.wasm':folder/'standalone/spatial-savanna.wasm','public/wild-engine/spatial-threaded.mjs':folder/'pthread/spatial-threaded.mjs','public/wild-engine/spatial-threaded.wasm':folder/'pthread/spatial-threaded.wasm'}
for p,source in mapping.items():shutil.copyfile(source,r/p);record['outputs'][p]=sha(p)
record['nativeBuiltInputs']={p:sha(p) for p in baseline['nativeInputs']};record['installed']=True;record['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();save();print(json.dumps({'installed':True,'outputs':record['outputs'],'abi':record['abi']},ensure_ascii=True),flush=True)
