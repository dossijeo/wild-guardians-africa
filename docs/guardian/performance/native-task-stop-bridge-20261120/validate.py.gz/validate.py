from pathlib import Path
import datetime,hashlib,json,os,re,subprocess,time

root=Path.cwd()
read=lambda p:json.loads(Path(p).read_bytes())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
native=read('.cache/native-task-stop-bridge-canonical-build.json');assert native['installed']
base=read('.cache/native-task-stop-bridge-baseline.json')
prior=read('.cache/native-task-stop-home-validation.json')
selector=re.compile(r'(route-stop|stroll.*stop|farm-arrival-stop|native-world-stop|home.*(proposal|source|game|held)|task.*(shift-end|game-execution)|native-world-proposal|terrain-proposal|native-resource-preparation|farm-suspended|held-continuation)')
tests=sorted(set(prior['testFiles'])|{p.as_posix() for p in Path('tests').glob('*.test.js') if selector.search(p.name)})
prior['files']=list(prior['frozenInputs'])
files=sorted(set(tests)|{p for p in prior['files'] if Path(p).is_file()})
frozen={p:sha(p) for p in files}
receipt={'scope':'Typed Task25 bridge and nearby native, stop, Home, renderer and preparation regressions. Production build. No physical GPU.',
 'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'at':now(),
 'nativeBuild':native,'nativeBuiltInputs':native['nativeBuiltInputs'],'preservedFiles':base['preservedFiles'],
 'externalCommittedInputs':base['externalCommittedInputs'],'frozenInputs':frozen,'testFiles':tests,'jobs':{}}
path=Path('.cache/native-task-stop-bridge-validation.json')
def save():path.write_text(json.dumps(receipt,ensure_ascii=True,indent=2)+'\n',encoding='utf-8')
common={'WILD_ENGINE_NATIVE_ROUTE_WASM':str(root/'src/world/wild-engine/spatial-savanna.wasm'),'WILD_ENGINE_SPATIAL_SERVICES_WASM':str(root/'src/world/wild-engine/spatial-savanna.wasm')}
commands=[('tests',['.cache/tooling/node20.exe','--test','--test-concurrency=4',*tests],common),('build',['.cache/tooling/node20.exe','node_modules/vite/bin/vite.js','build'],{**common,'VITE_PRESENTATION_BACKEND':'webgpu-worker','VITE_WEBGPU_REMOTE_DRAW':'true'})]
running={}
for label,argv,env in commands:
 log=Path(f'.cache/native-task-stop-bridge-{label}.log');stream=log.open('wb');process=subprocess.Popen(argv,cwd=root,env={**os.environ,**env},stdout=stream,stderr=subprocess.STDOUT)
 running[label]=(process,stream,time.monotonic())
 receipt['jobs'][label]={'command':argv,'environment':env,'log':log.as_posix(),'pid':process.pid,'startedAt':now()}
save();print(json.dumps({k:v['pid'] for k,v in receipt['jobs'].items()}),flush=True)
while running:
 for label,(process,stream,start) in list(running.items()):
  code=process.poll()
  if code is None:continue
  stream.close();del running[label];job=receipt['jobs'][label]
  job.update(exitCode=code,completionObservedAt=now(),secondsUntilCompletionObserved=time.monotonic()-start,logSha256=sha(job['log']))
  log=Path(job['log']).read_text(encoding='utf-8',errors='replace')
  if label=='tests':
   for key in ['tests','pass','fail','cancelled','skipped']:
    matches=re.findall(r'^# '+key+r' (\d+)\s*$',log,re.M);job[key]=int(matches[-1]) if matches else None
  else:job['vitePhaseText']=re.findall(r'built in ([^\r\n]+)',log)[-1:]
  save();print(json.dumps({k:job.get(k) for k in ['log','exitCode','tests','pass','fail','cancelled','skipped','vitePhaseText']}),flush=True)
 time.sleep(.25)
receipt['changed']={g:[p for p,h in receipt[g].items() if not Path(p).is_file() or sha(p)!=h] for g in ['frozenInputs','nativeBuiltInputs','preservedFiles','externalCommittedInputs']}
receipt['finishedAt']=now();save();assert not any(receipt['changed'].values()),receipt['changed'];assert all(v['exitCode']==0 for v in receipt['jobs'].values())
