from pathlib import Path
import json,hashlib,subprocess,os,time
n='native-retained-handoff'
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
write=lambda p,v:Path(p).write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
own=read('.cache/'+n+'-pending-files.json');old=read('.cache/'+n+'-post-prerequisite-pre-tested-hashes.json');native=read('.cache/'+n+'-pre-built-hashes.json');foreign=read('.cache/'+n+'-pre-preserved-hashes.json')
extra=['tests/webgpu-retained-handoff.test.js','tests/webgpu-retained-worker.test.js','tests/webgpu-world-client.test.js','tests/webgpu-world-client-temporal-profile.test.js','tests/webgpu-surface-handoff.test.js','tests/webgpu-surface-owner.test.js','tests/webgpu-microevent-client.test.js','tests/tutorial-daily-messages.test.js','tests/worker-tutorial-bridge-retry.test.js','tests/visual-recovery-visibility.test.js','tests/webgpu-auto-recovery-qa.test.js','tests/recovery-progress-watchdog.test.js']
focused=list(dict.fromkeys(read('.cache/native-retained-host-focused-files.json')+extra));selected=list(dict.fromkeys(read('.cache/native-retained-host-regression-files.json')+focused))
write('.cache/'+n+'-focused-files.json',focused);write('.cache/'+n+'-regression-files.json',selected)
inputs={p:sha(p) for p in sorted(set(old)|set(own)|set(selected)|set(focused))};write('.cache/'+n+'-tested-hashes.json',inputs)
def verify():
 for m in [inputs,native,foreign]:
  for p,h in m.items():assert sha(p)==h,p
verify();print('Frozen',len(inputs),'inputs;',len(focused),'directed;',len(selected),'selected files;64native/16foreign exact.',flush=True)
syntax=[]
for p in own:
 r=subprocess.run(['.cache/tooling/node20.exe','--check',p],capture_output=True,text=True);syntax.append({'file':p,'sha256':sha(p),'exitCode':r.returncode,'output':r.stdout+r.stderr});assert r.returncode==0
write('.cache/'+n+'-syntax.json',syntax)
env=os.environ.copy();env['WILD_ENGINE_NATIVE_ROUTE_WASM']=str(Path('src/world/wild-engine/spatial-savanna.wasm').resolve());env['WILD_ENGINE_SPATIAL_SERVICES_WASM']=env['WILD_ENGINE_NATIVE_ROUTE_WASM']
rows=[]
for label,command in [('final-focused',['.cache/tooling/node20.exe','--test',*focused]),('final-regression',['.cache/tooling/node20.exe','--test',*selected]),('final-build',['.cache/tooling/node20.exe','node_modules/vite/bin/vite.js','build'])]:
 log='.cache/'+n+'-'+label+'.log';started=time.time()
 with open(log,'w',encoding='utf-8') as out:
  process=subprocess.Popen(command,env=env,stdout=out,stderr=out)
  write('.cache/'+n+'-live-validation.json',{'label':label,'pid':process.pid,'command':command,'log':log,'started':started,'timeoutSeconds':1200})
  try:code=process.wait(timeout=1200)
  except subprocess.TimeoutExpired:
   stop=subprocess.run(['taskkill','/PID',str(process.pid),'/T','/F'],capture_output=True);Path(log+'.termination.stdout.bin').write_bytes(stop.stdout);Path(log+'.termination.stderr.bin').write_bytes(stop.stderr);process.wait(timeout=10);raise
 rows.append({'label':label,'command':command,'exitCode':code,'seconds':time.time()-started,'log':log,'sha256':sha(log)});write('.cache/'+n+'-final-runs.json',rows);print(label,code,round(time.time()-started,2),flush=True);verify()
 if code:raise SystemExit(code)
print('CPU/build complete;all frozen inputs/native64/foreign16 exact. GPU validation follows sequentially.',flush=True)
