from pathlib import Path
import subprocess, os, json, hashlib, time
n = 'native-retained-handoff'
read = lambda p: json.loads(Path(p).read_text(encoding='utf-8-sig'))
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p, value):
    Path(p).write_text(json.dumps(value, indent=2)+'\n', encoding='utf-8')
maps = [read('.cache/'+n+'-'+suffix+'.json') for suffix in ['tested-hashes', 'pre-built-hashes', 'pre-preserved-hashes']]
def verify():
    for mapping in maps:
        for path, digest in mapping.items():
            assert sha(path) == digest, path
runs = read('.cache/'+n+'-final-runs.json')
assert len(runs) == 3 and all(r['exitCode'] == 0 for r in runs), 'CPU/build incomplete'
verify()
env = os.environ.copy()
env.update(PLAYWRIGHT_MODULE=str(Path('.cache/microevent-qa/node_modules/playwright-core').resolve()), QA_BASE_URL='http://127.0.0.1:5218')
cases = [
    ('ordinary', 'tools/experiments/audit_early_native_gpu_view.mjs', {'QA_RETAINED_RECOVERY': 'true'}),
    ('device-loss', 'tools/experiments/audit_early_native_gpu_view.mjs', {'QA_RETAINED_RECOVERY': 'fresh'}),
    ('rebind', 'tools/experiments/audit_webgpu_temporal_ground.mjs', {'QA_NATIVE_RETAINED_RECOVERY': 'rebind'}),
    ('readmission', 'tools/experiments/audit_webgpu_temporal_ground.mjs', {'QA_NATIVE_RETAINED_RECOVERY': 'readmission'}),
    ('semantic-negative', 'tools/experiments/audit_webgpu_temporal_ground.mjs', {'QA_NATIVE_RETAINED_RECOVERY': 'negative'}),
]
rows = []
for label, script, options in cases:
    prefix = '.cache/'+n+'-verified-'+label
    local = env.copy()
    local.update(options, QA_ARTIFACT_PREFIX=prefix, OUTPUT=prefix+'.json')
    started = time.time()
    command = ['.cache/tooling/node20.exe', script]
    verify()
    with open(prefix+'.log', 'w', encoding='utf-8') as out:
        process = subprocess.Popen(command, env=local, stdout=out, stderr=out)
        write('.cache/'+n+'-live-gpu.json', {'label': label, 'pid': process.pid, 'command': command, 'started': started, 'log': prefix+'.log', 'timeoutSeconds': 600})
        # Keep the recorded process available for diagnosis if a deadline fails.
        code = process.wait(timeout=600)
    rows.append({'label': label, 'command': command, 'environment': {'QA_BASE_URL': local['QA_BASE_URL'], **options}, 'exitCode': code, 'seconds': time.time()-started, 'report': prefix+'.json', 'log': prefix+'.log'})
    write('.cache/'+n+'-verified-gpu-runs.json', rows)
    print(label, code, round(time.time()-started, 2), flush=True)
    verify()
    if code:
        raise SystemExit(code)
print('Sequential final GPU audits complete; frozen inputs/native64/foreign16 exact.', flush=True)
