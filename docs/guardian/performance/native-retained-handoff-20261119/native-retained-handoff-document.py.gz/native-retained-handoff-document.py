from pathlib import Path
import json, hashlib, gzip, shutil, re
n = 'native-retained-handoff'
root = Path('docs/guardian/performance/'+n+'-20261119')
read = lambda p: json.loads(Path(p).read_text(encoding='utf-8-sig'))
def sha(p):
    digest = hashlib.sha256()
    with open(p, 'rb') as source:
        for block in iter(lambda: source.read(1048576), b''):
            digest.update(block)
    return digest.hexdigest()
def write(p, value):
    Path(p).write_text(json.dumps(value, indent=2)+'\n', encoding='utf-8')
inputs = read('.cache/'+n+'-tested-hashes.json')
native = read('.cache/'+n+'-pre-built-hashes.json')
foreign = read('.cache/'+n+'-pre-preserved-hashes.json')
for mapping in [inputs, native, foreign]:
    for path, digest in mapping.items():
        assert sha(path) == digest, path
runs = read('.cache/'+n+'-final-runs.json')
gpu = read('.cache/'+n+'-verified-gpu-runs.json')
assert len(runs) == 3 and all(r['exitCode'] == 0 for r in runs)
assert len(gpu) == 5 and all(r['exitCode'] == 0 for r in gpu)
root.mkdir(parents=True, exist_ok=True)
artifacts = []
paths = [p for p in Path('.cache').glob(n+'-*') if p.is_file() and not any(v in p.name for v in ['CURRENT-STATUS', 'MIGRATION-OBJECTIVE', 'A6-CHECKLIST', 'integrated-gpu-migration-plan', '-draft.md', '-evidence-files.json'])]
research = {key: read('.cache/'+n+'-'+key+'.json') for key in ['research', 'frame-drain-research', 'close-research']}
def sources(value):
    if isinstance(value, dict):
        for key, item in value.items():
            if key in ['snapshot', 'source'] and isinstance(item, str) and item.startswith('.cache/') and Path(item).is_file():
                paths.append(Path(item))
            else:
                sources(item)
    elif isinstance(value, list):
        for item in value:
            sources(item)
sources(research)
for path in sorted(set(paths)):
    target = root/(path.name if path.suffix == '.png' else path.name+'.gz')
    original_sha = sha(path)
    if path.suffix == '.png':
        shutil.copyfile(path, target)
    else:
        with path.open('rb') as source, target.open('wb') as dest:
            with gzip.GzipFile(filename='', mode='wb', fileobj=dest, mtime=0) as archive:
                shutil.copyfileobj(source, archive, length=1048576)
    artifacts.append({'source': path.as_posix(), 'bytes': path.stat().st_size, 'sha256': original_sha, 'artifact': target.as_posix(), 'artifactSha256': sha(target)})
    if path.stat().st_size > 100000000:
        print('Archived full large failed log', path.name, target.stat().st_size, flush=True)
def tap(path):
    text = Path(path).read_text(encoding='utf-8', errors='replace')
    return {key: int(re.findall(r'^# '+key+r' (\d+)\s*$', text, re.M)[-1]) for key in ['tests', 'pass', 'fail', 'cancelled', 'skipped']}
for row in runs:
    row['sha256'] = sha(row['log'])
    if row['label'] != 'final-build':
        row['tap'] = tap(row['log'])
for row in gpu:
    report = read(row['report'])
    if row['label'] in ['ordinary', 'device-loss']:
        assert report.get('ok') is True
        row['summary'] = {'scope': report['scope'], 'adapter': report['before']['renderer']['device'], 'recoveries': [{'result': r['result'], 'delta': r.get('delta'), 'beforeSequence': r['prior']['renderer']['state']['sequence'], 'afterSequence': r['after']['renderer']['state']['sequence']} for r in report['recoveries']], 'drains': report['disposal']['disposals'], 'expectedDeviceLossErrors': report.get('expectedDeviceLossErrors',[]), 'errors': report['errors'], 'httpFailures': report['httpFailures'], 'requestErrors': report['requestErrors']}
    else:
        assert report['result']['ok'] and report['disposal']['nativeRetainedRecoveryDisposed']
        result = report['result']
        row['summary'] = {key: result.get(key) for key in ['mode', 'created', 'retainedChunks', 'retainedNodes', 'retainedImmutableNativeGenerations', 'transportRebind', 'unchangedCheckpoint', 'readmission']}
        row['summary'].update(visual=report['visual'], disposal=report['disposal'], consoleErrors=report['consoleErrors'], httpFailures=report['httpFailures'], requestErrors=report['requestErrors'])
receipt = {'version': 1, 'date': '2026-11-19', 'baseCommit': '76f23f3061c6f136534edfce44b2a69731237248', 'scope': 'A4/e-R3/f-R4;retain existing ordinary Worker/client/UI owner after validated rebind. Full migration/A6/A/B/C open,D not started.', 'changedFiles': read('.cache/'+n+'-pending-files.json'), 'testedInputs': inputs, 'nativeBuiltInputs': native, 'preservedFiles': foreign, 'nativeChangedFiles': [], 'newTests': {'cases': 19, 'originalPass': 1, 'originalFail': 18, 'currentPass': 19, 'inflightRaceBeforeDrain': {'pass': 0, 'fail': 1, 'skipped': 8}}, 'baselineControls': read('.cache/'+n+'-baseline-controls.json'), 'syntax': read('.cache/'+n+'-syntax.json'), 'cpuAndBuild': runs, 'focusedFiles': read('.cache/'+n+'-focused-files.json'), 'selectedRegressionFiles': read('.cache/'+n+'-regression-files.json'), 'separatePreexistingFailures': {'inheritedOnly': True, 'reference': 'docs/guardian/performance/native-retained-host-validation-20261119.json', 'cases': ['confirmed-presentation-timeline:19/20 handshake timeout', 'worker-runtime-host-timeline:25s nontermination', 'worker-runtime-host-historical-recovery:3pass/2fail releaseCommand'], 'note': 'Excluded from green selection as before;original/current raw controls in referenced prior receipt,not rerun or claimed fixed by this increment.'}, 'research': research, 'qaOnlyFollowup': read('.cache/'+n+'-qa-followup.json'), 'gpu': gpu, 'artifacts': artifacts, 'limits': ['Ordinary UI fixture:paused sabana,time0,two physical chunks,173 far sectors;nativeWorldBoundary null,no locomotion/native-world-mutation/cadence claim.', 'WorldWorker device identity is its remote device proxy;real GPU consumer counters and successful drain checked separately.', 'Component cases:real C++ authority and native mutation/cohort/direct control,desierto,time10,one quiet worker;live full/delta publications are protocol fixtures.', 'Only changed-resource deltas on same stable scene are comparable;startup totals266xx and prior1893/3123 are different fixtures.', 'All failed exploratory reports/logs retained;pilot5 stopped on actual fatal authority error with raw termination receipt,not a successful completion.', 'No WASM rebuild,new dependency,owner,journal,cache or native permission.']}
receipt_path = Path('docs/guardian/performance/'+n+'-validation-20261119.json')
write(receipt_path, receipt)
focused = runs[0]['tap']; selected = runs[1]['tap']; build = runs[2]
validation = f"""Se ejecutan 19 casos nuevos: fuentes anteriores **1 pase/18 fallos**, actuales **19/19** dentro de la selección dirigida. La carrera específica del frame pendiente falla contra el Worker anterior a la espera (**1 fallo/8 omisiones**). Pasan **{focused['pass']} dirigidas/51 archivos**, **{selected['pass']} de {selected['tests']} seleccionadas/337 archivos**, {selected['skipped']} omisión opcional, cero fallos/cancelaciones en esas selecciones; nueve sintaxis y build de producción, proceso completo, **{build['seconds']:.2f}s**. Se verifican **571 inputs, 64 nativos intactos y 16 ajenos exactos**, sin recompilar WASM.

Después de ese build solo cambió el harness QA: espera el intervalo sin propietario durante device loss y clasifica únicamente el mensaje exacto de destrucción provocado por la prueba. Se repiten las 737 dirigidas, se valida la sintaxis QA final y se repiten los cinco casos GPU secuenciales. El guard de espera conserva el plazo global. El recibo distingue ambos hashes de QA; las fuentes de producción, tests y build son idénticas.

Los controles separados conocidos del host/timeline siguen pendientes: timeline19/20 por handshake, host que no termina en25s e histórico3pases/2fallos por `releaseCommand`. Sus reproducciones antes/actual pertenecen al recibo de `6445f17ae`; no se han repetido ni se atribuye su reparación a este incremento. No se proclama suite universal.

Después de CPU/build se ejecutan secuencialmente cinco casos NVIDIA: partida con dos reconexiones y pausa/reanudación real entre ambas, pérdida real del dispositivo con propietario fresco, componente retenido con mutación C++ y rebind, readmisión de material y rechazo semántico. Cada caso exige finalización GPU real y conserva fuentes servidas y capturas. En cada reconexión de la escena estable: **0 recursos creados, 0 forks de uniformes, 0 forks de bindings y 0 compilaciones**; mismo binding/canvas/Worker/Surface/grafo, publicaciones completas/delta por el transporte nuevo y frame nuevo realmente completado. La pérdida real sí sustituye el propietario inutilizable. Los resultados de componente y sus límites están desglosados en el [recibo de validación](performance/{n}-validation-20261119.json).
"""
draft = Path('.cache/'+n+'-draft.md').read_text(encoding='utf-8')
assert draft.count('VALIDATION_PENDING') == 1
doc = Path('docs/guardian/'+n+'-20261119.md')
doc.write_text(draft.replace('VALIDATION_PENDING', validation), encoding='utf-8')
intro = f"\n\nContinuación A4/e-R3/f-R4: [recuperación retenida desde Worker y partida]({n}-20261119.md). Reutiliza binding/canvas/WorldWorker/Surface/recursos; espera el frame existente antes de validar salud y exige ACK y frame de la nueva generación. Reconecta tres transportes; evita doble inicio de hierba y reentrada de vegetación durante cierre. Investigación Redis/Babylon/Three en código, sin dependencia/dueño nuevos.19casos,baseline1pase/18fallos;{focused['pass']}dirigidas/51,{selected['pass']}/{selected['tests']}seleccionadas/337/{selected['skipped']}omisión,9sintaxis/build{build['seconds']:.2f}s;571inputs/64nativos intactos/16ajenos exactos. CincoGPU finales NVIDIA secuenciales:dos recuperaciones UI con0creaciones/0forks/0compilaciones,full/delta y drain real;device loss fresco y componente C++/rebind/readmisión/negativo separados. Partida pausada sabana/tiempo0/sin mutación nativa;componentes no son aceptación de locomoción/cadencia. Tres fallos previos del host/timeline heredados y abiertos;raws conservados. Siguiente productor/cohort/paradas/relevos/cadencia/plataforma;A6/A/B/C abiertos,D no iniciado,f-R3 seguridad conserva cierre.\n"
primary = ['CURRENT-STATUS.md', 'MIGRATION-OBJECTIVE.md', 'A6-CHECKLIST.md', 'integrated-gpu-migration-plan-20261104.md']
for name in primary:
    path = Path('docs/guardian')/name
    original = Path('.cache/'+n+'-'+name+'.post-prerequisite.before').read_bytes()
    assert path.read_bytes() == original, name+' changed since prerequisite'
    split = original.find(b'\n')+1
    path.write_bytes(original[:split]+intro.encode()+original[split:])
    assert path.read_bytes()[split+len(intro.encode()):] == original[split:]
owned = read('.cache/'+n+'-pending-files.json')+[str(doc).replace('\\','/'), str(receipt_path).replace('\\','/')]+['docs/guardian/'+name for name in primary]+[p.as_posix() for p in root.iterdir()]
write('.cache/'+n+'-publish-files.json', owned)
print('Documented', len(artifacts), 'raw artifacts;', len(owned), 'owned publication paths.', flush=True)
