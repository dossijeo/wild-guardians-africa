from pathlib import Path
import json, hashlib, gzip, re
n='native-production-quiescence'
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,value):
    Path(p).write_bytes((json.dumps(value,indent=2)+'\n').encode('utf-8'))
runs=read('.cache/'+n+'-final-runs.json')
assert len(runs)==3 and all(r['exitCode']==0 for r in runs)
inputs=read('.cache/'+n+'-tested-hashes.json');native=read('.cache/'+n+'-pre-built-hashes.json');foreign=read('.cache/'+n+'-pre-preserved-hashes.json')
for mapping in [inputs,native,foreign]:
    for p,digest in mapping.items():
        assert sha(p)==digest,p
def tap(path):
    s=Path(path).read_text(encoding='utf-8',errors='replace')
    return {k:int(re.findall(r'^# '+k+r' (\d+)\s*$',s,re.M)[-1]) for k in ['tests','pass','fail','cancelled','skipped']}
for run in runs:
    if run['label']!='final-build':run['tap']=tap(run['log'])
baseline=tap('.cache/'+n+'-published-test-baseline.log');assert baseline['fail']==9 and baseline['pass']==0
root=Path('docs/guardian/performance/'+n+'-20261119');root.mkdir(parents=True,exist_ok=True)
artifacts=[]
for source in sorted(Path('.cache').glob(n+'-*')):
    if not source.is_file() or '-draft.md' in source.name or any(v in source.name for v in ['CURRENT-STATUS','MIGRATION-OBJECTIVE','A6-CHECKLIST','integrated-gpu-migration-plan']):continue
    target=root/(source.name+'.gz');body=source.read_bytes();target.write_bytes(gzip.compress(body,mtime=0));assert gzip.decompress(target.read_bytes())==body
    artifacts.append({'source':source.as_posix(),'sha256':sha(source),'artifact':target.as_posix(),'artifactSha256':sha(target)})
receipt={'version':1,'date':'2026-11-19','baseCommit':'4c646d3c9e63d3c1d270c84504b834d5206604be','scope':'A4/e-R3/f-R4 prerequisite:quiesce existing native producer and resume only with its exact locally held receipt. No Worker transport/main resource bootstrap yet;full migration/A6/A/B/C open,D not started.','changedFiles':read('.cache/'+n+'-owned-files.json'),'testedInputs':inputs,'nativeBuiltInputs':native,'preservedFiles':foreign,'nativeChangedFiles':[],'newTests':{'cases':9,'original':baseline,'current':tap('.cache/'+n+'-boundary-final.log')},'syntax':read('.cache/'+n+'-syntax.json'),'cpuAndBuild':runs,'focusedFiles':read('.cache/'+n+'-focused-files.json'),'selectedRegressionFiles':read('.cache/'+n+'-regression-files.json'),'research':read('.cache/'+n+'-research.json'),'separatePreexistingFailures':{'inheritedOnly':True,'reference':'docs/guardian/performance/native-retained-host-validation-20261119.json','cases':['confirmed-presentation-timeline19/20 handshake timeout','worker-runtime-host-timeline25s nontermination','worker-runtime-host-historical-recovery3pass2fail releaseCommand'],'note':'Same explicit exclusions as prior selection;not rerun or claimed repaired by these two authority/producer API changes.'},'gpu':{'newHardwareRuns':0,'scope':'Actual WASM authority/planner/native commit and real MessageChannel;remote Host/queue deterministic adapters. Prior4c646d3c9 hardware cases are inherited only,not quiescence acceptance.'},'artifacts':artifacts,'artifactRoundTripsVerified':len(artifacts),'notes':['Native producer and source mutation permission owners are unchanged;only one existing active promise is drained. No new dependency,queue,clock,renderer or physical permission.','Receipt is an immutable local identity;copies and old receipts rejected. Future Worker protocol must keep the actual receipt in authority and use existing RPC identity for replies/resume.','Quiescing still observes real command invalidation;only future preparation dispatch is held. Host clock/command freeze remains separate.','Producer settlement is not an ACK that the GPU endpoint processed its last commit message;retain existing endpoint preflight and implement the transport barrier before ordinary resource wiring.','Preparation failure and disposal are terminal;this API never clears a native producer/cohort failure.','Failed intermediate test assertions and exact first/final source snapshots retained;no native/protocol guard or fixture rule changed.']}
rp=Path('docs/guardian/performance/'+n+'-validation-20261119.json');write(rp,receipt)
focused=runs[0]['tap'];selected=runs[1]['tap'];build=runs[2]['seconds']
validation=f"""Nueve pruebas nuevas: **0 pases/9 fallos** contra ambos módulos anteriores, cargados desde sus URLs originales; **9/9** con el código actual. La selección final pasa **{focused['pass']} dirigidas/59 archivos** y **{selected['pass']} de {selected['tests']} seleccionadas/338 archivos**, {selected['skipped']} omisión opcional, cero fallos/cancelaciones en esas selecciones; tres sintaxis y build de producción completo **{build:.2f}s**. **608 inputs, 64 nativos intactos y 16 ajenos exactos**; no se reconstruye WASM.

Los tres controles preexistentes separados del host/timeline siguen abiertos:19/20 por handshake, no terminación en25s y3pases/2fallos por `releaseCommand`. Sus reproducciones antes/actual y exclusiones proceden del recibo de `6445f17ae`; este incremento no se atribuye su cierre ni otra ejecución de esos controles. No se proclama suite universal.

Fuentes inspeccionadas, baselines, logs completos, selección, sintaxis y hashes: [recibo de validación](performance/{n}-validation-20261119.json).
"""
doc=Path('docs/guardian/'+n+'-20261119.md');draft=Path('.cache/'+n+'-draft.md').read_text(encoding='utf-8');assert draft.count('VALIDATION_PENDING')==1;doc.write_bytes(draft.replace('VALIDATION_PENDING',validation).encode('utf-8'))
note=f"\n\nContinuación A4/e-R3/f-R4: [frontera estable del productor nativo]({n}-20261119.md). El productor existente bloquea nuevos despachos y espera su operación real antes de devolver un recibo local inmutable; solo ese recibo resuelto puede reanudarlo. Comandos siguen invalidando fuentes obsoletas; fallos/disposición y cohortes no soportadas siguen protegidos. Código PhysX inspeccionado y patrón adaptado, sin dependencia, reloj, cola ni propietario nuevos. Nueve casos nuevos: baseline0/9→9/9; {focused['pass']} dirigidas/59 y {selected['pass']} de {selected['tests']} seleccionadas/338, una omisión; tres sintaxis/build completo {build:.2f}s. 608 inputs, 64 nativos y 16 ajenos intactos. Autoridad C++ y puertos reales con cola GPU de prueba; sin GPU hardware nueva ni aceptación de partida/cadencia. Faltan transporte de esa suspensión, checkpoint coherente y conexión ordinaria de recursos, incluido ACK gráfico final; los tres fallos previos del host/timeline permanecen abiertos. A6/A/B/C abiertos, D no iniciado y f-R3 conserva su cierre de seguridad.\n"
primary=['CURRENT-STATUS.md','MIGRATION-OBJECTIVE.md','A6-CHECKLIST.md','integrated-gpu-migration-plan-20261104.md']
primary_before=[]
for name in primary:
    path=Path('docs/guardian')/name;before=Path('.cache/'+n+'-'+name+'.before').read_bytes();assert path.read_bytes()==before
    split=before.find(b'\n')+1;path.write_bytes(before[:split]+note.encode('utf-8')+before[split:]);assert path.read_bytes().endswith(before[split:]);primary_before.append({'file':path.as_posix(),'sha256':hashlib.sha256(before).hexdigest(),'originalSuffixRetained':True})
receipt['primaryBefore']=primary_before;write(rp,receipt)
files=receipt['changedFiles']+[doc.as_posix(),rp.as_posix()]+['docs/guardian/'+name for name in primary]+[p.as_posix() for p in root.iterdir()]
write('.cache/'+n+'-publish-files.json',files)
print('Documented',len(artifacts),'raw artifacts and',len(files),'owned publication paths.',flush=True)
