from pathlib import Path
import subprocess, os, json, hashlib, time
n='native-production-quiescence'
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,value):
    Path(p).write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
own=read('.cache/'+n+'-owned-files.json')
extra=['tests/native-production-quiescence.test.js','tests/native-intent-production-authority.test.js','tests/native-intent-control-publication.test.js','tests/native-intent-control-cohort.test.js','tests/native-intent-control-authority.test.js','tests/native-resource-preparation-channel.test.js','tests/simulation-authority-client.test.js','tests/simulation-authority-chunks.test.js']
focused=list(dict.fromkeys(read('.cache/native-retained-handoff-focused-files.json')+extra))
selected=list(dict.fromkeys(read('.cache/native-retained-handoff-regression-files.json')+focused))
old=read('.cache/native-retained-handoff-tested-hashes.json')
helpers=[p.as_posix() for p in Path('tests/helpers').rglob('*.js')]
inputs={p:sha(p) for p in sorted(set(old)|set(own)|set(selected)|set(focused)|set(helpers))}
native=read('.cache/'+n+'-pre-built-hashes.json');foreign=read('.cache/'+n+'-pre-preserved-hashes.json')
write('.cache/'+n+'-focused-files.json',focused);write('.cache/'+n+'-regression-files.json',selected);write('.cache/'+n+'-tested-hashes.json',inputs)
def verify():
    for mapping in [inputs,native,foreign]:
        for p,digest in mapping.items():
            assert sha(p)==digest,p
verify();print('Frozen',len(inputs),'inputs;',len(focused),'directed;',len(selected),'selected;64native/16foreign exact.',flush=True)
syntax=[]
for p in own:
    result=subprocess.run(['.cache/tooling/node20.exe','--check',p],capture_output=True,text=True)
    syntax.append({'file':p,'sha256':sha(p),'exitCode':result.returncode,'output':result.stdout+result.stderr})
    assert result.returncode==0
write('.cache/'+n+'-syntax.json',syntax)
env=os.environ.copy();env['WILD_ENGINE_NATIVE_ROUTE_WASM']=str(Path('src/world/wild-engine/spatial-savanna.wasm').resolve());env['WILD_ENGINE_SPATIAL_SERVICES_WASM']=env['WILD_ENGINE_NATIVE_ROUTE_WASM']
rows=[]
for label,command in [('final-focused',['.cache/tooling/node20.exe','--test',*focused]),('final-regression',['.cache/tooling/node20.exe','--test',*selected]),('final-build',['.cache/tooling/node20.exe','node_modules/vite/bin/vite.js','build'])]:
    log='.cache/'+n+'-'+label+'.log';started=time.time()
    with open(log,'w',encoding='utf-8') as output:
        process=subprocess.Popen(command,env=env,stdout=output,stderr=output)
        write('.cache/'+n+'-live-validation.json',{'label':label,'pid':process.pid,'command':command,'log':log,'started':started,'timeoutSeconds':1200})
        # A timeout leaves its recorded handle available for diagnosis/adoption.
        code=process.wait(timeout=1200)
    rows.append({'label':label,'command':command,'exitCode':code,'seconds':time.time()-started,'log':log,'sha256':sha(log)})
    write('.cache/'+n+'-final-runs.json',rows);print(label,code,round(time.time()-started,2),flush=True);verify()
    if code:
        raise SystemExit(code)
print('CPU/build complete. Native authority/MessageChannel/Host adapters;no new hardware GPU or ordinary app wiring claim.',flush=True)
