import {nativeProductionAuthority,untilProduction} from './native-checkpoint-paused-probe-helper.mjs';
import {nativeIdleStrollGameSave} from '../tests/helpers/native-idle-stroll-restoration-game.js';
const saved=nativeIdleStrollGameSave();saved.state.pauses=['manual'];
let release;const gate=new Promise(resolve=>{release=resolve;});
const f=await nativeProductionAuthority(saved.state,{attach:false,onReady:()=>gate});
try{
 let resident=f.command({kind:'pause',reason:'manual'});for(const key of resident.residency.missing)resident=f.command({kind:'addChunk',key});const before=f.command({kind:'snapshot'});
 await f.attach();await untilProduction(f,()=>f.records.length===1);
 const active=f.command({kind:'snapshot'}),status=f.authority.nativeIntentProductionStatus();
 const waiting=f.authority.quiesceNativeIntentProduction();waiting.catch(()=>{});release();await untilProduction(f,()=>f.records[0].committed);await waiting;await f.authority.flushNativeResourcePreparation();
 const after=f.command({kind:'snapshot'});
 console.log(JSON.stringify({scope:'Read-only reproduction of next checkpoint prerequisite,actual native authority/ports,compactPausedAcks:true test adapter,not host runtime or hardware GPU.',before:{sequence:before.sequence,elapsed:before.elapsed,certificate:before.pausedQuiescent,pauses:before.pauses,residency:before.residency,marker:JSON.parse(before.snapshot).workers[0].nativeRouteAdmission},active:{sequence:active.sequence,elapsed:active.elapsed,certificate:active.pausedQuiescent,pauses:active.pauses,residency:active.residency,producer:status,marker:JSON.parse(active.snapshot).workers[0].nativeRouteAdmission},afterActualCommitAndBarrier:{sequence:after.sequence,elapsed:after.elapsed,certificate:after.pausedQuiescent,marker:JSON.parse(after.snapshot).workers[0].nativeRouteAdmission},faults:f.faults},null,2));
}finally{release();await f.close();}
