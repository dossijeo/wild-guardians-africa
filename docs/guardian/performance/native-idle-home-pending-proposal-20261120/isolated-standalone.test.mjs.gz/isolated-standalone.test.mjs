import test from 'node:test';import assert from 'node:assert/strict';
import {nativeSettledIdleFixture} from '../tests/helpers/native-settled-idle.js';
import {tick} from '../src/simulation/game.js';
function acquired(){const f=nativeSettledIdleFixture();try{const p=f.planner.prepareNativeIdleCycleProposal(f.actor);assert.equal(p.status,'proposed');f.commitIdle(p.proposal);return f;}catch(e){f.close();throw e;}}
function foreignProposal(f){assert.equal(f.w.spatial_barrier_proposal_stage(f.worker.x+25,f.worker.z+25,.1,.1,0,0),1);return f.tuple();}
test('the restoration fixture compiled the selected kernel bytes',()=>{assert(process.env.NATIVE_HOME_PROBE_WASM_SHA);assert.equal(globalThis.__nativeHomeProbeActualKernelSha,process.env.NATIVE_HOME_PROBE_WASM_SHA);});
for(const ordinary of [false,true])test(`actual21 expired Home ${ordinary?'ordinary tick':'direct request'} declares Home immediately and retains the foreign proposal`,()=>{
 const f=acquired();try{
  const ticket=foreignProposal(f),source=f.planner.nativeIdleCycleBinding(f.actor),own=f.body(1),peer=f.body(3),at=f.state.elapsed;f.worker.contractDay--;
  if(ordinary){assert.doesNotThrow(()=>tick(f.state,.1,f.nav));assert(f.state.elapsed>at);assert.notDeepEqual(f.body(3),peer);}else assert(f.planner.requestNativeIdleHome(f.state,f.worker));
  const home=f.planner.nativeHomeRequestReference(f.actor);assert(home);assert.equal(home.bodyId,source.reference.bodyId);assert.equal(home.requestedAt,at);assert.equal(f.worker.status,'returning');assert.equal(f.worker.nativeRouteAdmission,'pending-home-resources');assert.equal(f.worker.idleState,null);assert.deepEqual(f.body(1),own);assert.deepEqual(f.tuple(),ticket);
  assert.equal(f.w.nav_intent_barrier_proposal_cancel(...ticket.slice(0,2)),1);assert.deepEqual(f.planner.nativeHomeRequestReference(f.actor),home);assert.deepEqual(f.body(1),own);
 }finally{f.close();}
});
test('Home supersedes a same-actor Idle successor without acquiring the stale program',()=>{
 const f=acquired();try{
  const source=f.planner.nativeIdleCycleBinding(f.actor);f.advance(source.reference.worldBoundary.effectiveTime+source.reference.duration-f.state.elapsed+.01);
  const next=f.planner.nativeIdleCycleNextRequest(f.actor),rest=next.idleState.mode==='rest',p=rest?f.planner.prepareNativeIdleCycleProposal(f.actor):f.planner.prepareNativeIdleStrollProposal(f.actor);assert.equal(p.status,'proposed');const ticket=f.tuple(),own=f.body(1),peer=f.body(3);f.worker.contractDay--;
  const home=f.planner.requestNativeIdleHome(f.state,f.worker);assert(home);assert.equal(home.bodyId,1);assert.deepEqual(f.tuple(),ticket);assert.deepEqual(f.body(1),own);assert.deepEqual(f.body(3),peer);assert.equal(f.worker.nativeRouteAdmission,'pending-home-resources');
  const commit=rest?f.w.nav_idle_cycle_proposal_commit_bound:f.w.nav_idle_stroll_proposal_commit_bound;assert.notEqual(commit(...ticket.slice(0,5),p.proposal.ticket.ticket),1);assert.deepEqual(f.planner.nativeHomeRequestReference(f.actor),home);assert.deepEqual(f.body(1),own);
 }finally{f.close();}
});
for(const inside of [true,false])test(`actual17 Home still supersedes its prepared ${inside?21:22} with the same body`,()=>{
 const f=nativeSettledIdleFixture({inside});try{
  const p=inside?f.planner.prepareNativeIdleCycleProposal(f.actor):f.planner.prepareNativeIdleStrollProposal(f.actor);assert.equal(p.status,'proposed');const own=f.body(1),peer=f.body(3);f.worker.contractDay--;
  const home=f.planner.requestNativeIdleHome(f.state,f.worker);assert(home);assert.equal(home.bodyId,1);assert.equal(f.worker.status,'returning');assert.equal(f.worker.nativeRouteAdmission,'pending-home-resources');assert.deepEqual(f.body(1),own);assert.deepEqual(f.body(3),peer);
  assert.equal((inside?f.planner.revalidateNativeIdleCycleProposal(p.proposal.ticket):f.planner.revalidateNativeIdleStrollProposal(p.proposal.ticket)).status,'stale');
 }finally{f.close();}
});
test('a removed physical source cannot declare Home through a pending world proposal',()=>{
 const f=acquired();try{
  const ticket=foreignProposal(f);f.worker.contractDay--;assert.equal(f.w.spatial_body_remove(1),1);const worker=structuredClone(f.worker);
  assert.throws(()=>f.planner.requestNativeIdleHome(f.state,f.worker));assert.deepEqual(f.worker,worker);assert.equal(f.planner.nativeHomeRequestReference(f.actor),null);assert.deepEqual(f.tuple(),ticket);
 }finally{f.close();}
});
