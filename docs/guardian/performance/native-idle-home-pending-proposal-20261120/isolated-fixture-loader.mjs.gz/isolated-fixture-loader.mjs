import fs from 'node:fs';import {pathToFileURL}from'node:url';
const record=JSON.parse(fs.readFileSync(new URL('./native-current-idle-home-preemption-build.json',import.meta.url)));
const sources=Object.fromEntries(Object.entries(record.decoderSnapshots).map(([p,v])=>[new URL('../'+p,import.meta.url).href,v.path]));
const fixture=new URL('../tests/helpers/native-task-action-restoration.js',import.meta.url).href;
export async function load(url,context,nextLoad){
 if(sources[url])return {format:'module',shortCircuit:true,source:fs.readFileSync(sources[url],'utf8')};
 if(url===fixture){
  const source=fs.readFileSync(new URL(url),'utf8'),anchor="const module=new WebAssembly.Module(readFileSync(new URL('../../src/world/wild-engine/spatial-savanna.wasm',import.meta.url)));";
  if(source.split(anchor).length!==2||!process.env.NATIVE_HOME_PROBE_WASM)throw Error('Native Home fixture module seam changed');
  const wasm=JSON.stringify(pathToFileURL(process.env.NATIVE_HOME_PROBE_WASM).href);
  return {format:'module',shortCircuit:true,source:"import {createHash as nativeHomeProbeHash} from 'node:crypto';\n"+source.replace(anchor,`const nativeHomeProbeBytes=readFileSync(new URL(${wasm}));\nconst module=new WebAssembly.Module(nativeHomeProbeBytes);\nglobalThis.__nativeHomeProbeActualKernelSha=nativeHomeProbeHash('sha256').update(nativeHomeProbeBytes).digest('hex');`)};
 }
 return nextLoad(url,context);
}
