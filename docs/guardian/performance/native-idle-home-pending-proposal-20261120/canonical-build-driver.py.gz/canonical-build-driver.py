from pathlib import Path
import sys,subprocess,hashlib,json,re,os,time,shutil
r=Path.cwd();read=lambda p:json.loads(Path(p).read_bytes());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
candidate=read('.cache/native-current-idle-home-preemption-candidate.json');assert sha(candidate['baseSource'])==candidate['candidateSha256'],'Promote reviewed native header before canonical build'
prior=read('docs/guardian/performance/native-post-settlement-idle-source-20261120-validation.json');published=read('docs/guardian/performance/native-preparation-packet-slices-20261120-validation.json');source=str(Path(candidate['baseSource'])).replace('\\','/')
for p,h in published['nativeBuiltInputs'].items():assert sha(p)==(candidate['candidateSha256']if p==source else h),p
folder=r/'.cache/native-idle-home-pending-canonical';folder.mkdir(exist_ok=True);script=r/'tools/build-spatial-savanna-wasm.sh';assert sha(script)==prior['nativeBuild']['nativeSourceInputs']['tools/build-spatial-savanna-wasm.sh'];match=re.search(r"EXPORTED_FUNCTIONS=(\[.*?\])'",script.read_text(),re.S);assert match
exports=json.loads(match.group(1));exportfile=folder/'exports.json';exportfile.write_text(json.dumps(exports)+'\n')
record={'scope':'Canonical native sources and flags from tools/build-spatial-savanna-wasm.sh; compile both variants to private output then atomically install only after successful ABI/source checks. No cache include shadows or DTO snapshots.','canonicalScript':{'path':str(script),'sha256':sha(script)},'exports':{'count':len(exports),'path':str(exportfile),'sha256':sha(exportfile)},'commands':[],'before':published['nativeBuiltInputs'],'sourceInputs':{p:sha(p)for p in published['nativeBuiltInputs']if not p.endswith(('.wasm','.mjs'))},'outputs':{}}
recordfile=r/'.cache/native-idle-home-pending-canonical-build.json';save=lambda:recordfile.write_text(json.dumps(record,indent=2)+'\n')
environment={'EM_CONFIG':str(r/'.cache/emsdk/.emscripten'),'EMSDK':str(r/'.cache/emsdk'),'EMSDK_PYTHON':sys.executable};record['environment']=environment
for original in prior['nativeBuild']['commands']:
 label=original['label'];outdir=folder/label;outdir.mkdir(exist_ok=True);out=outdir/('spatial-savanna.wasm'if label=='standalone'else'spatial-threaded.mjs');args=[('EXPORTED_FUNCTIONS=@'+str(exportfile))if a.startswith('EXPORTED_FUNCTIONS=@')else a for a in original['command'][1:]];args[args.index('-o')+1]=str(out)
 command=[sys.executable,'-E',str(r/'.cache/emsdk/upstream/emscripten/em++.py'),*args];log=folder/(label+'.log');entry={'label':label,'command':command,'log':str(log)};record['commands'].append(entry);save();started=time.time();print(label+' canonical compile starts',flush=True)
 with log.open('wb')as stream:completed=subprocess.run(command,env={**os.environ,**environment},stdout=stream,stderr=subprocess.STDOUT)
 entry.update({'exitCode':completed.returncode,'seconds':time.time()-started,'sha256':sha(log)});save();assert completed.returncode==0,label
for p,h in record['sourceInputs'].items():assert sha(p)==h,p
mapping={'src/world/wild-engine/spatial-savanna.wasm':folder/'standalone/spatial-savanna.wasm','public/wild-engine/spatial-threaded.mjs':folder/'pthread/spatial-threaded.mjs','public/wild-engine/spatial-threaded.wasm':folder/'pthread/spatial-threaded.wasm'}
abi_script=folder/'abi.mjs';abi_script.write_text("import fs from 'node:fs';import assert from 'node:assert/strict';const pairs="+json.dumps([[str(r/p),str(q)]for p,q in mapping.items()if p.endswith('.wasm')])+";for(const[a,b]of pairs){const x=new WebAssembly.Module(fs.readFileSync(a)),y=new WebAssembly.Module(fs.readFileSync(b));for(const method of ['exports','imports'])assert.deepEqual(WebAssembly.Module[method](y),WebAssembly.Module[method](x));console.log(b,WebAssembly.Module.exports(y).length,'exports identical');}\n")
result=subprocess.run([str(r/'.cache/tooling/node20.exe'),str(abi_script)],capture_output=True,text=True);record['abi']={'exitCode':result.returncode,'output':result.stdout,'error':result.stderr};save();assert result.returncode==0,result.stderr
for p,h in published['preservedFiles'].items():assert sha(p)==h,p
for p,h in published['externalCommittedInputs'].items():assert sha(p)==h,p
for dest,output in mapping.items():shutil.copyfile(output,r/dest);record['outputs'][dest]=sha(dest)
record['pthreadWorkerUnchanged']=sha('public/wild-engine/spatial-threaded.worker.mjs')==published['preservedFiles']['public/wild-engine/spatial-threaded.worker.mjs'];assert record['pthreadWorkerUnchanged'];record['installed']=True;save();print(json.dumps({'installed':True,'outputs':record['outputs'],'abi':record['abi']}),flush=True)
