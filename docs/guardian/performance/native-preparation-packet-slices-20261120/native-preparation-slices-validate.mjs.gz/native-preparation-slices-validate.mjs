import fs from 'node:fs';import {createHash} from 'node:crypto';import {spawn,execFileSync} from 'node:child_process';import assert from 'node:assert/strict';
const read=p=>JSON.parse(fs.readFileSync(p)),hash=p=>createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const prior=read('.cache/native-settled-idle-consumer-validation.json'),frozen=read('.cache/native-preparation-budget-reference-static-frozen.json');assert.equal(frozen.inputsUnchanged,true);assert.equal(frozen.run.exitCode,0);
const owned=['src/rendering/remote-webgpu-host.js','tools/guardian/native-audit-preparation-costs.mjs','tests/remote-preparation-slices.test.js'];
for(const [p,h]of Object.entries(frozen.files))if(!owned.includes(p))assert.equal(hash(p),h,p);
const result={baseCommit:execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),scope:'Fresh previous selected suite plus packet-slice regressions; historical exclusions and one optional skip remain. CPU validation/build concurrent, no hardware run overlaps.',owned,files:Object.fromEntries(owned.map(p=>[p,hash(p)]))};
for(const key of ['testedInputs','runtimeSources','nativeBuiltInputs','preservedFiles','externalCommittedInputs'])result[key]=Object.fromEntries(Object.keys(prior[key]).map(p=>[p,hash(p)]));
result.testedInputs[owned[2]]=hash(owned[2]);
for(const key of ['nativeBuiltInputs','preservedFiles','externalCommittedInputs'])assert.deepEqual(result[key],prior[key]);
const save=()=>fs.writeFileSync('.cache/native-preparation-slices-validation.json',JSON.stringify(result,null,2)+'\n');
result.syntax=[];for(const p of owned){execFileSync('.cache/tooling/node20.exe',['--check',p],{stdio:'pipe'});result.syntax.push(p);}save();
async function run(key,command,environment){
 const log='.cache/native-preparation-slices-'+key+'.log',fd=fs.openSync(log,'w'),startedAt=new Date().toISOString(),start=Date.now();
 const child=spawn(command[0],command.slice(1),{env:{...process.env,...environment},stdio:['ignore',fd,fd]});
 const exitCode=await new Promise((resolve,reject)=>{child.on('error',reject);child.on('close',resolve);});fs.closeSync(fd);
 const row={command,environment,log,sha256:hash(log),startedAt,finishedAt:new Date().toISOString(),seconds:(Date.now()-start)/1000,exitCode};
 if(key==='validation'){const txt=fs.readFileSync(log,'utf8');for(const k of ['tests','pass','fail','cancelled','skipped']){const m=txt.match(new RegExp('^# '+k+' (\\d+)$','m'));assert(m,'Missing '+k);row[k]=+m[1];}}
 result[key]=row;save();console.log(JSON.stringify({key,exitCode,seconds:row.seconds,tests:row.tests,pass:row.pass,fail:row.fail,skipped:row.skipped}));return exitCode;
}
const command=[...prior.validation.command];assert(!command.includes(owned[2]));command.push(owned[2]);result.selectedFiles=command.filter(p=>p.endsWith('.test.js')).length;save();
const codes=await Promise.all([run('validation',command,prior.validation.environment),run('build',prior.build.command,prior.build.environment)]);
for(const key of ['files','testedInputs','runtimeSources','nativeBuiltInputs','preservedFiles','externalCommittedInputs'])for(const[p,h]of Object.entries(result[key]))assert.equal(hash(p),h,p);
result.inputsUnchanged=true;save();process.exit(codes.some(c=>c!==0)?1:0);
