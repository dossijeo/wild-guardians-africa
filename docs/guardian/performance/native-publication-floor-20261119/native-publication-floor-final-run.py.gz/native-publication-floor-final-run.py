from pathlib import Path
import subprocess,os,json,hashlib,time
n='native-publication-floor'
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,value):Path(p).write_bytes((json.dumps(value,indent=2)+'\n').encode())
own=read('.cache/'+n+'-owned-files.json');old=read('.cache/native-paused-publication-tested-hashes.json')
focused=list(dict.fromkeys(read('.cache/native-paused-publication-focused-files.json')+['tests/native-publication-floor.test.js']))
selected=list(dict.fromkeys(read('.cache/native-paused-publication-regression-files.json')+focused))
inputs={p:sha(p) for p in sorted(set(old)|set(own)|set(selected)|set(focused))};native=read('.cache/'+n+'-pre-built-hashes.json');foreign=read('.cache/'+n+'-pre-preserved-hashes.json')
for label,value in [('focused-files',focused),('regression-files',selected),('tested-hashes',inputs)]:write('.cache/'+n+'-'+label+'.json',value)
def verify():
 for mapping in [inputs,native,foreign]:
  for p,digest in mapping.items():assert sha(p)==digest,p
verify();print('Frozen',len(inputs),'inputs;',len(focused),'directed;',len(selected),'selected;64native/16foreign exact.',flush=True)
syntax=[]
for p in own:
 r=subprocess.run(['.cache/tooling/node20.exe','--check',p],capture_output=True,text=True);syntax.append({'file':p,'sha256':sha(p),'exitCode':r.returncode,'output':r.stdout+r.stderr});assert r.returncode==0
write('.cache/'+n+'-syntax.json',syntax)
env=os.environ.copy();env['WILD_ENGINE_NATIVE_ROUTE_WASM']=str(Path('src/world/wild-engine/spatial-savanna.wasm').resolve());env['WILD_ENGINE_SPATIAL_SERVICES_WASM']=env['WILD_ENGINE_NATIVE_ROUTE_WASM'];rows=[]
for label,command in [('final-focused',['.cache/tooling/node20.exe','--test',*focused]),('final-regression',['.cache/tooling/node20.exe','--test',*selected]),('final-build',['.cache/tooling/node20.exe','node_modules/vite/bin/vite.js','build'])]:
 log='.cache/'+n+'-'+label+'.log';started=time.time()
 with open(log,'w',encoding='utf-8') as out:
  process=subprocess.Popen(command,env=env,stdout=out,stderr=out);write('.cache/'+n+'-live-validation.json',{'label':label,'pid':process.pid,'command':command,'log':log,'started':started,'timeoutSeconds':1200})
  # Preserve the recorded handle for diagnosis/adoption if observation expires.
  code=process.wait(timeout=1200)
 rows.append({'label':label,'command':command,'exitCode':code,'seconds':time.time()-started,'log':log,'sha256':sha(log)});write('.cache/'+n+'-final-runs.json',rows);print(label,code,round(time.time()-started,2),flush=True);verify()
 if code:raise SystemExit(code)
print('CPU/build complete;optional native publication floor through existing RPCs/production modules;actual C++ authority/resource MessageChannel with creation/message/GPUqueue adapters. No new hardware GPU or automatic recovery checkpoint claim.',flush=True)
