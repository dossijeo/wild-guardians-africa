from pathlib import Path
import json,subprocess,os
n='native-publication-floor';own=json.loads(Path('.cache/'+n+'-owned-files.json').read_text());sources=[p for p in own if p.startswith('src/')]
mapping={Path(p).resolve().as_uri():str(Path('.cache/'+n+'-'+Path(p).name+'.before').resolve()) for p in sources}
loader=Path('.cache/'+n+'-baseline-loader.mjs');loader.write_text("import {readFile} from 'node:fs/promises';\nconst sources=new Map("+json.dumps(list(mapping.items()))+");\nexport async function load(url,context,next){const file=sources.get(url);return file?{format:'module',source:await readFile(file,'utf8'),shortCircuit:true}:next(url,context);}\n")
absolute={str(Path(p).resolve()).replace('\\','/'):{'before':str(Path('.cache/'+n+'-'+Path(p).name+'.before').resolve()),'dir':str(Path(p).resolve().parent)} for p in sources}
plugin="const __originalNativeSources="+json.dumps(absolute)+";p.onLoad({filter:/\\.js$/},args=>{const item=__originalNativeSources[args.path.replaceAll('\\\\','/')];if(item)return {contents:readFileSync(item.before,'utf8'),loader:'js',resolveDir:item.dir};});"
text=Path('tests/native-production-lifecycle.test.js').read_text(encoding='utf-8').replace("from './helpers/","from '../tests/helpers/").replace('setup(p){','setup(p){'+plugin)
copy=Path('.cache/'+n+'-baseline-lifecycle.test.mjs');copy.write_text(text,encoding='utf-8')
env=os.environ.copy();env['WILD_ENGINE_NATIVE_ROUTE_WASM']=str(Path('src/world/wild-engine/spatial-savanna.wasm').resolve());env['WILD_ENGINE_SPATIAL_SERVICES_WASM']=env['WILD_ENGINE_NATIVE_ROUTE_WASM']
with open('.cache/'+n+'-final-original-new.log','w',encoding='utf-8') as out:p=subprocess.run(['.cache/tooling/node20.exe','--loader',loader.resolve().as_uri(),'--test',str(copy),'tests/native-publication-floor.test.js'],env=env,stdout=out,stderr=out,timeout=120)
s=Path('.cache/'+n+'-final-original-new.log').read_text(encoding='utf-8');print('Baseline exit',p.returncode);print(s[-350:]);assert p.returncode==1 and '# pass 16\n' in s and '# fail 17\n' in s and 'asynchronous activity' not in s
