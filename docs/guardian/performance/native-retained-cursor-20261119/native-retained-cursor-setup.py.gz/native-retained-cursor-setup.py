from pathlib import Path
import json,hashlib,subprocess
n='native-retained-cursor';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_text());write=lambda p,v:Path(p).write_bytes((json.dumps(v,indent=2)+'\n').encode())
base='2fdd772a9ad69a4c17bd149f6580e0828784e40a';assert subprocess.check_output(['git','rev-parse','HEAD']).decode().strip()==base
old=read('.cache/native-retained-surface-recovery-verified-hashes.json');native=read('.cache/native-retained-surface-recovery-pre-built-hashes.json');foreign=read('.cache/native-retained-surface-recovery-pre-preserved-hashes.json');assert len(old)==526 and all(sha(p)==h for m in [old,native,foreign] for p,h in m.items())
for label,m in [('pre-tested',old),('pre-built',native),('pre-preserved',foreign)]:write(f'.cache/{n}-{label}-hashes.json',m)
files=['src/simulation/presentation-recovery-replay.js','src/simulation/historical-terrain-recovery.js','src/world/native-world-boundary.js','src/rendering/temporal-recovery-receiver.js','tests/presentation-retained-recovery-replay.test.js']
write(f'.cache/{n}-owned-files.json',files)
for p in files[:4]+['docs/guardian/integrated-gpu-migration-plan-20261104.md','docs/guardian/MIGRATION-OBJECTIVE.md','docs/guardian/A6-CHECKLIST.md','docs/guardian/CURRENT-STATUS.md']:
 target=Path(f'.cache/{n}-{Path(p).name}.before');assert not target.exists();target.write_bytes(Path(p).read_bytes())
research=read('.cache/native-retained-replay-entry-research.json');assert sha(research['snapshot']['source'])==research['snapshot']['sha256'];research['symbols']=['masterTryPartialResynchronization','addReplyReplicationBacklog'];research['decision']='Validate exact history identity/range before resuming at an already-consumed cursor. Materialize that source checkpoint from the existing complete terrain/journal, replay only its later entries, and keep the original journal base. No new log owner, cache, dependency, source clock or GPU permit.';write(f'.cache/{n}-research.json',research)
print('Verified526prior inputs/64native/16foreign;4production backups and4primary raw backups;Redis pinned source inspected;source cursor projection and suffix replay next.')
