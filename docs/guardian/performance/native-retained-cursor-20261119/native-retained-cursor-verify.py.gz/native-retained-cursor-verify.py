from pathlib import Path
import json,hashlib,gzip,re,subprocess,sys
n='native-retained-cursor';read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();e=read(f'docs/guardian/performance/{n}-validation-20261119.json');files=read(f'.cache/{n}-commit-files.json');assert len(files)==len(set(files)) and len(files)>20
for key,count in [('testedInputs',536),('nativeBuiltInputs',64),('preservedFiles',16)]:assert len(e[key])==count and all(sha(p)==h for p,h in e[key].items()),key
before=read(f'.cache/{n}-pre-tested-hashes.json');assert len(before)==526 and e['changedPriorInputs']==sorted(p for p,h in before.items() if e['testedInputs'][p]!=h) and set(e['changedPriorInputs'])<=set(e['productionChangedFiles']) and e['addedInputs']==sorted(set(e['testedInputs'])-set(before))
assert e['productionChangedFiles']==['src/simulation/presentation-recovery-replay.js','src/simulation/historical-terrain-recovery.js','src/world/native-world-boundary.js','src/rendering/temporal-recovery-receiver.js'] and e['nativeChangedFiles']==[] and e['gpu']['newRuns']==0
assert Path('public/wild-engine/spatial-threaded.worker.mjs').read_bytes()==Path('.cache/native-idle-stroll-preserved-worker.mjs').read_bytes()
def refs(v):
 if isinstance(v,dict):
  if 'source' in v and 'sha256' in v:assert sha(v['source'])==v['sha256'],v['source']
  if 'original' in v and 'raw' in v:assert gzip.decompress(Path(v['raw']['source']).read_bytes())==Path(v['original']['source']).read_bytes(),v['original']['source']
  for x in v.values():refs(x)
 elif isinstance(v,list):
  for x in v:refs(x)
refs(e)
for label,t in e['tests'].items():
 s=Path(t['original']['source']).read_text(encoding='utf-8-sig');assert all(int(re.search(r'^# '+k+r' (\d+)\s*$',s,re.M).group(1))==t[k] for k in ['tests','pass','fail','cancelled','skipped'])
t=e['tests'];assert t['final-baseline-complete']['tests']==23 and t['final-baseline-complete']['pass']==2 and t['final-baseline-complete']['fail']==21 and t['real-receiver-second']['pass']==23 and e['newTests']==23
assert t['final-focused']['pass']==422 and t['final-regression']['pass']>=3977 and t['final-regression']['tests']==t['final-regression']['pass']+t['final-regression']['skipped'] and t['final-regression']['skipped']==1 and all(t[k]['fail']==t[k]['cancelled']==0 for k in ['final-focused','final-regression']) and len(e['focusedFiles'])==27 and len(e['regressionFiles'])==315
assert len(e['syntax'])==5 and all(x['exitCode']==0 and x['sha256']==sha(x['file']) for x in e['syntax']) and e['build']['seconds']>0
for name in ['integrated-gpu-migration-plan-20261104.md','MIGRATION-OBJECTIVE.md','A6-CHECKLIST.md','CURRENT-STATUS.md']:
 old=Path(f'.cache/{n}-{name}.before').read_bytes();new=(Path('docs/guardian')/name).read_bytes();pos=old.index(b'\n')+1;assert new[:pos]==old[:pos] and len(new)>len(old) and new[pos+len(new)-len(old):]==old[pos:]
for row in e['productionBefore']:
 body=Path(row['snapshot']['original']['source']).read_bytes();committed=subprocess.check_output(['git','show',e['baseCommit']+':'+row['file']]);assert body.replace(b'\r\n',b'\n')==committed.replace(b'\r\n',b'\n')
assert read(f'.cache/{n}-stopped-run.json')['controllerPid']==9308
partial=Path(f'.cache/{n}-regression.log').read_text(encoding='utf-8-sig');assert not re.search(r'^# tests ',partial,re.M) and max(map(int,re.findall(r'^ok (\d+) -',partial,re.M)))==903
assert subprocess.check_output(['git','branch','--show-current']).decode().strip()=='codex/guardian-3d-animation' and not subprocess.check_output(['git','diff','--cached','--name-only']).strip()
head=subprocess.check_output(['git','rev-parse','HEAD']).decode().strip();assert head==e['baseCommit'] or subprocess.check_output(['git','rev-parse','HEAD^']).decode().strip()==e['baseCommit']
if '--published' in sys.argv:
 assert not subprocess.check_output(['git','status','--porcelain','--',*files]).strip()
 assert subprocess.check_output(['git','rev-list','--left-right','--count','HEAD...origin/codex/guardian-3d-animation']).decode().strip()=='0\t0'
 assert subprocess.check_output(['git','ls-remote','origin','refs/heads/codex/guardian-3d-animation']).decode().split()[0]==head
subprocess.run(['git','diff','--check','--',*files],check=True);print('Verified',len(files),'paths;536/64native-unchanged/16foreign-exact;23new/422directed;',t['final-regression']['pass'],'of',t['final-regression']['tests'],'selected1skip/build',e['build']['seconds'],';5syntax/full raw history/primary suffixes intact. Source cursor+suffix integration only;no new GPU/ordinary handoff/cadence claim.')
