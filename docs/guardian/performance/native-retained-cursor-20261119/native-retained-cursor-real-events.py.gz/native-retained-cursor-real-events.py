from pathlib import Path
p=Path('tests/presentation-retained-recovery-replay.test.js');s=p.read_text();a="import {observePresentationGameEvents} from '../src/simulation/game.js';";assert s.count(a)==1;s=s.replace(a,"import {emit,observePresentationGameEvents} from '../src/simulation/game.js';")
for a,b,count in [
 ('state.workers[0].heading=sequence/10;if(terrain.length)',"state.workers[0].heading=sequence/10;if(!unchanged)emit(state,'Audit');if(terrain.length)",1),
 ('events:[{id:`event-${sequence}`,type:\'Audit\',time:state.elapsed}]','events:[state.events.at(-1)]',1),
 ("assert.deepEqual(events,['event-4','event-6']);","assert.deepEqual(events,[4,6].map(n=>f.publications.get(n).events[0].id));",2),
 ("f.journal.append({...f.publications.get(6),sequence:7,events:[{id:'event-7'}]},true);","emit(f.state,'Audit');f.journal.append({...f.publications.get(6),sequence:7,snapshot:serializeConfirmedState(f.state),events:[f.state.events.at(-1)]},true);",1)
]:
 assert s.count(a)==count,(a,s.count(a));s=s.replace(a,b)
p.write_bytes(s.encode());print('Source fixture now emits real Game event IDs and snapshot sequence changes. Real receiver verifies no duplicate prior event and preserves actor identity.')
