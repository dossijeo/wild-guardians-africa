from pathlib import Path
import json,subprocess
n='native-retained-cursor';files=json.loads(Path(f'.cache/{n}-commit-files.json').read_text());assert not subprocess.check_output(['git','diff','--cached','--name-only']).strip()
subprocess.run(['git','fetch','origin','codex/guardian-3d-animation'],check=True);assert subprocess.check_output(['git','rev-parse','HEAD']).strip()==subprocess.check_output(['git','rev-parse','origin/codex/guardian-3d-animation']).strip()
p=Path(f'.cache/{n}-pathspec.txt');p.write_bytes(('\0'.join(files)+'\0').encode());subprocess.run(['git','add','--pathspec-from-file='+str(p),'--pathspec-file-nul'],check=True)
staged=subprocess.check_output(['git','diff','--cached','--name-only','-z']).decode().strip('\0').split('\0');assert sorted(staged)==sorted(files);subprocess.run(['git','diff','--cached','--check'],check=True)
subprocess.run(['git','-c','user.name=OpenAI','-c','user.email=noreply@openai.com','commit','-m','Resume retained presentation from its verified source cursor'],check=True)
subprocess.run(['git','push','origin','HEAD:refs/heads/codex/guardian-3d-animation'],check=True);subprocess.run(['.cache/emsdk/python/3.13.3_64bit/python.exe','-X','utf8',f'.cache/{n}-verify.py','--published'],check=True);print('Published',subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),flush=True)
