from pathlib import Path
import json,hashlib,subprocess,os,sys
n='native-retained-cursor';read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();write=lambda p,v:Path(p).write_bytes((json.dumps(v,indent=2)+'\n').encode())
own=read(f'.cache/{n}-owned-files.json');old=read(f'.cache/{n}-pre-tested-hashes.json');native=read(f'.cache/{n}-pre-built-hashes.json');foreign=read(f'.cache/{n}-pre-preserved-hashes.json')
focused=list(dict.fromkeys(read('.cache/native-retained-surface-recovery-focused-files.json')+['tests/presentation-retained-recovery-replay.test.js','tests/presentation-recovery-replay.test.js','tests/historical-terrain-recovery.test.js','tests/temporal-recovery-receiver.test.js','tests/presentation-recovery-journal.test.js','tests/temporal-recovery-pipeline.test.js']))
selected=list(dict.fromkeys(read('.cache/native-retained-surface-recovery-regression-files.json')+focused));write(f'.cache/{n}-focused-files.json',focused);write(f'.cache/{n}-regression-files.json',selected)
inputs={p:sha(p) for p in sorted(set(old)|set(own)|set(focused)|set(selected)|{'src/simulation/presentation-worker-headings.js','src/simulation/retained-size.js','src/simulation/terrain-publication.js','src/simulation/presentation-recovery-journal.js'})};write(f'.cache/{n}-final-tested-hashes.json',inputs)
def verify():assert all(sha(p)==h for m in [inputs,native,foreign] for p,h in m.items())
verify();print('Frozen',len(inputs),'inputs;',len(focused),'directed;',len(selected),'selected files;64native/16foreign exact.',flush=True)
syntax=[]
for p in own:
 r=subprocess.run(['.cache/tooling/node20.exe','--check',p],capture_output=True,text=True);syntax.append({'file':p,'sha256':sha(p),'exitCode':r.returncode,'output':r.stdout+r.stderr});assert r.returncode==0
write(f'.cache/{n}-final-syntax.json',syntax)
with open(f'.cache/{n}-final-baseline-complete.log','w',encoding='utf-8') as output:r=subprocess.run(['.cache/tooling/node20.exe','--experimental-loader','./.cache/native-retained-cursor-baseline-loader.mjs','--test','tests/presentation-retained-recovery-replay.test.js'],stdout=output,stderr=output)
assert r.returncode!=0;print('Original-source complete baseline',r.returncode,flush=True);verify()
env=os.environ.copy();env['WILD_ENGINE_NATIVE_ROUTE_WASM']=str(Path('src/world/wild-engine/spatial-savanna.wasm').resolve());env['WILD_ENGINE_SPATIAL_SERVICES_WASM']=env['WILD_ENGINE_NATIVE_ROUTE_WASM']
for label,command in [('final-focused',['.cache/tooling/node20.exe','--test',*focused]),('final-regression',['.cache/tooling/node20.exe','--test',*selected]),('final-build',['.cache/tooling/node20.exe','node_modules/vite/bin/vite.js','build'])]:
 with open(f'.cache/{n}-{label}.log','w',encoding='utf-8') as output:r=subprocess.run(command,env=env,stdout=output,stderr=output)
 print(label,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
 verify()
print('Exact',len(inputs),'tested/64native unchanged/16foreign;23new source cursor+suffix/negative cases;ordinary Worker/UI/producer handoff and GPU/cadence still pending.',flush=True)
