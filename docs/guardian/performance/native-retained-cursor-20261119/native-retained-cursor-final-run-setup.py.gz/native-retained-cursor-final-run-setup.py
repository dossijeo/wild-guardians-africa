from pathlib import Path
s=Path('.cache/native-retained-cursor-run.py').read_text()
for a,b in [('-tested-hashes.json','-final-tested-hashes.json'),('-syntax.json','-final-syntax.json'),('-baseline-complete.log','-final-baseline-complete.log'),("('focused',","('final-focused',"),("('regression',","('final-regression',"),("('build',","('final-build',"),('22new source cursor','23new source cursor')]:
 if a=='-tested-hashes.json':
  # Only the output; retain the original prior-input map read.
  a="write(f'.cache/{n}-tested-hashes.json',inputs)";b="write(f'.cache/{n}-final-tested-hashes.json',inputs)"
 assert a in s,a;s=s.replace(a,b)
p=Path('.cache/native-retained-cursor-final-run.py');assert not p.exists();p.write_bytes(s.encode());print('Separate final validation outputs;earlier partial run and frozen inputs retained. Production unchanged;corrected fixture plus real state receiver frozen next.')
