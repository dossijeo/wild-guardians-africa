from pathlib import Path
p=Path('tests/presentation-retained-recovery-replay.test.js');s=p.read_text()
s=s.replace("const boundary=n=>", "const sourceElapsed=deserialize(gunzipSync(readFileSync('tests/fixtures/manglares-123-d10-raid-state.json.gz')).toString()).elapsed;\nconst boundary=n=>")
for a,b in [
 ('effectiveTime:10+n-1','effectiveTime:sourceElapsed'),
 ('state.raid=null;state.elapsed=10;','state.raid=null;'),
 ('capturedAt:10','capturedAt:sourceElapsed'),
 ('producer.stage(initial,10)','producer.stage(initial,sourceElapsed)'),
 ("sequence:1,elapsed:10,snapshot:","sequence:1,elapsed:sourceElapsed,snapshot:"),
 ('state.elapsed=10+sequence-1;','state.workers[0].heading=sequence/10;'),
 ('state.elapsed=13;const unchanged=','const unchanged='),
 ('sequence:5,elapsed:13,','sequence:5,elapsed:sourceElapsed,'),
 ('const elapsed=sequence===5?13:10+sequence-1;','const elapsed=sourceElapsed;'),
 ('assert.equal(p.checkpoint.elapsed,12)','assert.equal(p.checkpoint.elapsed,sourceElapsed)'),
 ('capturedAt:12','capturedAt:sourceElapsed'),
 ('assert.equal(p.checkpoint.elapsed,13)','assert.equal(p.checkpoint.elapsed,sourceElapsed)'),
 ("workCheckpoint,elapsed:13}","workCheckpoint,elapsed:sourceElapsed+1}"),
 ('sequence:2,elapsed:11,nativeWorldResources:','sequence:2,elapsed:sourceElapsed,nativeWorldResources:')
]:
 assert a in s,a;s=s.replace(a,b)
p.write_bytes(s.encode());print('Fixture keeps the real saved elapsed; source revisions/heading/snapshot changes happen at that same boundary, without invalidating unrelated raid/wall clocks.')
