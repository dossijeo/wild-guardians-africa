import {readFile} from 'node:fs/promises';
const files=new Set(['presentation-recovery-replay.js','historical-terrain-recovery.js','native-world-boundary.js','temporal-recovery-receiver.js']);
export async function load(url,context,nextLoad){
 const name=url.split('/').at(-1);
 if(url.startsWith('file:')&&files.has(name))return {format:'module',shortCircuit:true,source:await readFile(new URL(`./native-retained-cursor-${name}.before`,import.meta.url),'utf8')};
 return nextLoad(url,context);
}
