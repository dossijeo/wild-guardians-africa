from pathlib import Path
p=Path('src/simulation/historical-terrain-recovery.js');s=p.read_text()
for a,b in [
 ('const revisions=new Map(),removed=new Map(),keyOf=', 'const revisions=new Map(),removed=new Map(),removedAt=new Map(),keyOf='),
 ('removed.set(key,chunk.removed===true);','removed.set(key,chunk.removed===true);if(chunk.removed===true)removedAt.set(key,chunk.capturedAt);else removedAt.delete(key);'),
 ('revisions.set(key,row.revision);removed.set(key,true);','revisions.set(key,row.revision);removed.set(key,true);removedAt.set(key,row.capturedAt);'),
 ("removed.get(key)!==(chunk.removed===true))throw Error('Historical terrain handoff mismatch')", "removed.get(key)!==(chunk.removed===true)||chunk.removed!==undefined&&chunk.removed!==true||chunk.removed===true&&(!Number.isFinite(removedAt.get(key))||chunk.capturedAt!==removedAt.get(key)))throw Error('Historical terrain handoff mismatch')")
]:
 assert s.count(a)==1,(a,s.count(a));s=s.replace(a,b)
p.write_bytes(s.encode())
p=Path('tests/presentation-retained-recovery-replay.test.js');s=p.read_text();a='let receiver,replay;';assert s.count(a)==1;s=s.replace(a,'caught.catch(()=>{});let receiver,replay;');p.write_bytes(s.encode());print('Source removal proof now checks removed flag and exact authoritative capture time;no synthesized revision or time. Original graphical admission guard unchanged.')
