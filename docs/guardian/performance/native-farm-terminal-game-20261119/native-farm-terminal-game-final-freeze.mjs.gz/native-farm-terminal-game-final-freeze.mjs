import fs from 'node:fs';import crypto from 'node:crypto';import assert from 'node:assert/strict';import {execFileSync} from 'node:child_process';
const n='native-farm-terminal-game',read=p=>JSON.parse(fs.readFileSync(p,'utf8').replace(/^\uFEFF/,'')),hash=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex'),b=read('.cache/'+n+'-baseline.json'),own=read('.cache/'+n+'-owned-files.json'),native=read('.cache/'+n+'-built-hashes.json'),tested={};
assert.equal(execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),b.baseCommit);assert.equal(execFileSync('git',['diff','--cached','--name-only'],{encoding:'utf8'}).trim(),'');
for(const[p,h]of Object.entries(b.testedInputs)){tested[p]=hash(p);if(!own.includes(p))assert.equal(tested[p],h,p);}for(const p of own)tested[p]=hash(p);
for(const m of [native,b.preservedFiles])for(const[p,h]of Object.entries(m))assert.equal(hash(p),h,p);
const changed=own.filter(p=>!b.testedInputs[p]||tested[p]!==b.testedInputs[p]);
const syntax=changed.filter(p=>p.endsWith('.js'));for(const p of syntax)execFileSync('.cache/tooling/node20.exe',['--check',p],{windowsHide:true});
for(const[p,h]of Object.entries(read('.cache/'+n+'-geometry-ownership-audit.json').inputs))assert.equal(hash(p),h,p);
fs.writeFileSync('.cache/'+n+'-frozen.json',JSON.stringify({baseCommit:b.baseCommit,testedInputs:tested,nativeBuiltInputs:native,preservedFiles:b.preservedFiles,changedFiles:changed,nativeChangedFiles:Object.keys(native).filter(p=>native[p]!==b.nativeBuiltInputs[p]),syntaxPass:syntax.length},null,2)+'\n');console.log({tested:Object.keys(tested).length,native:Object.keys(native).length,preserved:Object.keys(b.preservedFiles).length,changed,syntax:syntax.length});
