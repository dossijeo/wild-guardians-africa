import test from 'node:test';import assert from 'node:assert/strict';
import {nativeIdleStrollGameFixture} from './helpers/native-idle-stroll-game.js';
import {PROFILES} from '../src/simulation/workforce.js';
import {tick} from '../src/simulation/game.js';
import {createNativeIntentProduction} from '../src/simulation/native-intent-production.js';
import {createThreadedSpatialWorld} from '../src/world/wild-engine/spatial-thread-runtime.js';

async function fixture(threaded,profile){let runtime;try{if(threaded){const{default:factory}=await import('../public/wild-engine/spatial-threaded.mjs');runtime=await createThreadedSpatialWorld(factory);}const f=nativeIdleStrollGameFixture({core:runtime?.core,profile,peer:false});f.commitStroll();f.planner.projectNativeIdleStroll(f.state,f.worker);tick(f.state,.1,f.nav);return {...f,async close(){f.close();await runtime?.dispose();}};}catch(e){await runtime?.dispose();throw e;}}

for(const threaded of [false,true])for(const p of PROFILES)test(`${threaded?'pthread':'standalone'} ${p.id} contract expiry requests prepared WALK stop before Home on its original body`,async()=>{
 const f=await fixture(threaded,p.id);try{
  assert.equal(f.planner.nativeIdleStrollStopRequest(f.actor),null);const binding=f.planner.nativeIdleStrollBinding(f.actor),body=f.body(1),rng=f.state.rng,ledger=structuredClone(f.state.ledger);
  f.state.time=p.end-.05;tick(f.state,.1,f.nav);assert.notDeepEqual(f.body(1),body);assert.equal(f.worker.nativeRouteAdmission,'native-idle-stroll');assert.equal(f.worker.status,'idle');assert.equal(f.planner.nativeHomeRequestReference(f.actor),null);
  const request=f.planner.nativeIdleStrollStopRequest(f.actor);assert.equal(request.reason,'home');assert.deepEqual(request.binding,binding);
  const stop=f.planner.prepareNativeIdleStrollStopProposal(f.actor);assert.equal(stop.status,'proposed');const moving=f.body(1);tick(f.state,.1,f.nav);assert.notDeepEqual(f.body(1),moving);assert.equal(f.planner.nativeHomeRequestReference(f.actor),null);
  const fresh=f.planner.revalidateNativeIdleStrollStopProposal(stop.ticket);assert.equal(fresh.status,'revalidated');assert.equal(f.w.spatial_world_proposal_stop_commit_bound(...f.tuple().slice(0,5),stop.ticket.ticket),1);assert.equal(f.planner.commitNativeCausalClock().status,'committed');const held=f.planner.projectNativeIdleStroll(f.state,f.worker),heldBody=f.body(1);tick(f.state,.1,f.nav);
  const home=f.planner.nativeHomeRequestReference(f.actor);assert(home);assert.equal(home.bodyId,binding.reference.bodyId);assert.equal(home.actorId,f.actor);assert.equal(f.worker.nativeRouteAdmission,'pending-home-resources');assert.equal(f.worker.status,'returning');assert.deepEqual(f.body(1),heldBody);assert.deepEqual(home.pose,held.pose);assert.equal(f.state.rng,rng);assert.deepEqual(f.state.ledger,ledger);assert.equal(f.w.spatial_body_count(),1);
 }finally{await f.close();}
});

test('ordinary producer dispatches family12 and withdraws it when the actual contract is renewed',async()=>{
 const f=await fixture(false,'olderMale'),calls=[],prepared=[],errors=[];let production,release;
 try{
  f.worker.contractDay--;tick(f.state,.1,f.nav);
  const planner={...f.planner,stopNativeIdleStrollAfterGpuQuiescence(options){calls.push(options);const p=f.planner.prepareNativeIdleStrollStopProposal(f.actor);assert.equal(p.status,'proposed');options.prepareResources({resources:f.planner.captureNativeIdleStrollStopProposal(p.ticket),signal:options.signal,deferredStart:true});return new Promise(resolve=>{release=()=>resolve({status:'cancelled'});});}};
  production=createNativeIntentProduction({state:f.state,planner,bodyId:()=>1,getPublication:()=>({status:()=>({coherent:true,closed:false})}),getResources:()=>({status:()=>({phase:'running',pending:false,retained:false}),prepareNativeGateResources(resources,options){prepared.push({resources,options});return Promise.resolve({observationOnly:true});}}),publicationSequence:()=>7,terrainManifest:()=>({epoch:'dispatch-observation',chunks:[]}),onError:e=>errors.push(e)});
  const pending=production.wake();assert.equal(calls.length,1);assert.equal(calls[0].actorId,f.worker.id);assert.equal(prepared[0].resources.kind,12);assert.equal(prepared[0].options.minSequence,7);assert.equal(prepared[0].options.deferredStart,undefined);assert.equal(production.status().active.kind,'idle-stroll-stop');assert.equal(calls[0].signal.aborted,false);
  f.worker.contractDay=f.state.day;tick(f.state,.1,f.nav);production.wake();assert.equal(calls[0].signal.aborted,true);release();await pending;assert.equal(f.planner.nativeIdleStrollHeldExecution(f.actor),null);assert.equal(f.planner.nativeHomeRequestReference(f.actor),null);assert.deepEqual(errors,[]);
 }finally{release?.();production?.dispose();await f.close();}
});

for(const fault of ['retired','pose','profile','task'])test(`${fault} live WALK source cannot supply a Home stop request`,async()=>{
 const f=await fixture(false,'olderMale');try{f.worker.contractDay--;if(fault==='retired'){f.w.nav_intent_retire_actor(f.actor);f.planner.commitNativeCausalClock();assert.equal(f.planner.nativeIdleStrollStopRequest(f.actor),null);}else{if(fault==='pose')f.worker.x+=.1;else if(fault==='profile')f.worker.profile='youngFemale';else f.worker.taskId='task-999';const at=f.state.elapsed,body=f.body(1);assert.throws(()=>f.planner.nativeIdleStrollStopRequest(f.actor),/Idle|stroll|source|owner/i);assert.equal(f.state.elapsed,at);assert.deepEqual(f.body(1),body);}}finally{await f.close();}
});
