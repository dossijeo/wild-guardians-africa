from pathlib import Path
from urllib.request import Request,urlopen
import json,hashlib,subprocess
n='native-retained-surface-recovery';old='native-retained-replay-entry';read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();write=lambda p,v:Path(p).write_bytes((json.dumps(v,indent=2)+'\n').encode())
assert subprocess.check_output(['git','rev-parse','HEAD']).decode().strip()=='8bbf5daa73da8b0281646cde562fdc1c4a1523d3'
for before,after in [('tested','tested'),('pre-built','built'),('pre-preserved','preserved')]:
 m=read(f'.cache/{old}-{before}-hashes.json');assert all(sha(p)==h for p,h in m.items());write(f'.cache/{n}-pre-{after}-hashes.json',m)
files=['src/rendering/webgpu-world-surface.js','src/rendering/temporal-surface-recovery.js','tests/temporal-surface-recovery.test.js','tests/browser/webgpu-temporal-ground-worker.js','tools/experiments/audit_webgpu_temporal_ground.mjs','src/rendering/webgpu-world-worker.js','src/rendering/webgpu-world-client.js','tests/webgpu-temporal-recovery-worker.test.js'];assert not subprocess.check_output(['git','status','--porcelain','--',*files]).strip()
for f in files:
 p=Path(f);q=Path(f'.cache/{n}-{p.name}.before');assert not q.exists();q.write_bytes(p.read_bytes())
write(f'.cache/{n}-candidate-files.json',files)
for name in ['integrated-gpu-migration-plan-20261104.md','MIGRATION-OBJECTIVE.md','A6-CHECKLIST.md','CURRENT-STATUS.md']:
 p=Path(f'.cache/{n}-{name}.before');assert not p.exists();p.write_bytes((Path('docs/guardian')/name).read_bytes())
get=lambda u:urlopen(Request(u,headers={'User-Agent':'Wild-Guardians-migration-source-audit'}),timeout=25).read();sources=[]
for repo,rev,path,name,symbols in [('facebook/react','ae74234eae6ebd62f19190731278e20bc1c37d51','packages/react-reconciler/src/ReactFiberHooks.js','react-hooks.js',['mountSyncExternalStore','updateStoreInstance','checkIfSnapshotChanged']),('epoberezkin/fast-deep-equal',None,'src/index.jst','fast-deep-equal.jst',['Object.keys','Array.isArray'])]:
 if rev is None:rev=json.loads(get(f'https://api.github.com/repos/{repo}/commits/v3.1.3'))['sha']
 p=Path(f'.cache/{n}-{name}');p.write_bytes(get(f'https://raw.githubusercontent.com/{repo}/{rev}/{path}'));sources.append({'repo':repo,'revision':rev,'url':f'https://github.com/{repo}/blob/{rev}/{path}','snapshot':{'source':p.as_posix(),'sha256':sha(p)},'symbols':symbols})
write(f'.cache/{n}-research.json',{'sources':sources,'decision':'Inspect snapshot consistency before/after asynchronous work and DTO equality before integrating retained state/effects in existing controller/Surface. No React/deep-equal dependency or replacement architecture.'});print('Saved524/64/16,8candidate originals/main raw suffixes;actual hook consistency and deep-equality source pinned for inspection.')
