async function auditRetainedSurfaceRecovery({negative=false}={}){
 const prefix=process.env.QA_ARTIFACT_PREFIX??`.cache/native-retained-surface-recovery-${Date.now()}`,output=process.env.OUTPUT??prefix+'.json',consoleErrors=[],httpFailures=[],requestErrors=[],served=new Map(),browser=await chromium.launch({channel:'msedge',headless:true});
 const save=(path,body)=>writeFile(path,body,{flag:'wx'});
 try{
  const page=await browser.newPage();page.on('console',message=>{if(message.type()==='error')consoleErrors.push({text:message.text(),location:message.location()});});page.on('pageerror',error=>consoleErrors.push({pageError:String(error.stack??error)}));page.on('response',response=>{if(response.status()>=400)httpFailures.push({url:response.url(),status:response.status()});});page.on('requestfailed',request=>requestErrors.push({url:request.url(),failure:request.failure()}));
  await page.route('**/ground-qa',route=>route.fulfill({status:200,contentType:'text/html',body:'<link rel="icon" href="data:,"><canvas width="512" height="512"></canvas>'}));
  for(const [name,pattern] of [['surface','**/src/rendering/webgpu-world-surface.js*'],['worker','**/tests/browser/webgpu-temporal-ground-worker.js*'],['host','**/src/rendering/remote-webgpu-host.js*']])await page.route(pattern,async route=>{
   const response=await route.fetch();let source=await response.text();
   if(name==='host'){
    const anchor='inspect: () => ({ ...metrics,';if(source.split(anchor).length!==2)throw Error('Readonly retained native inventory anchor missing');
    source=source.replace(anchor,"inspect: () => ({ qaRetainedResources:[...resources.values()].filter(entry=>entry.value&&typeof entry.value==='object').map(entry=>{if(!qaRetainedNativeIds.has(entry.value))qaRetainedNativeIds.set(entry.value,++qaRetainedNativeNext);return {id:entry.id,kind:entry.kind,generation:qaRetainedNativeIds.get(entry.value),label:entry.descriptor?.label??null,usage:entry.descriptor?.usage??0,retired:entry.retired,nativeDestroyed:entry.nativeDestroyed};}), ...metrics,");
    source+='\nconst qaRetainedNativeIds=new WeakMap();let qaRetainedNativeNext=0;\n';
   }
   if(!served.has(name)){await save(prefix+'-'+name+'-served.js',source);served.set(name,source);}else if(served.get(name)!==source)throw Error('Served source changed during retained recovery audit: '+name);
   await route.fulfill({response,body:source});
  });
  await page.goto((process.env.QA_BASE_URL??'http://127.0.0.1:5200')+'/ground-qa');
  const result=await page.evaluate(({negative})=>new Promise((resolve,reject)=>{
   const worker=new Worker('/tests/browser/webgpu-temporal-ground-worker.js',{type:'module'}),draw=new Worker('/src/rendering/webgpu-draw-worker.js',{type:'module'}),canvas=document.querySelector('canvas').transferControlToOffscreen(),r=new MessageChannel(),c=new MessageChannel(),unusedR=new MessageChannel(),unusedC=new MessageChannel();window.retainedRecoveryWorkers=[worker,draw];const timer=setTimeout(()=>reject(Error('Retained Surface GPU audit timed out')),160000);worker.onerror=event=>{clearTimeout(timer);reject(Error(event.message||'Retained Surface Worker failed to parse or load'));};worker.onmessage=({data})=>{clearTimeout(timer);resolve(data);};
   draw.postMessage({type:'init',canvas,port:r.port2,intentControl:{port:c.port2,session:'ground-native'}},[canvas,r.port2,c.port2]);worker.postMessage({nativeReplay:true,nativeRetainedRecovery:true,nativeRetainedRecoveryNegative:negative,nativeDelta:false,resource:r.port1,control:c.port1,resourceNext:unusedR.port1,controlNext:unusedC.port1},[r.port1,c.port1,unusedR.port1,unusedC.port1]);
  }),{negative});
  let disposal=null;if(result.ok){await page.locator('canvas').screenshot({path:prefix+'.png'});disposal=await page.evaluate(()=>new Promise((resolve,reject)=>{const worker=window.retainedRecoveryWorkers[0],timer=setTimeout(()=>reject(Error('Retained Surface actual GPU disposal/drain timed out')),20000);worker.onmessage=({data})=>{if(data.nativeRetainedRecoveryDisposed!==undefined){clearTimeout(timer);resolve(data);}};worker.postMessage({nativeReplayCaptured:true});}));}
  await page.evaluate(()=>{for(const worker of window.retainedRecoveryWorkers??[])worker.terminate();});const report={result,disposal,consoleErrors,httpFailures,requestErrors,servedSources:[...served.keys()].map(name=>prefix+'-'+name+'-served.js'),screenshot:result.ok?prefix+'.png':null};await save(output,JSON.stringify(report,null,2));
  console.log(JSON.stringify({ok:result.ok,error:result.error,mode:result.mode,types:result.types,retainedChunks:result.retainedChunks,retainedNodes:result.retainedNodes,retainedImmutableNativeGenerations:result.retainedImmutableNativeGenerations,unchangedCheckpoint:result.unchangedCheckpoint?{created:result.unchangedCheckpoint.created,factories:result.unchangedCheckpoint.factories}:null,disposed:disposal?.nativeRetainedRecoveryDisposed,consoleErrors,httpFailures,requestErrors,output}));
  if(!result.ok||!disposal?.nativeRetainedRecoveryDisposed||consoleErrors.length||httpFailures.length||requestErrors.length)process.exitCode=1;
 }catch(error){await save(output,JSON.stringify({fatal:String(error.stack??error),consoleErrors,httpFailures,requestErrors,servedSources:[...served.keys()].map(name=>prefix+'-'+name+'-served.js')},null,2));throw error;}finally{await browser.close();}
}
