from pathlib import Path
import json,hashlib,os,subprocess,sys
n='native-retained-surface-recovery';read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();write=lambda p,v:Path(p).write_bytes((json.dumps(v,indent=2)+'\n').encode())
own=read(f'.cache/{n}-candidate-files.json')[:5];write(f'.cache/{n}-owned-files.json',own)
focused=list(dict.fromkeys(read('.cache/native-retained-replay-entry-focused-files.json')+['tests/webgpu-world-surface-epochs.test.js','tests/webgpu-native-world-admission.test.js','tests/webgpu-pipeline-admission.test.js','tests/native-world-boundary.test.js']))
files=list(dict.fromkeys(read('.cache/native-retained-replay-entry-regression-files.json')+focused));write(f'.cache/{n}-focused-files.json',focused);write(f'.cache/{n}-regression-files.json',files)
inputs={p:sha(p) for p in sorted(set(read(f'.cache/{n}-pre-tested-hashes.json'))|set(own)|set(focused)|set(files)|{'src/rendering/webgpu-native-world-admission.js','src/rendering/webgpu-pipeline-admission.js'})};write(f'.cache/{n}-tested-hashes.json',inputs)
native=read(f'.cache/{n}-pre-built-hashes.json');foreign=read(f'.cache/{n}-pre-preserved-hashes.json')
def verify():assert len(native)==64 and len(foreign)==16 and all(sha(p)==h for m in [inputs,native,foreign] for p,h in m.items())
verify();syntax=[]
for p in own:
 r=subprocess.run(['.cache/tooling/node20.exe','--check',p],capture_output=True,text=True);syntax.append({'file':p,'sha256':sha(p),'exitCode':r.returncode,'output':r.stdout+r.stderr});assert r.returncode==0
write(f'.cache/{n}-syntax.json',syntax);env=os.environ.copy();env['WILD_ENGINE_NATIVE_ROUTE_WASM']=str(Path('src/world/wild-engine/spatial-savanna.wasm').resolve());env['WILD_ENGINE_SPATIAL_SERVICES_WASM']=env['WILD_ENGINE_NATIVE_ROUTE_WASM']
print('frozen',len(inputs),'inputs;',len(focused),'focused;',len(files),'selected files',flush=True)
for label,command in [('focused',['.cache/tooling/node20.exe','--test',*focused]),('regression',['.cache/tooling/node20.exe','--test',*files]),('build',['.cache/tooling/node20.exe','node_modules/vite/bin/vite.js','build'])]:
 with open(f'.cache/{n}-{label}.log','w',encoding='utf-8') as log:r=subprocess.run(command,env=env,stdout=log,stderr=log)
 print(label,r.returncode,flush=True)
 if r.returncode:sys.exit(r.returncode)
 verify()
print('Exact',len(inputs),'tested/64unchanged native/16foreign;frozen CPU/build complete;final GPU still required. Ordinary UI/producer/Worker handoff/full migration/cadence remain open.',flush=True)
