from pathlib import Path
n='native-retained-surface-recovery';s=Path('tools/experiments/audit_webgpu_temporal_ground.mjs').read_text()
a="   if(name==='host'){"
b="""   if(name==='surface')source=source.replace('if(sameNativeWorldBoundary(boundary,nativeWorldFrameAdmission?.worldBoundary??null)&&nativeWorldFrameAdmission.valid())','if(false)');
   if(name==='worker')source=source.replace("if(['uniformForks','bindingForks','bufferForks','textureForks'].some(key=>(noopAfter.consumer[key]??0)!==(noopBefore.consumer[key]??0)))throw Error('Identical retained checkpoint forked native resources');",'');
"""+a
assert s.count(a)==1;Path(f'.cache/{n}-isolate-recompile-audit.mjs').write_bytes(s.replace(a,b).encode())
print('Diagnostic only: restores previous full-scene recompilation for identical checkpoint; records native forks without accepting them as incremental.')
