from pathlib import Path
n='native-retained-surface-recovery'
s=Path('tools/experiments/audit_webgpu_temporal_ground.mjs').read_text()
a="   if(name==='host'){"
b="""   if(name==='worker'){
    const begin='    const work=surface.agricultureVfx.exportWorkCheckpoint(2,';
    const end='    if(data.nativeRetainedReadmission)';
    const start=source.indexOf(begin),next=source.indexOf(end,start),last=source.indexOf('\\n',next);
    if(start<0||next<0||last<0)throw Error('Noop isolation anchor absent');
    source=source.slice(0,start)+'    if(false){\\n'+source.slice(start,last)+'\\n    }'+source.slice(last);
   }
"""+a
assert s.count(a)==1
Path(f'.cache/{n}-isolate-noop-audit.mjs').write_bytes(s.replace(a,b).encode())
print('Diagnostic only: skips second identical recovery; first actual production recovery unchanged.')
