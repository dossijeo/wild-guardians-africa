from pathlib import Path
import json
n='native-retained-surface-recovery'
s=Path(f'.cache/{n}-texture-hash-debug-audit.mjs').read_text()
t=Path(f'.cache/{n}-texture-hash-debug.txt').read_text()
u=t.replace('+tex.reduce((n,row)=>n+row.bytes,0)', '+tex.reduce((n,row)=>n+row.bytes,0)+256')
u=u.replace('for(const row of tex){encoder.copyTextureToBuffer', 'for(const row of tex){offset=Math.ceil(offset/256)*256;encoder.copyTextureToBuffer')
assert t!=u
assert json.dumps(t) in s
Path(f'.cache/{n}-texture-hash-debug2-audit.mjs').write_bytes(s.replace(json.dumps(t),json.dumps(u)).encode())
print('Readback offsets corrected to required 256-byte texture alignment; diagnostic only.')
