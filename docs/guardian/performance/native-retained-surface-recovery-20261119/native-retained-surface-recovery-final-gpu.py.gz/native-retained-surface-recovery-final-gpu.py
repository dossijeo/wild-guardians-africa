from pathlib import Path
import json,hashlib,subprocess,os
n='native-retained-surface-recovery';read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();inputs=read(f'.cache/{n}-tested-hashes.json');native=read(f'.cache/{n}-pre-built-hashes.json');foreign=read(f'.cache/{n}-pre-preserved-hashes.json');extra=read(f'.cache/{n}-active-work-inputs.json')
def verify():assert all(sha(p)==h for m in [inputs,native,foreign,extra] for p,h in m.items())
log=Path(f'.cache/{n}-run.log').read_text();assert 'build 0' in log and 'Exact 526' in log
verify()
with open(f'.cache/{n}-active-work.log','w',encoding='utf-8') as output:code=subprocess.run(['.cache/tooling/node20.exe','--test',f'.cache/{n}-active-work.test.mjs','tests/work-vfx-checkpoint.test.js'],stdout=output,stderr=output).returncode
print('supplemental work',code,flush=True);assert code==0;verify()
# Readonly extra client counter in the existing fresh-control fixture. The
# actual Surface, native controls and preparation logic are unchanged.
source=Path('tools/experiments/audit_webgpu_temporal_ground.mjs').read_text();anchor="await page.goto((process.env.QA_BASE_URL??'http://127.0.0.1:5200')+'/ground-qa');";assert source.count(anchor)==2
hook="""await page.route('**/tests/browser/webgpu-temporal-ground-worker.js*',async route=>{const response=await route.fetch();let source=await response.text();const anchor='adapter:inspection.consumer.adapterInfo,checkpointWorld:';if(source.split(anchor).length!==2)throw Error('Readonly fresh resource counter anchor missing');source=source.replace(anchor,'adapter:inspection.consumer.adapterInfo,resourcesCreated:remote.inspect().resourcesCreated,checkpointWorld:');await writeFile(process.env.QA_ARTIFACT_PREFIX+'-worker-served.js',source,{flag:'wx'});await route.fulfill({response,body:source});});"""
adapter=f'.cache/{n}-fresh-audit.mjs';assert not Path(adapter).exists();Path(adapter).write_bytes(source.replace(anchor,hook+anchor,1).encode());assert subprocess.run(['.cache/tooling/node20.exe','--check',adapter],capture_output=True).returncode==0
rows=[]
for mode,label in [('true','positive'),('readmission','readmission'),('negative','negative'),('false','fresh')]:
 prefix=f'.cache/{n}-final-{label}';env=os.environ.copy();env.update({'PLAYWRIGHT_MODULE':str(Path('.cache/microevent-qa/node_modules/playwright-core').resolve()),'QA_BASE_URL':'http://127.0.0.1:5181','QA_NATIVE_RETAINED_RECOVERY':mode,'QA_ARTIFACT_PREFIX':prefix,'OUTPUT':prefix+'.json','QA_SCREENSHOT':prefix+'.png','QA_NATIVE_REPLAY':'true' if label=='fresh' else 'false','QA_NATIVE_DELTA':'false','QA_NATIVE_COLOR':'false','QA_NATIVE_OBSOLETE':'false'})
 command=['.cache/tooling/node20.exe',adapter if label=='fresh' else 'tools/experiments/audit_webgpu_temporal_ground.mjs']
 with open(prefix+'.log','w',encoding='utf-8') as output:code=subprocess.run(command,env=env,stdout=output,stderr=output).returncode
 row={'mode':mode,'label':label,'exitCode':code,'report':prefix+'.json','log':prefix+'.log','command':command};rows.append(row);Path(f'.cache/{n}-final-gpu.json').write_bytes((json.dumps(rows,indent=2)+'\n').encode());print(json.dumps(row),flush=True);verify()
 if code:raise SystemExit(code)
print('Four final GPU cases sequential after CPU/build/supplement;526+4/64native/16foreign exact. Ordinary Worker/UI/producer handoff and cadence still pending.',flush=True)
