from pathlib import Path
n='native-retained-surface-recovery';p=Path('tests/browser/webgpu-temporal-ground-worker.js');s=p.read_bytes().decode();assert p.read_bytes()==Path(f'.cache/{n}-{p.name}.before').read_bytes()
def replace(a,b):
 global s
 assert s.count(a)==1,(a[:80],s.count(a));s=s.replace(a,b)
replace('const errors=[],createdResources=[],ports=[]','const errors=[],createdResources=[],resourceRetirements=[],ports=[]')
replace('const observed=data.nativeDelta?', 'const observed=data.nativeDelta||data.nativeRetainedRecovery?')
replace("label:message.descriptor?.label??null});port.postMessage(message,transfer);", "label:message.descriptor?.label??null,usage:message.descriptor?.usage??null,size:message.descriptor?.size??null,format:message.descriptor?.format??null});if(message.type==='destroy'||message.type==='release')resourceRetirements.push({type:message.type,id:message.id});port.postMessage(message,transfer);")
anchor="  const first=await bridge.mutateNativeWorldAfterGpuQuiescence({getPublication:()=>cohort,mutation:{type:'addChunk',cx:4,cz:4}});"
warm="""  if(data.nativeRetainedRecovery){const deadline=performance.now()+90000;for(;;){const a=surface.preparationStatus.admission,b=surface.settlements.status();if(surface.biomeProps.status().selectableReady&&surface.residency.visualReady()&&b.selectableReady&&b.villageTextured===b.villagePreviews&&!a.active&&!a.queued&&!a.inflightCompiles)break;if(performance.now()>=deadline||errors.length)throw Error('Retained recovery warm owners did not settle '+JSON.stringify({settlements:b,admission:a,errors}));await render();await new Promise(resolve=>setTimeout(resolve,16));}for(let frame=0;frame<3;frame++){await render();await new Promise(resolve=>setTimeout(resolve,16));}await remote.device.queue.onSubmittedWorkDone();}
""".replace('\n','\r\n')
replace(anchor,warm+anchor)
replace("  const checkpoint={session:'ground-native',sequence:1,", "  const checkpointWork=data.nativeRetainedRecovery?surface.agricultureVfx.exportWorkCheckpoint(1,{allowHidden:true}):{version:1,sequence:1,elapsed:10,effects:[]};\r\n  const checkpoint={session:'ground-native',sequence:1,")
replace('workCheckpoint:{version:1,sequence:1,elapsed:10,effects:[]}};', 'workCheckpoint:checkpointWork};')
replace('  let obsolete=null;',Path(f'.cache/{n}-gpu-body.js').read_text().replace('\n','\r\n')+'\r\n  let obsolete=null;')
p.write_bytes(s.encode());print('Existing fixture now exercises actual retained Surface API, source checkpoint/replay, warm owner identities and readonly Host inventory, including effect mismatch rejection and repeated identical recovery.')
