from pathlib import Path
import subprocess,os,json
n='native-retained-surface-recovery';rows=[]
for mode,label in [('readmission','readmission-1'),('negative','negative-1')]:
 prefix=f'.cache/{n}-probe-{label}';env=os.environ.copy();env.update({'PLAYWRIGHT_MODULE':str(Path('.cache/microevent-qa/node_modules/playwright-core').resolve()),'QA_BASE_URL':'http://127.0.0.1:5181','QA_NATIVE_RETAINED_RECOVERY':mode,'QA_ARTIFACT_PREFIX':prefix,'OUTPUT':prefix+'.json'})
 with open(prefix+'.log','w',encoding='utf-8') as log:result=subprocess.run(['.cache/tooling/node20.exe','tools/experiments/audit_webgpu_temporal_ground.mjs'],env=env,stdout=log,stderr=log)
 row={'mode':mode,'label':label,'exitCode':result.returncode,'report':prefix+'.json','log':prefix+'.log'};rows.append(row);Path(f'.cache/{n}-probes.json').write_bytes((json.dumps(rows,indent=2)+'\n').encode());print(json.dumps(row),flush=True)
 if result.returncode:raise SystemExit(result.returncode)
