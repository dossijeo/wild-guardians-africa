from pathlib import Path
n='native-retained-surface-recovery';p=Path(f'.cache/{n}-uniform-debug-audit.mjs');assert not p.exists();s=Path(f'.cache/{n}-diagnostic-audit.mjs').read_text();a="    source+='\\nconst qaRetainedNativeIds=new WeakMap();let qaRetainedNativeNext=0;\\n';";assert s.count(a)==1
helper=Path(f'.cache/{n}-uniform-debug.txt').read_text();insertion="""    const debugFunction=__HELPER__;
    source=source.replace('  function setResource(key, entry) {',debugFunction+'\\n  function setResource(key, entry) {');
    const inspectAnchor="if (message.type === 'inspect') { reply(message, {...api.inspect(),intentControl:routeControl?.status()??null}); return; }";if(source.split(inspectAnchor).length!==2)throw Error('Uniform debug inspect anchor missing');source=source.replace(inspectAnchor,"if (message.type === 'inspect') { qaReadRetainedUniforms().then(qa=>reply(message,{...api.inspect(),qaUniforms:qa,intentControl:routeControl?.status()??null}),error=>reply(message,{...api.inspect(),qaUniformError:String(error.stack??error)})); return; }");
"""
import json
insertion=insertion.replace('__HELPER__',json.dumps(helper));s=s.replace(a,insertion+a);p.write_bytes(s.encode());print('Saved readonly GPU uniform COPY_SRC readback diagnostic;no production changes, separate diagnostic GPU allocations excluded from acceptance.')
