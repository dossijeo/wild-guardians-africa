from pathlib import Path
n='native-retained-surface-recovery';s=Path('tools/experiments/audit_webgpu_temporal_ground.mjs').read_text()
a="   if(name==='host'){"
b="""   if(name==='worker'){
    source+='\\nasync function qaCaptureStage(label){const previous=self.onmessage;try{await new Promise(resolve=>{self.onmessage=({data})=>{if(data.qaStageCaptured===label)resolve();};self.postMessage({qaStage:label});});}finally{self.onmessage=previous;}}\\n';
    source=source.replace('const before=await remote.inspectAsync(),beforeCreated=',\"await qaCaptureStage('before');const before=await remote.inspectAsync(),beforeCreated=\");
    source=source.replace('    const work=surface.agricultureVfx.exportWorkCheckpoint(2,',\"    await qaCaptureStage('recovered');const work=surface.agricultureVfx.exportWorkCheckpoint(2,\");
    source=source.replace('    if(data.nativeRetainedReadmission)',\"    await qaCaptureStage('noop');if(data.nativeRetainedReadmission)\");
   }
"""+a
assert s.count(a)==1;s=s.replace(a,b)
a='  const result=await page.evaluate(({negative,readmission})'
b="  await page.exposeFunction('qaCaptureStage',async label=>{await page.locator('canvas').screenshot({path:prefix+'-stage-'+label+'.png'});});\n"+a
assert s.count(a)==1;s=s.replace(a,b)
a='worker.onmessage=({data})=>{clearTimeout(timer);resolve(data);};'
b="worker.onmessage=async({data})=>{if(data.qaStage){await window.qaCaptureStage(data.qaStage);worker.postMessage({qaStageCaptured:data.qaStage});return;}clearTimeout(timer);resolve(data);};"
assert s.count(a)==1;s=s.replace(a,b)
Path(f'.cache/{n}-stage-debug-audit.mjs').write_bytes(s.encode())
print('Three stage screenshots on same retained Surface;diagnostic synchronization only.')
