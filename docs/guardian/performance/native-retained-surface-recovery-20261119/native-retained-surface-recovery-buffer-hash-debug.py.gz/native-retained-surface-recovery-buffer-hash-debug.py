from pathlib import Path
import json
n='native-retained-surface-recovery';p=Path(f'.cache/{n}-buffer-hash-debug-audit.mjs');assert not p.exists();s=Path(f'.cache/{n}-full-uniform-debug-audit.mjs').read_text();start=s.index('    const debugFunction=');end=s.index(';\n    source=source.replace',start);s=s[:start]+'    const debugFunction='+json.dumps(Path(f'.cache/{n}-buffer-hash-debug.txt').read_text())+s[end:];p.write_bytes(s.encode());print('Saved COPY_SRC hash of all live buffers, plus full uniform values;diagnostic readback only.')
