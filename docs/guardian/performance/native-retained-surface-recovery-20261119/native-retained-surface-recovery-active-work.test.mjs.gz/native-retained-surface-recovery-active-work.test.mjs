import test from 'node:test';
import assert from 'node:assert/strict';
import {createNativeVfx} from '../src/rendering/vfx-native.js';
import {assertRetainedTemporalPresentation} from '../src/rendering/temporal-surface-recovery.js';

for(const [id,extra] of [['dig',{}],['water',{}],['harvest',{}],['dust',{stepMode:true}]])test(`retained ${id} keeps actual active work particles, rigid bodies, clock and RNG without import`,()=>{
 let x=0;const source=createNativeVfx(id,{}, {...extra,surface:(a,b)=>.02*a+.01*b,waterSource:()=>({position:[x,1.2,0],direction:[.4,0,.9]})});source.advance(.9);x=.2;source.advance(.3);const native=source.exportWorkCheckpoint();assert(native.parts.length+native.rigids.length>0,'actual work effect must be active');
 const presentation={version:1,sequence:1,elapsed:1.2,guardian:{active:null},blessing:{pending:[]},agriculture:{eventWindow:{events:[]}}},makeWork=()=>({version:1,sequence:1,elapsed:1.2,effects:[{key:id,id,x:0,y:0,z:0,yaw:0,terrainDependencies:[[0,0]],native:source.exportWorkCheckpoint()}]}),message={sequence:1,elapsed:1.2,presentationCheckpoint:structuredClone(presentation),workCheckpoint:makeWork()};
 assert.equal(assertRetainedTemporalPresentation(message,{presentation,work:makeWork()}),true);assert.deepEqual(source.exportWorkCheckpoint(),native);
 for(const mutate of [value=>value.seed^=1,value=>value.eventIndex++,value=>value.clock+=.01]){const changed=structuredClone(message);mutate(changed.workCheckpoint.effects[0].native);assert.throws(()=>assertRetainedTemporalPresentation(changed,{presentation,work:makeWork()}),/work checkpoint differs/);assert.deepEqual(source.exportWorkCheckpoint(),native);}
 source.advance(.05);assert.throws(()=>assertRetainedTemporalPresentation(message,{presentation,work:makeWork()}),/work checkpoint differs/);
});
