from pathlib import Path
n='native-retained-surface-recovery'
s=Path(f'.cache/{n}-binding-debug-audit.mjs').read_text()
a="    const nativeBindCapture="
i=s.index(a)
hook="""    source=source.replace('  function applyQueue(op, replay = false, initialized = false) {','  const qaPassUniforms=[];\\n  function applyQueue(op, replay = false, initialized = false) {');
    source=source.replace("      return buffers.length > 0;",`      if(active&&resolutionResources){const uniforms=[...resolutionResources.values()].filter(entry=>entry.uniformShadow).map(entry=>({id:entry.id,data:Array.from(new Float32Array(entry.uniformShadow.buffer,entry.uniformShadow.byteOffset,entry.uniformShadow.byteLength/4))}));qaPassUniforms.push({sequence:active.sequence,world:active.metadata?.nativeWorldBoundary??null,uniforms});if(qaPassUniforms.length>3)qaPassUniforms.shift();}return buffers.length > 0;`);
"""
s=s[:i]+hook+s[i:]
a='inspect: () => ({ qaActiveResources:'
assert s.count(a)==1
s=s.replace(a,'inspect: () => ({ qaPassUniforms:qaPassUniforms.slice(), qaActiveResources:')
Path(f'.cache/{n}-pass-debug-audit.mjs').write_bytes(s.encode())
print('Diagnostic CPU shadow read sets immediately at each actual submission, no queue order changed.')
