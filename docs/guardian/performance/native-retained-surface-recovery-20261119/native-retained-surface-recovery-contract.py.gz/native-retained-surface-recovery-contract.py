from pathlib import Path
n='native-retained-surface-recovery';p=Path('src/rendering/temporal-surface-recovery.js');s=p.read_bytes().decode();assert p.read_bytes()==Path(f'.cache/{n}-{p.name}.before').read_bytes()
helper="""// Compare the existing checkpoint DTOs, preserving ordered histories and every
// own field. Keys may be serialized in a different order. No owner is restored.
function sameCheckpointDto(a,b){
 if(a===null||b===null)return a===b;
 if(typeof a!=='object'||typeof b!=='object')return a===b&&!['function','symbol','bigint'].includes(typeof a)&&(typeof a!=='number'||Number.isFinite(a));
 const array=Array.isArray(a);if(array!==Array.isArray(b)||array&&a.length!==b.length)return false;
 if(!array&&[a,b].some(value=>![Object.prototype,null].includes(Object.getPrototypeOf(value))))return false;
 const keys=Object.keys(a);return keys.length===Object.keys(b).length&&keys.every(key=>Object.hasOwn(b,key)&&sameCheckpointDto(a[key],b[key]));
}
export function assertRetainedTemporalPresentation(message,{presentation,work=null}={}){
 if(!Number.isSafeInteger(message?.sequence)||message.sequence<0||!Number.isFinite(message.elapsed)||message.elapsed<0||presentation?.version!==1||presentation.sequence!==message.sequence||presentation.elapsed!==message.elapsed)throw Error('Retained presentation checkpoint boundary mismatch');
 const expected=message.presentationCheckpoint??message.workCheckpoint?.presentation;
 if(!expected||!sameCheckpointDto(expected,presentation))throw Error('Retained presentation checkpoint differs from current effects');
 const expectedWork=message.workCheckpoint;
 if(expectedWork===undefined){if(work!==null)throw Error('Retained work checkpoint unavailable');return true;}
 if(!expectedWork||typeof expectedWork!=='object'||Array.isArray(expectedWork)||work?.version!==1||work.sequence!==message.sequence||work.elapsed!==message.elapsed)throw Error('Retained work checkpoint boundary mismatch');
 const {presentation:embedded,...payload}=expectedWork;
 if(embedded!==undefined&&!sameCheckpointDto(embedded,presentation)||!sameCheckpointDto(payload,work))throw Error('Retained work checkpoint differs from current effects');
 return true;
}
"""
anchor='export function createTemporalSurfaceRecovery';assert s.count(anchor)==1;s=s.replace(anchor,helper+'\n'+anchor)
for a,b in [
 ('async function restoreTimelineCheckpoint(message,{signal}={}){if(phase',"async function restoreTimelineCheckpoint(message,{signal,retainCurrent:retained=retainCurrent}={}){if(typeof retained!=='boolean'||retained&&typeof stream?.beginTimelineReplay!=='function')throw TypeError('Invalid retained temporal recovery mode');if(phase"),
 ("phase!=='checkpoint'&&(!retainCurrent||phase!=='live')", "phase!=='checkpoint'&&(!retained||phase!=='live')"),
 ('check(signal);validateCheckpoint(message);const recoveryOptions={signal,...(retainCurrent?{retainCurrent:true}:{})},sourceEpoch=retainCurrent?', 'check(signal);const recoveryOptions={signal,...(retained?{retainCurrent:true}:{})};validateCheckpoint(message,recoveryOptions);const sourceEpoch=retained?'),
 ('?.epoch:null;if(retainCurrent)', '?.epoch:null;if(retained)'),
 ('check(signal);validateCheckpoint(message);if(!prepared', 'check(signal);validateCheckpoint(message,recoveryOptions);if(!prepared'),
 ("typeof prepared.epoch!=='string'||retainCurrent&&", "typeof prepared.epoch!=='string'||retained&&"),
 ("if(!retainCurrent)terrain.beginReplay", "if(retained)validateCheckpoint(message,recoveryOptions);if(!retained)terrain.beginReplay"),
 ("await onCheckpoint(message,prepared,recoveryOptions);check(signal);phase='replay'", "await onCheckpoint(message,prepared,recoveryOptions);check(signal);if(retained)validateCheckpoint(message,recoveryOptions);phase='replay'")]:
 assert s.count(a)==1,(a,s.count(a));s=s.replace(a,b)
p.write_bytes(s.encode());print('Added strict presentation/work comparison and per-attempt retention with post-commit/post-admission state rechecks.')
