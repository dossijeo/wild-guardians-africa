from pathlib import Path
import json,hashlib,subprocess,os,sys
n='native-retained-surface-recovery';read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();write=lambda p,v:Path(p).write_bytes((json.dumps(v,indent=2)+'\n').encode())
old=read(f'.cache/{n}-tested-hashes.json');inputs={p:sha(p) for p in old};changed=[p for p in old if old[p]!=inputs[p]];assert sorted(changed)==sorted(['tests/browser/webgpu-temporal-ground-worker.js','tools/experiments/audit_webgpu_temporal_ground.mjs']);write(f'.cache/{n}-verified-hashes.json',inputs)
native=read(f'.cache/{n}-pre-built-hashes.json');foreign=read(f'.cache/{n}-pre-preserved-hashes.json');extra=read(f'.cache/{n}-active-work-inputs.json')
def verify():assert all(sha(p)==h for m in [inputs,native,foreign,extra] for p,h in m.items())
verify();print('Only two QA inputs changed after 3954/3955 regression and build48.72; production and CPU tests exact. Current526 inputs frozen.',flush=True)
for p in read(f'.cache/{n}-owned-files.json'):
 r=subprocess.run(['.cache/tooling/node20.exe','--check',p],capture_output=True);assert r.returncode==0
env=os.environ.copy();env['WILD_ENGINE_NATIVE_ROUTE_WASM']=str(Path('src/world/wild-engine/spatial-savanna.wasm').resolve());env['WILD_ENGINE_SPATIAL_SERVICES_WASM']=env['WILD_ENGINE_NATIVE_ROUTE_WASM']
for label,files in [('verified-focused',read(f'.cache/{n}-focused-files.json')),('verified-work',[f'.cache/{n}-active-work.test.mjs','tests/work-vfx-checkpoint.test.js'])]:
 with open(f'.cache/{n}-{label}.log','w',encoding='utf-8') as log:r=subprocess.run(['.cache/tooling/node20.exe','--test',*files],env=env,stdout=log,stderr=log)
 print(label,r.returncode,flush=True);assert r.returncode==0;verify()
s=Path('tools/experiments/audit_webgpu_temporal_ground.mjs').read_text();anchor="await page.goto((process.env.QA_BASE_URL??'http://127.0.0.1:5200')+'/ground-qa');";assert s.count(anchor)==2
hook="""await page.route('**/tests/browser/webgpu-temporal-ground-worker.js*',async route=>{const response=await route.fetch();let source=await response.text();const anchor='adapter:inspection.consumer.adapterInfo,checkpointWorld:';if(source.split(anchor).length!==2)throw Error('Readonly fresh resource counter anchor missing');source=source.replace(anchor,'adapter:inspection.consumer.adapterInfo,resourcesCreated:remote.inspect().resourcesCreated,checkpointWorld:');await writeFile(process.env.QA_ARTIFACT_PREFIX+'-worker-served.js',source,{flag:'wx'});await route.fulfill({response,body:source});});"""
adapter=f'.cache/{n}-verified-fresh-audit.mjs';assert not Path(adapter).exists();Path(adapter).write_bytes(s.replace(anchor,hook+anchor,1).encode())
rows=[]
for mode,label in [('true','positive'),('readmission','readmission'),('negative','negative'),('false','fresh')]:
 prefix=f'.cache/{n}-verified-{label}';gpuenv=env.copy();gpuenv.update({'PLAYWRIGHT_MODULE':str(Path('.cache/microevent-qa/node_modules/playwright-core').resolve()),'QA_BASE_URL':'http://127.0.0.1:5181','QA_NATIVE_RETAINED_RECOVERY':mode,'QA_ARTIFACT_PREFIX':prefix,'OUTPUT':prefix+'.json','QA_SCREENSHOT':prefix+'.png','QA_NATIVE_REPLAY':'true' if label=='fresh' else 'false','QA_NATIVE_DELTA':'false','QA_NATIVE_COLOR':'false','QA_NATIVE_OBSOLETE':'false'})
 command=['.cache/tooling/node20.exe',adapter if label=='fresh' else 'tools/experiments/audit_webgpu_temporal_ground.mjs']
 with open(prefix+'.log','w',encoding='utf-8') as log:code=subprocess.run(command,env=gpuenv,stdout=log,stderr=log).returncode
 row={'mode':mode,'label':label,'exitCode':code,'report':prefix+'.json','log':prefix+'.log','command':command};rows.append(row);write(f'.cache/{n}-verified-gpu.json',rows);print(json.dumps(row),flush=True);verify()
 if code:raise SystemExit(code)
print('Verified four sequential GPU cases, actual disposal/drain, production unchanged,526+4/64/16 exact. Current retained PNG checks include worker bounds and blank rejection.',flush=True)
