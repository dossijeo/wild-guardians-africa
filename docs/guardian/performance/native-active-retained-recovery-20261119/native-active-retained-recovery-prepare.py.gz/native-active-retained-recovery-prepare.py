from pathlib import Path
import json,hashlib,subprocess
n='native-active-retained-recovery';read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
def write(p,v):Path(p).write_bytes((json.dumps(v,indent=2)+'\n').encode())
assert subprocess.check_output(['git','rev-parse','HEAD']).strip()==b'63cef06bbc6641911136b01ad4f3de302577bf4e'
for label in ['pre-built-hashes','pre-preserved-hashes']:
 m=read('.cache/native-quiescence-failure-'+label+'.json')
 for p,h in m.items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h,p
 write('.cache/'+n+'-'+label+'.json',m)
write('.cache/'+n+'-owned-files.json',['tests/browser/native-active-retained-recovery.js','tools/experiments/audit_native_active_retained_recovery.mjs'])
for name in ['CURRENT-STATUS.md','MIGRATION-OBJECTIVE.md','A6-CHECKLIST.md','integrated-gpu-migration-plan-20261104.md']:Path('.cache/'+n+'-'+name+'.before').write_bytes(Path('docs/guardian/'+name).read_bytes())
research=read('.cache/native-retained-handoff-research.json')['babylon'];assert hashlib.sha256(Path(research['snapshot']['source']).read_bytes()).hexdigest()==research['snapshot']['sha256']
write('.cache/'+n+'-decision.json',{'scope':'Before ordinary main resource attachment: actual hardware evidence for existing automatic host/native checkpoint and retained Surface recovery,not a new production architectural mechanism.','reference':research,'symbolsRead':['enabled setter40–51','reset113 onward'],'adaptation':'Same alreadyimplemented lifetime separation:invalidate recordings and transport witnesses whilekeepinghealthyGPUengine resources. Exerciseexisting sourcefloor/ACK/hold/replay/activate APIs through actualhost/source/world/drawWorkers;no ABI/page-side simulationclock,newworld/owner/dependency/queue. Existing instrumented native-worker-world-audit-worker reads factory/nativebuffer/rig/owners;readonlyserverroutehooks observe actualnativeGPUobjects and existingownedSurfaceidentities. No event/ACK/resource/clock substituted.','knownLimits':'Initialcasepausedbutactualboundnativecohort;movingcaseplanned separately. Restoredsemantic WALK source fixtureonly supported domain;no ordinaryfullmain/deviceloss/deadconsumer/platform/cadence acceptance. Any newlyadmitted effects separatelyaccounted,neverclaim3123rebuild or allscenezeroallocation withoutproof. FirstpilotfailedonlyViteserved-formatinstrumentationanchorbeforeauthoritycreation;retainedasintermediatefailure.'})
print('Prepared active-native GPU audit;64native/16foreign exact;2newowned paths;actualBabylon codeSHAverified.')
