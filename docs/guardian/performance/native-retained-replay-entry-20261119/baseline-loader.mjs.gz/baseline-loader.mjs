import {readFile} from 'node:fs/promises';
const names=['confirmed-presentation-stream.js','confirmed-terrain-receiver.js','terrain-history-receiver.js','temporal-surface-recovery.js'];
export async function load(url,context,nextLoad){for(const name of names)if(url.endsWith('/src/rendering/'+name))return {format:'module',source:await readFile('.cache/native-retained-replay-entry-'+name+'.before','utf8'),shortCircuit:true};return nextLoad(url,context);}
