import fs from 'node:fs';
const file='src/simulation/native-intent-control-publication.js',before=fs.readFileSync(file),events=[];let f;
globalThis.__debugClock=value=>events.push(value);
fs.writeFileSync(file,before.toString().replace("throw Error('Native clock publication lost causal order');","{globalThis.__debugClock?.({record,sentSequence,clock,baseline,stack:new Error().stack});throw Error('Native clock publication lost causal order');}"));
try{
 const {nativeFarmAuthoritySave}=await import('../tests/helpers/native-farm-authority-save.js'),{nativeProductionAuthority,untilProduction}=await import('../tests/helpers/native-production-authority.js'),{PROFILES}=await import('../src/simulation/workforce.js');
 const saved=nativeFarmAuthoritySave({configureState(state){state.time=PROFILES.find(p=>p.id===state.workers[0].profile).end-.01;}});f=await nativeProductionAuthority(saved.state);await untilProduction(f,()=>f.records.some(r=>r.kind==='farm-arrival'&&r.committed));let error;
 try{for(let i=0;i<80&&!f.faults.length&&!f.records.some(r=>r.kind==='home-route'&&r.committed);i++){f.advance();await f.present();}}catch(e){error=e.stack;}
 const result={events,error,faults:f.faults,status:f.authority.nativeIntentProductionStatus(),records:f.records.map(r=>({kind:r.kind,committed:r.committed}))};fs.writeFileSync('.cache/native-farm-restored-authority-clock-debug.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));
}finally{await f?.close();fs.writeFileSync(file,before);}
