from pathlib import Path
import datetime,hashlib,json,os,re,subprocess,time

root=Path.cwd()
read=lambda p:json.loads(Path(p).read_bytes())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
prior=read('.cache/native-task-stop-graphics-validation.json')
native=prior['nativeBuild']
base=prior
selector=re.compile(r'(stop-(admission|control|ports|remote)|native.*(quiesce|intent-control|resource-admission|opportunity)|native-(task-start|home-route|farm-arrival|idle-stroll)-(remote|admission)|native-task-route-stop-source)')
tests=sorted(p.as_posix() for p in Path('tests').glob('*.test.js') if selector.search(p.name))
prior['files']=list(prior['frozenInputs'])
files=sorted(set(tests)|{p for p in prior['files'] if Path(p).is_file()})
frozen={p:sha(p) for p in files}
receipt={'scope':'Task25 authority admission and direct control publication, exact resource/pose translation and neighboring prepared motion regressions. Production build. No physical GPU.',
 'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'at':now(),
 'nativeBuild':native,'nativeBuiltInputs':native['nativeBuiltInputs'],'preservedFiles':base['preservedFiles'],
 'externalCommittedInputs':base['externalCommittedInputs'],'frozenInputs':frozen,'testFiles':tests,'jobs':{}}
path=Path('.cache/native-task-stop-admission-validation.json')
def save():path.write_text(json.dumps(receipt,ensure_ascii=True,indent=2)+'\n',encoding='utf-8')
common={'WILD_ENGINE_NATIVE_ROUTE_WASM':str(root/'src/world/wild-engine/spatial-savanna.wasm'),'WILD_ENGINE_SPATIAL_SERVICES_WASM':str(root/'src/world/wild-engine/spatial-savanna.wasm')}
commands=[('tests',['.cache/tooling/node20.exe','--test','--test-concurrency=4',*tests],common),('build',['.cache/tooling/node20.exe','node_modules/vite/bin/vite.js','build'],{**common,'VITE_PRESENTATION_BACKEND':'webgpu-worker','VITE_WEBGPU_REMOTE_DRAW':'true'})]
running={}
for label,argv,env in commands:
 log=Path(f'.cache/native-task-stop-admission-{label}.log');stream=log.open('wb');process=subprocess.Popen(argv,cwd=root,env={**os.environ,**env},stdout=stream,stderr=subprocess.STDOUT)
 running[label]=(process,stream,time.monotonic())
 receipt['jobs'][label]={'command':argv,'environment':env,'log':log.as_posix(),'pid':process.pid,'startedAt':now()}
save();print(json.dumps({k:v['pid'] for k,v in receipt['jobs'].items()}),flush=True)
while running:
 for label,(process,stream,start) in list(running.items()):
  code=process.poll()
  if code is None:continue
  stream.close();del running[label];job=receipt['jobs'][label]
  job.update(exitCode=code,completionObservedAt=now(),secondsUntilCompletionObserved=time.monotonic()-start,logSha256=sha(job['log']))
  log=Path(job['log']).read_text(encoding='utf-8',errors='replace')
  if label=='tests':
   for key in ['tests','pass','fail','cancelled','skipped']:
    matches=re.findall(r'^# '+key+r' (\d+)\s*$',log,re.M);job[key]=int(matches[-1]) if matches else None
  else:job['vitePhaseText']=re.findall(r'built in ([^\r\n]+)',log)[-1:]
  save();print(json.dumps({k:job.get(k) for k in ['log','exitCode','tests','pass','fail','cancelled','skipped','vitePhaseText']}),flush=True)
 time.sleep(.25)
receipt['changed']={g:[p for p,h in receipt[g].items() if not Path(p).is_file() or sha(p)!=h] for g in ['frozenInputs','nativeBuiltInputs','preservedFiles','externalCommittedInputs']}
receipt['finishedAt']=now();save();assert not any(receipt['changed'].values()),receipt['changed'];assert all(v['exitCode']==0 for v in receipt['jobs'].values())
