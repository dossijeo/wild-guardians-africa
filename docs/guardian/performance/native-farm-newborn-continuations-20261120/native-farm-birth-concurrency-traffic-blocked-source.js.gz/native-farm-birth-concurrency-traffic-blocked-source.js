import test from 'node:test';
import assert from 'node:assert/strict';
import {rational} from '../src/simulation/money.js';
import {nativeFarmAuthoritySave} from './helpers/native-farm-authority-save.js';
import {nativeProductionAuthority,untilProduction} from './helpers/native-production-authority.js';

const actor=w=>Number(w.id.split('-').at(-1)),pose=w=>Object.fromEntries(['x','z','heading','runPhase','walkPhase','carryPhase','runRemaining'].map(k=>[k,w[k]]));
for(const selection of [{youngFemale:2},{youngFemale:1,olderMale:1}])test(`ordinary batch ${JSON.stringify(selection)} completes both first admissions after one genuine READY wait`,async()=>{
 const {state}=nativeFarmAuthoritySave({profile:'youngFemale',approach:true,configureState(s){const w=s.workers[0];s.hiringPaidDay=s.day;s.ledger.balance=rational(100000);s.villages.find(v=>v.id===w.villageId).entry={x:w.x,z:w.z+6};}}),oldId=state.workers[0].id;
 let release;const held=new Promise(r=>release=r);let retained=null;
 const f=await nativeProductionAuthority(state,{async onReady(record){if(record.kind==='farm-arrival'&&record.resources.nativeFarmArrival.actorId!==actor(state.workers[0])&&!retained){retained=record;await held;}}});
 try{
  await untilProduction(f,()=>f.records.some(r=>r.kind==='farm-arrival'&&r.committed));const before=f.snapshot(),result=f.command({kind:'hireAdditional',id:'batch-'+JSON.stringify(selection),selection,centerId:before.workers[0].centerId});assert.equal(result.value,true,result.rejection);
  const born=JSON.parse(result.snapshot).workers.filter(w=>w.id!==oldId);assert.equal(born.length,2);assert.deepEqual(JSON.parse(result.snapshot).workers[0],before.workers[0]);
  for(let i=0;i<800&&!retained;i++){f.advance(.02);await f.present();assert.deepEqual(f.faults,[]);}assert(retained,JSON.stringify(f.authority.nativeIntentProductionStatus()));assert.equal(retained.resources.nativeFarmArrival.bodyId,2);
  const waiting=f.snapshot();for(let i=0;i<12;i++){f.advance(.05);await f.present();}
  const pending=f.snapshot();assert.notDeepEqual(pose(pending.workers.find(w=>w.id===oldId)),pose(waiting.workers.find(w=>w.id===oldId)));
  for(const w of born){const current=pending.workers.find(v=>v.id===w.id);assert.deepEqual(pose(current),pose(w));assert.equal(current.nativeRouteAdmission,'pending-farm-arrival-resources');}
  assert.equal(f.records.filter(r=>r.kind==='farm-arrival'&&born.some(w=>actor(w)===r.resources.nativeFarmArrival.actorId)).length,1);
  release();
  for(let i=0;i<800&&!born.every(w=>f.records.some(r=>r.kind==='farm-arrival'&&r.resources.nativeFarmArrival.actorId===actor(w)&&r.committed));i++){f.advance(.02);await f.present();assert.deepEqual(f.faults,[]);}
  const records=born.map(w=>f.records.filter(r=>r.kind==='farm-arrival'&&r.resources.nativeFarmArrival.actorId===actor(w)&&r.committed));assert(records.every(r=>r.length===1),JSON.stringify({production:f.authority.nativeIntentProductionStatus(),workers:f.snapshot().workers.map(w=>({id:w.id,x:w.x,z:w.z,status:w.status,admission:w.nativeRouteAdmission})),records:f.records.map(r=>({kind:r.kind,committed:r.committed,aborted:r.aborted,actor:r.resources.nativeFarmArrival?.actorId,body:r.resources.nativeFarmArrival?.bodyId}))}));
  assert.deepEqual(records.map(r=>r[0].resources.nativeFarmArrival.bodyId).sort(),[2,3]);assert.equal(records[0][0].resources.nativeFarmArrival.worldBoundary.authorityEpoch,records[1][0].resources.nativeFarmArrival.worldBoundary.authorityEpoch);
  assert.deepEqual(f.faults,[]);assert.deepEqual(f.errors,[]);
 }finally{release();await f.close();}
});
