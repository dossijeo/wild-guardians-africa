import fs from 'node:fs';import crypto from 'node:crypto';import assert from 'node:assert/strict';
const n='native-farm-moving-game',base=JSON.parse(fs.readFileSync('.cache/'+n+'-baseline.json')),manifest='.cache/'+n+'-owned-files.json',owned=JSON.parse(fs.readFileSync(manifest)),names=['native-farm-arrival-route-admission','native-farm-arrival-route-control','native-farm-arrival-route-data','native-farm-arrival-route-graphics','native-farm-arrival-route-remote','native-farm-arrival-route-source','native-farm-arrived-task-source','native-farm-moving-task-control','native-farm-moving-task-source'];
for(const name of names){const p='tests/'+name+'.test.js',b=fs.readFileSync(p);assert.equal(crypto.createHash('sha256').update(b).digest('hex'),base.testedInputs[p],p);assert(!owned.includes(p));fs.copyFileSync(p,'.cache/'+n+'-'+name+'.test.js.before');owned.push(p);}
fs.writeFileSync(manifest,JSON.stringify(owned,null,2)+'\n');
function replace(s,a,b,p,count=1){assert.equal(s.split(a).length-1,count,p+' '+a);return s.split(a).join(b);}
for(const name of names){const p='tests/'+name+'.test.js';let s=fs.readFileSync(p,'utf8').replaceAll('\r\n','\n');
 if(name.includes('arrival-route-')){
  const a=name.endsWith('-source')?'assert.equal(f.w.nav_intent_game_execution_state(),-1)':'assert.equal(f.planner.nativeGameExecutionState(),-1)';s=replace(s,a,a.replace(',-1)',',1)'),p,name.endsWith('-data')?2:1);
  if(name.endsWith('-admission'))s=replace(s,"assert.throws(()=>tick(f.state,.1,f.nav),/intention class/);assert.equal(f.state.elapsed,at);f.move(.1);","tick(f.state,.1,f.nav);assert.equal(f.state.elapsed,at+.1);",p);
 }else if(name==='native-farm-arrived-task-source'){
  s=replace(s,"assert.throws(()=>f.planner.commitTaskBatchToState(f.state,rows,{navVersion:1,pendingResources}),/became stale/);","if(pendingResources)assert.equal(f.planner.commitTaskBatchToState(f.state,rows,{navVersion:1,pendingResources}),0);else assert.throws(()=>f.planner.commitTaskBatchToState(f.state,rows,{navVersion:1,pendingResources}),/became stale/);",p);
 }else if(name==='native-farm-moving-task-control'){
  s=replace(s,"assert.throws(()=>f.planner.commitTaskBatchToState(f.state,rows,{navVersion:1,pendingResources:true}),/became stale/);","assert.equal(f.planner.commitTaskBatchToState(f.state,rows,{navVersion:1,pendingResources:true}),0);",p);
 }else{
  s=replace(s,"assert.throws(()=>f.planner.commitTaskBatchToState(f.state,retry,{navVersion:1,pendingResources:true}),/became stale/);","assert.equal(f.planner.commitTaskBatchToState(f.state,retry,{navVersion:1,pendingResources:true}),0);",p);
 }
 fs.writeFileSync(p,s);
}
fs.writeFileSync('.cache/'+n+'-updated-contract-files.json',JSON.stringify(owned.filter(p=>p.startsWith('tests/')&&p.endsWith('.test.js')),null,2)+'\n');console.log({updatedAdditionalFiles:names.length,modifiedTestFiles:owned.filter(p=>p.endsWith('.test.js')).length});
