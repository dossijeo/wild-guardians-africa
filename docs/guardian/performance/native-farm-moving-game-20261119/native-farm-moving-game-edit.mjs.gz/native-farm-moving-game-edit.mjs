import fs from 'node:fs';
function edit(p,changes){let s=fs.readFileSync(p,'utf8').replaceAll('\r\n','\n');for(const [a,b]of changes){if(s.split(a).length!==2)throw Error('Expected one anchor: '+p+' '+a.slice(0,65));s=s.replace(a,b);}fs.writeFileSync(p,s);}
if(false)edit('src/simulation/game.js',[
 ["import {nativeFarmArrivalState,nativeFarmArrivalExecutionState,nativeFarmArrivalHeldState,nativeFarmArrivalTerminalState}","import {nativeFarmArrivalState,nativeFarmArrivalExecutionState,nativeFarmArrivalHeldState,nativeFarmArrivalTerminalState,nativeFarmArrivalBoundState}"],
 [":already?nativeFarmArrivalHeldState(s,w):nativeFarmArrivalExecutionState(s,w);",":already?nativeFarmArrivalHeldState(s,w):nativeFarmArrivalBoundState(s,w);"],
 [":execution.arrived===true&&execution.running===false&&execution.currentSpeed===0&&execution.executedThrough>=r.endTime?nativeFarmArrivalTerminalState(s,w):nativeFarmArrivalExecutionState(s,w),h=",":nativeFarmArrivalBoundState(s,w),h="],
 ["if(w.status==='arriving'&&(w.nativeRouteAdmission==='native-farm-arrival-held'||nativeCompletedFarmArrival(w,planner)))planner.requestNativeFarmHome(s,w);","if(w.status==='arriving'&&w.nativeRouteAdmission==='native-farm-arrival'&&!nativeCompletedFarmArrival(w,planner)){if(planner.nativeWorkerTaskEligible?.(w.id))notifyWorkerPlanningChange(s,w);}\n    else if(w.status==='arriving'&&(w.nativeRouteAdmission==='native-farm-arrival-held'||nativeCompletedFarmArrival(w,planner)))planner.requestNativeFarmHome(s,w);"],
 ["w.status==='arriving'&&!w.taskId&&!!nativeCompletedFarmArrival(w,planner)||","w.status==='arriving'&&!w.taskId&&w.nativeRouteAdmission==='native-farm-arrival'&&!!planner.nativeFarmArrivalRouteExecution?.(w.id)||"],
 ["if(w.nativeRouteAdmission==='native-farm-arrival'){if(!nativeExecutionActive||!nativeCompletedFarmArrival(w,nav.intentTaskPlanner)||!nav.intentTaskPlanner.projectNativeFarmArrivalExecution(s,w))throw Error('Farm arrival requires its actual completed native body');continue;}","if(w.nativeRouteAdmission==='native-farm-arrival'){if(!nativeExecutionActive||!nav.intentTaskPlanner.projectNativeFarmArrivalExecution(s,w))throw Error('Farm arrival requires its actual native body');continue;}"],
 ["if(worker.nativeRouteAdmission==='native-farm-arrival-held'&&!nav.intentTaskPlanner?.projectNativeFarmArrivalExecution(s,worker))", "if(worker.nativeRouteAdmission==='native-farm-arrival'&&!nav.intentTaskPlanner?.projectNativeFarmArrivalExecution(s,worker))throw Error('Farm arrival has no current native body owner');\n      if(worker.nativeRouteAdmission==='native-farm-arrival-held'&&!nav.intentTaskPlanner?.projectNativeFarmArrivalExecution(s,worker))"],
 ["!(nativeCompletedFarmArrival(w,nav.intentTaskPlanner)&&nav.intentTaskPlanner.projectNativeFarmArrivalExecution(s,w))", "!(w.nativeRouteAdmission==='native-farm-arrival'&&nav.intentTaskPlanner.projectNativeFarmArrivalExecution(s,w))"]
]);
edit('src/world/wild-engine/spatial-intent-bridge.js',[
 ["import {nativeFarmArrivalState,nativeFarmArrivalExecutionState,nativeFarmArrivalHeldState,nativeFarmArrivalTerminalState}","import {nativeFarmArrivalState,nativeFarmArrivalExecutionState,nativeFarmArrivalHeldState,nativeFarmArrivalTerminalState,nativeFarmArrivalBoundState}"],
 ["const applyEvents=(state,events)=>{\n    lastPlan=null;lastPlanFacts=null;","const applyEvents=(state,events)=>{\n    if(lastPlan?.some(row=>row.status===1))dirty=true;\n    lastPlan=null;lastPlanFacts=null;"],
 ["const assignments=[];\n    for(const row of plan){", "const assignments=[];let awaitingFarmStop=false;\n    for(const row of plan){"],
 ["const fact=lastPlanFacts.get(task.id);", "const farm=pendingResources&&worker.nativeRouteAdmission==='native-farm-arrival'?bridge.nativeFarmArrivalRouteExecution(worker.id):null,stopping=!!farm&&!(farm.arrived&&farm.running===false&&farm.currentSpeed===0&&farm.executedThrough>=farm.binding.reference.endTime);\n      if(stopping)awaitingFarmStop=true;\n      const fact=lastPlanFacts.get(task.id);"],
 ["workerRow(worker,state)[6]!==1)\n        throw Error('Native proposal inputs changed before commit');", "workerRow(worker,state)[6]!==1&&!stopping)\n        throw Error('Native proposal inputs changed before commit');"],
 ["// Validate the JS side before committing WASM. A stale native revision", "// The existing native batch owns the choice while stop24 prepares. Do not\n    // exclude a moving Farm candidate, claim its task early or copy a queue.\n    // Its real stop notification invalidates this proposal and wakes replanning.\n    if(awaitingFarmStop)return 0;\n    // Validate the JS side before committing WASM. A stale native revision"],
 ["const wasDirty=dirty;\n    const eligibilityChanged=events.some", "const wasDirty=dirty||!!lastPlan?.some(row=>row.status===1);\n    const eligibilityChanged=events.some"],
 ["commitTaskBatchToState,\n    registerAttackIntent:", "commitTaskBatchToState,nativeFarmArrivalStopRequest,nativeWorkerTaskEligible:actorId=>eligible.has(numericId(actorId)),\n    registerAttackIntent:"],
 ["const requestNativeFarmHome=(state,worker)=>{", `const nativeFarmArrivalStopRequest=actorId=>{
    const state=observedTaskState??sourceState,worker=state?.workers.find(w=>numericId(w.id)===numericId(actorId));
    if(!worker||worker.nativeRouteAdmission!=='native-farm-arrival')return null;
    const execution=bridge.nativeFarmArrivalRouteExecution(actorId);
    if(!execution||execution.arrived&&execution.running===false&&execution.currentSpeed===0&&execution.executedThrough>=execution.binding.reference.endTime)return null;
    const semantic=nativeFarmArrivalBoundState(state,worker),q=execution.binding.reference.sourceRequest;
    if(execution.executedThrough!==state.elapsed||Object.keys(semantic.pose).some(k=>semantic.pose[k]!==execution[k])||Object.keys(semantic.goal).some(k=>semantic.goal[k]!==q.goal[k]))throw Error('Farm stop request differs from its executed Game source');
    const binding=execution.binding;
    if(contractExpired(worker,state)||state.time>=(profileEnd.get(worker.profile)??0))return Object.freeze({reason:'home',taskId:null,binding});
    if(dirty||pendingTaskEvents.length||pendingWorldEvents.length||!lastPlan)return null;
    const row=lastPlan.find(r=>r.status===1&&r.workerId===numericId(actorId)),task=row&&state.tasks.find(t=>numericId(t.id)===row.taskId),fact=task&&lastPlanFacts?.get(task.id),target=task&&taskTargetLookup(state)(task.targetId);
    if(!task||task.workerId||!fact||!target||'alive' in target&&!target.alive||'delivered' in target&&target.delivered||task.kind==='repair'&&target.hp>=target.maxHp||workerRow(worker,state)[6]!==1||fact.workerId!==worker.id||fact.targetId!==task.targetId||fact.centerId!==task.centerId||fact.kind!==task.kind||fact.targetX!==target.x||fact.targetZ!==target.z)return null;
    return Object.freeze({reason:'task',taskId:task.id,binding});
  };
  const requestNativeFarmHome=(state,worker)=>{`]
]);
